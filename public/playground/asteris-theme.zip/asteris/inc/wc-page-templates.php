<?php
/**
 * Force the Asteris cart/checkout templates for WC's cart and checkout pages
 * regardless of their slug. WC stores those page IDs in
 * woocommerce_cart_page_id and woocommerce_checkout_page_id options.
 *
 * Without this, a site that renamed the cart page to `/your-cart/` would fall
 * back to page.html instead of using page-cart.html. With this filter, the
 * Asteris cart template is injected at the top of the template hierarchy
 * whenever we're on a page whose ID matches WC's cart/checkout option.
 *
 * @package Asteris
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'template_hierarchy', static function ( array $templates ): array {
	if ( ! function_exists( 'wc_get_page_id' ) ) {
		return $templates;
	}
	if ( ! is_page() ) {
		return $templates;
	}
	$current_id = (int) get_queried_object_id();
	if ( ! $current_id ) {
		return $templates;
	}

	$map = [
		'page-cart'     => (int) wc_get_page_id( 'cart' ),
		'page-checkout' => (int) wc_get_page_id( 'checkout' ),
	];
	foreach ( $map as $slug => $wc_page_id ) {
		if ( $wc_page_id > 0 && $wc_page_id === $current_id && ! in_array( $slug, $templates, true ) ) {
			array_unshift( $templates, $slug );
		}
	}
	return $templates;
} );
