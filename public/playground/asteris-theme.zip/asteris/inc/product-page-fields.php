<?php
/**
 * Per-product editable content fields for the Asteris product page templates.
 *
 * Adds an "Asteris Page Content" tab to the WooCommerce Product data box.
 * Six text fields map to paragraphs in the product page templates via the
 * WordPress 6.5+ Block Bindings API. Empty field => block hides.
 *
 * Fields:
 *   - _asteris_loyalty_message   (Atelier loyalty banner)
 *   - _asteris_alternative_link  (Atelier "Looking for the alternative?" line)
 *   - _asteris_bulk_enquiry      (Atelier "For bulk enquiries..." line)
 *   - _asteris_shipping_text     (Atelier "Spend $125+..." line)
 *   - _asteris_how_to_use        (Atelier "How To Use" accordion body)
 *   - _asteris_important_notice  (Atelier "Important" accordion body)
 *
 * Templates reference these via metadata.bindings on each paragraph:
 *   {"metadata":{"bindings":{"content":{"source":"asteris/product-field",
 *    "args":{"key":"loyalty_message"}}}}}
 *
 * @package Asteris
 */

defined( 'ABSPATH' ) || exit;

/**
 * BNPL providers — text-only wordmarks (no copyrighted logo files).
 * Each renders as a styled .asteris-bnpl-badge with brand-tinted colours.
 */
const ASTERIS_BNPL_PROVIDERS = [
	'afterpay' => [ 'label' => 'Afterpay', 'bg' => '#B2FCE4', 'fg' => '#000000' ],
	'klarna'   => [ 'label' => 'Klarna',   'bg' => '#FFB3C7', 'fg' => '#0A0A0A' ],
	'zip'      => [ 'label' => 'Zip',      'bg' => '#1A0826', 'fg' => '#AAFE2E' ],
	'affirm'   => [ 'label' => 'Affirm',   'bg' => '#0FA0EA', 'fg' => '#FFFFFF' ],
	'paypal'   => [ 'label' => 'PayPal Pay in 4', 'bg' => '#FFC439', 'fg' => '#003087' ],
	'sezzle'   => [ 'label' => 'Sezzle',   'bg' => '#9B5BFF', 'fg' => '#FFFFFF' ],
	'clearpay' => [ 'label' => 'Clearpay', 'bg' => '#B2FCE4', 'fg' => '#000000' ],
];

const ASTERIS_LAYOUT_WIDTHS = [
	'standard' => 'Standard — centred (default, ~840px)',
	'wide'     => 'Wide — 1280px columns',
	'full'     => 'Full width — edge-to-edge with side padding',
];

const ASTERIS_PRODUCT_FIELDS = [
	// === Shared across templates ===
	'bnpl_text'        => [
		'label' => 'BNPL / payment-options line',
		'help'  => 'Sits directly under the price. Lead text + provider chips. Empty lead AND no providers hides the line.',
		'type'  => 'bnpl',
		'group' => 'Shared',
	],
	'loyalty_message'  => [
		'label' => 'Loyalty banner',
		'help'  => 'Coloured strip above add-to-cart. Empty hides the strip. HTML <strong>, <em>, <a> allowed.',
		'group' => 'Shared',
	],
	'alternative_link' => [
		'label' => 'Alternative-product line',
		'help'  => '"Looking for the alternative? <a>It remains available here.</a>" Empty hides the line.',
		'group' => 'Shared',
	],
	'bulk_enquiry'     => [
		'label' => 'Bulk-enquiry line',
		'help'  => '"For bulk enquiries, please <a>contact us</a>." Empty hides the line.',
		'group' => 'Shared',
	],
	'shipping_text'    => [
		'label' => 'Shipping line',
		'help'  => '"Spend $125+ and receive FREE* shipping. T&Cs apply." Empty hides the line.',
		'group' => 'Shared',
	],
	// === Lookbook ===
	'size_guide'       => [
		'label' => 'Size & fit notes (Lookbook)',
		'help'  => 'Long-form size + fit guidance. Shows in the "Size & fit" accordion. HTML allowed.',
		'group' => 'Lookbook',
	],
	'materials_care'   => [
		'label' => 'Materials & care (Lookbook / Configurator)',
		'help'  => 'Fabric / material composition + care instructions. Shows in accordion.',
		'group' => 'Lookbook',
	],
	// === Specs ===
	'spec_table'       => [
		'label' => 'Spec table (Specs)',
		'help'  => 'Left-rail spec list. Use HTML — one row per spec, e.g. `<strong>CPU:</strong> M3 Pro<br>` per line.',
		'group' => 'Specs',
	],
	'datasheet_url'    => [
		'label' => 'Datasheet PDF link (Specs)',
		'help'  => 'Full HTML anchor: `<a href="...">Download datasheet</a>`. Renders below the spec table.',
		'group' => 'Specs',
	],
	'feature_1'        => [
		'label' => 'Feature tile 1 (Specs)',
		'help'  => 'Short headline for the first key-features tile, e.g. "M3 Pro chip · 12-core CPU".',
		'group' => 'Specs',
	],
	'feature_2'        => [
		'label' => 'Feature tile 2 (Specs)',
		'help'  => 'Short headline for tile 2.',
		'group' => 'Specs',
	],
	'feature_3'        => [
		'label' => 'Feature tile 3 (Specs)',
		'help'  => 'Short headline for tile 3.',
		'group' => 'Specs',
	],
	'feature_4'        => [
		'label' => 'Feature tile 4 (Specs)',
		'help'  => 'Short headline for tile 4.',
		'group' => 'Specs',
	],
	'box_contents'     => [
		'label' => "What's in the box (Specs)",
		'help'  => 'Centred dark stripe. Plain text or HTML list — e.g. `Laptop · Charger · USB-C cable · Quick-start guide`.',
		'group' => 'Specs',
	],
	'compatibility'    => [
		'label' => 'Compatibility notes (Specs)',
		'help'  => 'Compatible OS / accessories / models. Accordion body.',
		'group' => 'Specs',
	],
	'warranty'         => [
		'label' => 'Warranty & support (Specs)',
		'help'  => 'Warranty terms + support contact. Accordion body.',
		'group' => 'Specs',
	],
	// === Subscription ===
	'subscription_callout' => [
		'label' => 'Subscription callout copy (Subscription)',
		'help'  => 'Shown in the bordered callout box near the top of the buy column. e.g. "Want this delivered on a schedule? Email us at hello@yourstore.com to set up a regular dispatch." Leave empty to hide the box.',
		'group' => 'Subscription',
	],
	'delivery_frequencies' => [
		'label' => 'Available delivery rhythms (Subscription)',
		'help'  => 'List of supported cadences e.g. "Every 30 days · Every 60 days · Every 90 days". Display only — actual recurring billing requires a subscriptions plugin.',
		'group' => 'Subscription',
	],
	'how_it_works'     => [
		'label' => 'How subscriptions work (Subscription)',
		'help'  => 'Plain-language explainer in the accordion.',
		'group' => 'Subscription',
	],
	'ingredients'      => [
		'label' => 'Ingredients & details (Subscription)',
		'help'  => 'Ingredient list / nutrition / composition. Accordion body.',
		'group' => 'Subscription',
	],
	// === Configurator ===
	'build_time'       => [
		'label' => 'Build time pill (Configurator)',
		'help'  => 'Short text e.g. "⏱ Made in 2-3 weeks". Shows in the muted pill below the gallery.',
		'group' => 'Configurator',
	],
	'addons'           => [
		'label' => 'Optional add-ons list (Configurator)',
		'help'  => 'One add-on per line, e.g. "Gift wrapping +$5". Shown to customers in the dashed-border panel.',
		'group' => 'Configurator',
	],
	// === Wellness ===
	'skin_types'       => [
		'label' => 'Target skin/hair type tag (Wellness)',
		'help'  => 'Short eyebrow above title, e.g. "For dry · sensitive skin" or "Combination · oily".',
		'group' => 'Wellness',
	],
	'ingredients_list' => [
		'label' => 'Key ingredients hero (Wellness)',
		'help'  => 'Hero list of star ingredients with short benefit. e.g. "Niacinamide — calms redness · Hyaluronic — plumps · Vitamin C — brightens".',
		'group' => 'Wellness',
	],
	'how_to_use'       => [
		'label' => 'How to use (Wellness)',
		'help'  => 'Routine steps, e.g. "AM: cleanse → apply 2 drops → moisturise · PM: cleanse → apply → seal".',
		'group' => 'Wellness',
	],
	'review_summary'   => [
		'label' => 'Reviews by skin type (Wellness)',
		'help'  => 'Aggregate snapshot, e.g. "Loved by dry-skin customers · Mixed reviews from acne-prone". Accordion body.',
		'group' => 'Wellness',
	],
	// === B2B / Wholesale ===
	'payment_terms'    => [
		'label' => 'Account-status badge (B2B)',
		'help'  => 'Pill above title, e.g. "Trade account · Net-30" or "Approved buyer · PO accepted". Leave empty to hide.',
		'group' => 'B2B',
	],
	'pricing_tiers'    => [
		'label' => 'Volume pricing table (B2B)',
		'help'  => 'One tier per line, e.g. "1–10 units → $50 ea · 11–50 → $42 ea · 51+ → $36 ea". Display only.',
		'group' => 'B2B',
	],
	'moq_text'         => [
		'label' => 'Minimum order quantity (B2B)',
		'help'  => 'Short line next to price, e.g. "MOQ: 10 units".',
		'group' => 'B2B',
	],
	'rfq_contact'      => [
		'label' => 'Request-for-quote CTA (B2B)',
		'help'  => 'Dashed-border box. e.g. "Need 500+? Email trade@yourstore.com for a custom quote." HTML link allowed.',
		'group' => 'B2B',
	],
	'spec_sheet_url'   => [
		'label' => 'Spec sheet PDF link (B2B)',
		'help'  => 'Anchor HTML, e.g. `<a href="...">Download spec sheet (PDF)</a>`. Accordion body.',
		'group' => 'B2B',
	],
	'compliance'       => [
		'label' => 'Compliance & certifications (B2B)',
		'help'  => 'Certifications, RoHS/REACH/CE, etc. Accordion body.',
		'group' => 'B2B',
	],
	// === Tickets / Events ===
	'event_dates'      => [
		'label' => 'Event date/time eyebrow (Tickets)',
		'help'  => 'Bold dateline above title, e.g. "SAT 12 SEP 2026 · 7:00 PM AEST".',
		'group' => 'Tickets',
	],
	'venue_address'    => [
		'label' => 'Venue address (Tickets)',
		'help'  => 'Single line, e.g. "📍 The Forum · 154 Flinders St · Melbourne VIC".',
		'group' => 'Tickets',
	],
	'speakers_list'    => [
		'label' => 'Speakers / instructors list (Tickets)',
		'help'  => 'One speaker per line, e.g. "Jane Doe — keynote · John Lee — workshop".',
		'group' => 'Tickets',
	],
	'seat_tiers'       => [
		'label' => 'Seat tier options (Tickets)',
		'help'  => 'One tier per line, e.g. "General — $89 · Reserved — $149 · VIP table — $299". Display only.',
		'group' => 'Tickets',
	],
	'group_discount'   => [
		'label' => 'Group-buy discount line (Tickets)',
		'help'  => 'Dashed-border box. e.g. "🎟 3+ tickets = 15% off — use code GROUP15 at checkout".',
		'group' => 'Tickets',
	],
	'schedule'         => [
		'label' => 'Event schedule (Tickets)',
		'help'  => 'Detailed agenda. Accordion body.',
		'group' => 'Tickets',
	],
	'refund_policy'    => [
		'label' => 'Refund policy (Tickets)',
		'help'  => 'Ticket refund/cancellation policy. Accordion body.',
		'group' => 'Tickets',
	],
];

/**
 * Register meta for REST API + Block Bindings exposure.
 */
add_action( 'init', static function (): void {
	foreach ( ASTERIS_PRODUCT_FIELDS as $key => $cfg ) {
		register_post_meta( 'product', '_asteris_' . $key, [
			'type'         => 'string',
			'single'       => true,
			'show_in_rest' => true,
			'auth_callback' => static fn() => current_user_can( 'edit_products' ),
			'sanitize_callback' => static fn( $v ) => wp_kses_post( (string) $v ),
		] );
	}
	// Page width — registered separately so it can live in a side metabox.
	register_post_meta( 'product', '_asteris_layout_width', [
		'type'              => 'string',
		'single'            => true,
		'show_in_rest'      => true,
		'auth_callback'     => static fn() => current_user_can( 'edit_products' ),
		'sanitize_callback' => static function ( $v ): string {
			return array_key_exists( (string) $v, ASTERIS_LAYOUT_WIDTHS ) ? (string) $v : 'standard';
		},
	] );
	// Sub-text size — S/M/L for the bound sub paragraphs (BNPL, alternative,
	// bulk, shipping, loyalty). Default M.
	register_post_meta( 'product', '_asteris_subtext_size', [
		'type'              => 'string',
		'single'            => true,
		'show_in_rest'      => true,
		'auth_callback'     => static fn() => current_user_can( 'edit_products' ),
		'sanitize_callback' => static fn( $v ): string => in_array( (string) $v, [ 's', 'm', 'l' ], true ) ? (string) $v : 'm',
	] );
	// Show breadcrumbs — default = on. Stored as '1' or '0'.
	register_post_meta( 'product', '_asteris_show_breadcrumbs', [
		'type'              => 'string',
		'single'            => true,
		'show_in_rest'      => true,
		'auth_callback'     => static fn() => current_user_can( 'edit_products' ),
		'sanitize_callback' => static fn( $v ): string => $v === '0' ? '0' : '1',
	] );
	// BNPL providers stored as comma-separated slugs.
	register_post_meta( 'product', '_asteris_bnpl_providers', [
		'type'              => 'string',
		'single'            => true,
		'show_in_rest'      => true,
		'auth_callback'     => static fn() => current_user_can( 'edit_products' ),
		'sanitize_callback' => static function ( $v ): string {
			$slugs = array_filter( array_map( 'sanitize_key', (array) explode( ',', (string) $v ) ) );
			$valid = array_keys( ASTERIS_BNPL_PROVIDERS );
			return implode( ',', array_intersect( $slugs, $valid ) );
		},
	] );
} );

/**
 * Add the Asteris Page Content tab to the WC Product data box.
 */
add_filter( 'woocommerce_product_data_tabs', static function ( array $tabs ): array {
	$tabs['asteris_page_content'] = [
		'label'  => __( 'Page Content', 'asteris' ),
		'target' => 'asteris_page_content_data',
		'class'  => [],
		'priority' => 65,
	];
	return $tabs;
} );

/**
 * Render the tab body — one textarea per field.
 */
add_action( 'woocommerce_product_data_panels', static function (): void {
	global $post;
	echo '<div id="asteris_page_content_data" class="panel woocommerce_options_panel">';
	?>
	<style>
		#asteris_page_content_data .asteris-row { display:block; padding:14px 16px; border-bottom:1px solid #eee; clear:both; overflow:hidden; }
		#asteris_page_content_data .asteris-row label.asteris-label { display:block; float:none !important; width:auto !important; font-weight:600; font-size:13px; margin:0 0 4px; padding:0; color:#1d2327; }
		#asteris_page_content_data .asteris-row .asteris-help { display:block; font-size:12px; color:#646970; margin:0 0 8px; padding:0; }
		#asteris_page_content_data .asteris-row textarea { display:block; width:100%; max-width:680px; float:none !important; margin:0; padding:6px 8px; box-sizing:border-box; }
		#asteris_page_content_data .asteris-bnpl-grid { margin-top:12px; display:block; max-width:680px; overflow:visible; }
		#asteris_page_content_data .asteris-bnpl-grid .asteris-bnpl-intro { display:block; font-size:12px; color:#646970; margin:0 0 8px; padding:0; width:auto; float:none; }
		#asteris_page_content_data .asteris-bnpl-grid label.asteris-bnpl-row { display:flex; align-items:center; justify-content:space-between; gap:12px; font-size:13px; font-weight:400; cursor:pointer; padding:6px 10px; margin:0 0 4px; border:1px solid #e6e6e8; border-radius:6px; background:#fbfbfc; width:100%; max-width:none; float:none; box-sizing:border-box; }
		#asteris_page_content_data .asteris-bnpl-grid label.asteris-bnpl-row:hover { background:#f0f0f1; }
		#asteris_page_content_data .asteris-bnpl-grid label.asteris-bnpl-row input[type=checkbox] { margin:0 8px 0 0; flex:0 0 auto; }
		#asteris_page_content_data .asteris-bnpl-grid label.asteris-bnpl-row .asteris-bnpl-name { flex:1 1 auto; color:#1d2327; font-weight:500; }
		#asteris_page_content_data .asteris-bnpl-grid .asteris-chip { display:inline-block; padding:4px 12px; border-radius:4px; font-size:11px; font-weight:700; line-height:1.4; white-space:nowrap; flex:0 0 auto; min-width:90px; text-align:center; }
		#asteris_page_content_data .asteris-intro { padding:14px 16px 0; color:#646970; font-size:13px; margin:0; }
		#asteris_page_content_data .asteris-group-header { padding:18px 16px 8px; margin-top:4px; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:#1d2327; background:#f6f7f7; border-top:1px solid #dcdcde; border-bottom:1px solid #dcdcde; }
	</style>
	<p class="asteris-intro">These fields populate the per-product editable strings on the Asteris product page templates. Leave empty to hide. Fields are grouped by which template uses them — fill only what applies to this product.</p>
	<?php
	$last_group = '';
	foreach ( ASTERIS_PRODUCT_FIELDS as $key => $cfg ) {
		$id    = '_asteris_' . $key;
		$value = get_post_meta( $post->ID, $id, true );
		$group = $cfg['group'] ?? 'Other';
		if ( $group !== $last_group ) {
			echo '<div class="asteris-group-header">' . esc_html( $group ) . '</div>';
			$last_group = $group;
		}
		echo '<div class="asteris-row">';
		echo '<label class="asteris-label" for="' . esc_attr( $id ) . '">' . esc_html( $cfg['label'] ) . '</label>';
		echo '<p class="asteris-help">' . esc_html( $cfg['help'] ) . '</p>';

		echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" rows="2">' . esc_textarea( $value ) . '</textarea>';

		if ( ( $cfg['type'] ?? '' ) === 'bnpl' ) {
			$selected = array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, '_asteris_bnpl_providers', true ) ) ) );
			echo '<div class="asteris-bnpl-grid">';
			echo '<span class="asteris-bnpl-intro">Show providers below the line:</span>';
			foreach ( ASTERIS_BNPL_PROVIDERS as $slug => $info ) {
				$checked = in_array( $slug, $selected, true ) ? ' checked' : '';
				echo '<label class="asteris-bnpl-row">';
				echo '<input type="checkbox" name="_asteris_bnpl_providers[]" value="' . esc_attr( $slug ) . '"' . $checked . '>';
				echo '<span class="asteris-bnpl-name">' . esc_html( $info['label'] ) . '</span>';
				echo '<span class="asteris-chip" style="background:' . esc_attr( $info['bg'] ) . ';color:' . esc_attr( $info['fg'] ) . '">' . esc_html( $info['label'] ) . '</span>';
				echo '</label>';
			}
			echo '</div>';
		}
		echo '</div>';
	}
	echo '</div>';
} );

/**
 * Save the meta on product save.
 */
add_action( 'woocommerce_process_product_meta', static function ( int $product_id ): void {
	foreach ( ASTERIS_PRODUCT_FIELDS as $key => $cfg ) {
		$id = '_asteris_' . $key;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WC handles nonce on the product save form
		if ( ! isset( $_POST[ $id ] ) ) {
			continue;
		}
		update_post_meta( $product_id, $id, wp_kses_post( wp_unslash( (string) $_POST[ $id ] ) ) );
	}
	// BNPL providers (checkbox array).
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WC handles nonce on the product save form
	$providers = isset( $_POST['_asteris_bnpl_providers'] ) ? (array) wp_unslash( $_POST['_asteris_bnpl_providers'] ) : [];
	$slugs     = array_filter( array_map( 'sanitize_key', $providers ) );
	$valid     = array_keys( ASTERIS_BNPL_PROVIDERS );
	update_post_meta( $product_id, '_asteris_bnpl_providers', implode( ',', array_intersect( $slugs, $valid ) ) );
} );

/**
 * Register the Block Bindings source.
 *
 * Templates bind paragraphs via:
 *   {"metadata":{"bindings":{"content":{
 *     "source":"asteris/product-field",
 *     "args":{"key":"loyalty_message"}
 *   }}}}
 *
 * Returns the meta value verbatim. Empty returns empty string — the calling
 * pattern (render_block filter below) hides the wrapping group when empty.
 */
add_action( 'init', static function (): void {
	if ( ! function_exists( 'register_block_bindings_source' ) ) {
		return;
	}

	register_block_bindings_source( 'asteris/product-field', [
		'label'              => __( 'Asteris Product Field', 'asteris' ),
		'get_value_callback' => static function ( array $source_args, $block ): string {
			$key = $source_args['key'] ?? '';
			if ( ! $key || ! array_key_exists( $key, ASTERIS_PRODUCT_FIELDS ) ) {
				return '';
			}

			$product_id = 0;
			if ( $block instanceof WP_Block && ! empty( $block->context['postId'] ) ) {
				$product_id = (int) $block->context['postId'];
			}
			if ( ! $product_id ) {
				$product_id = get_the_ID();
			}
			if ( ! $product_id ) {
				return '';
			}

			$value = get_post_meta( $product_id, '_asteris_' . $key, true );
			$value = is_string( $value ) ? $value : '';

			// Multi-line list-style fields: convert newlines to <br> so each
			// line in the textarea renders as its own visual line.
			$list_like = [ 'spec_table', 'box_contents', 'addons', 'delivery_frequencies', 'ingredients_list', 'how_to_use', 'pricing_tiers', 'speakers_list', 'seat_tiers' ];
			if ( in_array( $key, $list_like, true ) && $value !== '' ) {
				$value = nl2br( $value, false );
			}

			// Compose BNPL line: lead text + provider chips.
			if ( $key === 'bnpl_text' ) {
				$providers = array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $product_id, '_asteris_bnpl_providers', true ) ) ) );
				$chips = '';
				foreach ( $providers as $slug ) {
					if ( ! isset( ASTERIS_BNPL_PROVIDERS[ $slug ] ) ) {
						continue;
					}
					$info = ASTERIS_BNPL_PROVIDERS[ $slug ];
					$chips .= sprintf(
						' <span class="asteris-bnpl-badge" style="background:%s;color:%s">%s</span>',
						esc_attr( $info['bg'] ),
						esc_attr( $info['fg'] ),
						esc_html( $info['label'] )
					);
				}
				if ( $value === '' && $chips === '' ) {
					return '';
				}
				return trim( $value . $chips );
			}

			return $value;
		},
		'uses_context' => [ 'postId', 'postType' ],
	] );
} );

/**
 * Page width side metabox — lives in the right-hand sidebar of the
 * product edit screen next to Publish / Post Attributes / Product image.
 */
add_action( 'add_meta_boxes', static function (): void {
	add_meta_box(
		'asteris_page_width',
		__( 'Asteris page settings', 'asteris' ),
		static function ( WP_Post $post ): void {
			$current = get_post_meta( $post->ID, '_asteris_layout_width', true );
			if ( ! is_string( $current ) || ! array_key_exists( $current, ASTERIS_LAYOUT_WIDTHS ) ) {
				$current = 'standard';
			}
			$show_breadcrumbs = get_post_meta( $post->ID, '_asteris_show_breadcrumbs', true );
			if ( $show_breadcrumbs === '' ) {
				$show_breadcrumbs = '1'; // default on for new products
			}
			wp_nonce_field( 'asteris_page_width_save', 'asteris_page_width_nonce' );

			echo '<p style="margin:0 0 4px;font-size:13px;font-weight:600;color:#1d2327">Page width</p>';
			echo '<p style="margin:0 0 8px;font-size:12px;color:#646970">How wide the product page renders.</p>';
			foreach ( ASTERIS_LAYOUT_WIDTHS as $value => $label ) {
				$checked = checked( $current, $value, false );
				echo '<label style="display:block;padding:4px 0;font-size:13px;cursor:pointer">';
				echo '<input type="radio" name="_asteris_layout_width" value="' . esc_attr( $value ) . '"' . $checked . ' style="margin-right:6px"> ';
				echo esc_html( $label );
				echo '</label>';
			}

			echo '<hr style="margin:14px 0;border:none;border-top:1px solid #e0e0e0">';
			$subtext_size = get_post_meta( $post->ID, '_asteris_subtext_size', true );
			if ( ! in_array( $subtext_size, [ 's', 'm', 'l' ], true ) ) {
				$subtext_size = 'm';
			}
			echo '<p style="margin:0 0 4px;font-size:13px;font-weight:600;color:#1d2327">Sub-text size</p>';
			echo '<p style="margin:0 0 8px;font-size:12px;color:#646970">Size of the BNPL, alternative-link, bulk-enquiry, shipping and loyalty lines.</p>';
			$st_labels = [ 's' => 'Small', 'm' => 'Medium', 'l' => 'Large' ];
			echo '<div class="asteris-subtext-pill-group">';
			foreach ( $st_labels as $value => $label ) {
				$checked = checked( $subtext_size, $value, false );
				echo '<label class="asteris-subtext-pill">';
				echo '<input type="radio" name="_asteris_subtext_size" value="' . esc_attr( $value ) . '"' . $checked . '>';
				echo '<span>' . esc_html( $label ) . '</span>';
				echo '</label>';
			}
			echo '</div>';
			?>
			<style>
				.asteris-subtext-pill-group { display:flex; gap:6px; margin-bottom:4px; }
				.asteris-subtext-pill { flex:1; }
				.asteris-subtext-pill input[type="radio"] { position:absolute; opacity:0; pointer-events:none; }
				.asteris-subtext-pill > span { display:block; text-align:center; padding:6px 8px; border:1px solid #c3c4c7; border-radius:4px; cursor:pointer; font-size:13px; background:#fff; color:#1d2327; transition:background 80ms, color 80ms, border-color 80ms; }
				.asteris-subtext-pill:hover > span { border-color:#2271b1; }
				.asteris-subtext-pill:has(input:checked) > span { background:#2271b1; color:#fff; border-color:#2271b1; }
			</style>
			<?php

			echo '<hr style="margin:14px 0;border:none;border-top:1px solid #e0e0e0">';
			echo '<p style="margin:0 0 4px;font-size:13px;font-weight:600;color:#1d2327">Breadcrumbs</p>';
			echo '<p style="margin:0 0 8px;font-size:12px;color:#646970">Show the "Home / Category / Product" breadcrumb trail near the top of the page.</p>';
			echo '<label style="display:block;padding:4px 0;font-size:13px;cursor:pointer">';
			// Hidden input ensures unchecked submits '0' (vs unchecked = absent from POST)
			echo '<input type="hidden" name="_asteris_show_breadcrumbs" value="0">';
			echo '<input type="checkbox" name="_asteris_show_breadcrumbs" value="1"' . checked( $show_breadcrumbs, '1', false ) . ' style="margin-right:6px"> ';
			echo 'Show breadcrumbs on this product';
			echo '</label>';
		},
		'product',
		'side',
		'default'
	);
} );

add_action( 'save_post_product', static function ( int $post_id ): void {
	if ( ! isset( $_POST['asteris_page_width_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['asteris_page_width_nonce'] ) ), 'asteris_page_width_save' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Page width
	$raw = isset( $_POST['_asteris_layout_width'] ) ? sanitize_key( wp_unslash( $_POST['_asteris_layout_width'] ) ) : 'standard';
	if ( ! array_key_exists( $raw, ASTERIS_LAYOUT_WIDTHS ) ) {
		$raw = 'standard';
	}
	update_post_meta( $post_id, '_asteris_layout_width', $raw );
	// Sub-text size
	$st = isset( $_POST['_asteris_subtext_size'] ) ? sanitize_key( wp_unslash( $_POST['_asteris_subtext_size'] ) ) : 'm';
	if ( ! in_array( $st, [ 's', 'm', 'l' ], true ) ) {
		$st = 'm';
	}
	update_post_meta( $post_id, '_asteris_subtext_size', $st );
	// Breadcrumbs — hidden input guarantees value present; '1' = show, '0' = hide.
	$bc = isset( $_POST['_asteris_show_breadcrumbs'] ) && (string) $_POST['_asteris_show_breadcrumbs'] === '1' ? '1' : '0';
	update_post_meta( $post_id, '_asteris_show_breadcrumbs', $bc );
} );

/**
 * Add a body class reflecting the per-product Page width selection so
 * style.css can override the constrained layout on this product only.
 *
 *   asteris-pw-standard  (default — no override)
 *   asteris-pw-wide      (~1280px columns)
 *   asteris-pw-full      (edge-to-edge with side padding)
 */
add_filter( 'body_class', static function ( array $classes ): array {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return $classes;
	}
	$id    = get_the_ID();
	$width = $id ? get_post_meta( $id, '_asteris_layout_width', true ) : '';
	if ( ! is_string( $width ) || $width === '' ) {
		$width = 'standard';
	}
	if ( ! array_key_exists( $width, ASTERIS_LAYOUT_WIDTHS ) ) {
		$width = 'standard';
	}
	$classes[] = 'asteris-pw-' . $width;

	$bc = $id ? get_post_meta( $id, '_asteris_show_breadcrumbs', true ) : '';
	if ( $bc === '0' ) {
		$classes[] = 'asteris-no-breadcrumbs';
	}

	$st = $id ? get_post_meta( $id, '_asteris_subtext_size', true ) : '';
	if ( ! in_array( $st, [ 's', 'm', 'l' ], true ) ) {
		$st = 'm';
	}
	$classes[] = 'asteris-st-' . $st;
	return $classes;
} );

/**
 * Print the tiny tab-restructure JS in the footer when the current product
 * uses the tabbed accordion style. Restructures any group of consecutive
 * <details> blocks into a proper tab interface (tab row + shared content
 * pane). Pure DOM rewrite, no external script — keeps the "no bundled JS"
 * theme promise truthful because this only fires when the user opts in to
 * the tabbed style on a specific product.
 */

/**
 * Hide wrapper groups marked with the className "asteris-bound-hide-if-empty"
 * when every bound paragraph inside resolves to empty.
 *
 * Lightweight render-time check — runs only on groups carrying the class.
 */
$asteris_hide_if_empty_callback = static function ( string $block_content, array $block ): string {
	$class = $block['attrs']['className'] ?? '';
	if ( ! is_string( $class ) || ! str_contains( $class, 'asteris-bound-hide-if-empty' ) ) {
		return $block_content;
	}
	// If the rendered output, stripped of HTML tags and whitespace, is empty, hide.
	if ( trim( wp_strip_all_tags( $block_content ) ) === '' ) {
		return '';
	}
	return $block_content;
};
add_filter( 'render_block_core/group',   $asteris_hide_if_empty_callback, 10, 2 );
add_filter( 'render_block_core/column',  $asteris_hide_if_empty_callback, 10, 2 );
add_filter( 'render_block_core/details', $asteris_hide_if_empty_callback, 10, 2 );
