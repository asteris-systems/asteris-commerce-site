<?php
/**
 * Title: Press — "As seen in" strip
 * Slug: asteris/shop-press-strip
 * Categories: asteris-shop, woo-commerce
 * Description: Single-line strip of publication names. Drop above or below the hero for instant credibility.
 */
if ( ! class_exists( 'WooCommerce' ) ) { return; }
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">AS SEEN IN</p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center" style="margin-top:var(--wp--preset--spacing--40)">
		<!-- wp:column {"verticalAlignment":"center"} --><div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"align":"center","fontSize":"lg"} --><p class="has-text-align-center has-lg-font-size"><strong>VOGUE</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} --><div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"align":"center","fontSize":"lg"} --><p class="has-text-align-center has-lg-font-size"><strong>GQ</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} --><div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"align":"center","fontSize":"lg"} --><p class="has-text-align-center has-lg-font-size"><strong>NYT</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} --><div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"align":"center","fontSize":"lg"} --><p class="has-text-align-center has-lg-font-size"><strong>ESQUIRE</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} --><div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"align":"center","fontSize":"lg"} --><p class="has-text-align-center has-lg-font-size"><strong>MONOCLE</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
