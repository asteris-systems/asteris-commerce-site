<?php
/**
 * Title: Team grid — 4 people
 * Slug: asteris/team-grid
 * Categories: asteris-page-sections, featured
 * Description: Four team members with photo, name, role.
 */
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">The team behind the product.</h2>
	<!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image -->
			<figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure>
			<!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-md-font-size">Sarah Chen</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
			<p class="has-muted-color has-text-color has-sm-font-size">Founder &amp; CEO</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image -->
			<figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure>
			<!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-md-font-size">Alex Morgan</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
			<p class="has-muted-color has-text-color has-sm-font-size">Head of Engineering</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image -->
			<figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure>
			<!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-md-font-size">Priya Iyer</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
			<p class="has-muted-color has-text-color has-sm-font-size">Design Lead</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image -->
			<figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure>
			<!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-md-font-size">Jack Williams</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
			<p class="has-muted-color has-text-color has-sm-font-size">Customer Success</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
