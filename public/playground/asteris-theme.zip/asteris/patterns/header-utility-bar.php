<?php
/**
 * Title: Header with utility bar
 * Slug: asteris/header-utility-bar
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Slim utility row (account / wishlist / cart) above main header. E-commerce / store vibe.
 */
?>
<!-- wp:group {"tagName":"header","align":"full"} -->
<header class="wp-block-group alignfull">

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"color":{"background":"var:preset|color|subtle"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignfull has-background" style="background-color:var(--wp--preset--color--subtle);padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:group {"layout":{"type":"flex","justifyContent":"right"},"style":{"typography":{"fontSize":"var:preset|font-size|xs"}}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|xs"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
			<p class="has-text-color" style="color:var(--wp--preset--color--muted);margin-top:0;margin-bottom:0;font-size:var(--wp--preset--font-size--xs)"><a href="#">Track order</a> &nbsp;·&nbsp; <a href="#">Help</a> &nbsp;·&nbsp; <a href="#">Account</a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"nowrap"}} -->
		<div class="wp-block-group">
			<!-- wp:site-title {"level":0,"style":{"typography":{"fontWeight":"800","fontSize":"var:preset|font-size|lg"}}} /-->

			<!-- wp:navigation {"layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center"},"style":{"typography":{"fontSize":"var:preset|font-size|md"}}} /-->

			<!-- wp:search {"label":"Search","showLabel":false,"placeholder":"Search products…","width":260,"widthUnit":"px","buttonText":"Search","buttonPosition":"button-inside","buttonUseIcon":true,"style":{"border":{"radius":"999px"}}} /-->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

</header>
<!-- /wp:group -->
