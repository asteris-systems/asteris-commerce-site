<?php
/**
 * Title: Reviews — social proof with aggregate
 * Slug: asteris/shop-reviews-proof
 * Categories: asteris-shop, woo-commerce, featured
 * Description: Star rating headline + three customer reviews. Drop above the buy section.
 */
if ( ! class_exists( 'WooCommerce' ) ) { return; }
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"3xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-3-xl-font-size">★★★★★ 4.9 / 5</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"md","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-md-font-size">From 2,341 verified customer reviews.</p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size">★★★★★</p><!-- /wp:paragraph -->
			<!-- wp:paragraph --><p>&ldquo;Better than the one I paid three times as much for last year. Will buy again.&rdquo;</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size"><strong>Emma R.</strong> · Verified buyer</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size">★★★★★</p><!-- /wp:paragraph -->
			<!-- wp:paragraph --><p>&ldquo;Arrived in three days, beautifully packaged, exactly as pictured. Five stars.&rdquo;</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size"><strong>James T.</strong> · Verified buyer</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size">★★★★★</p><!-- /wp:paragraph -->
			<!-- wp:paragraph --><p>&ldquo;The packaging alone made me want to keep buying. The product is even better.&rdquo;</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size"><strong>Mira L.</strong> · Verified buyer</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
