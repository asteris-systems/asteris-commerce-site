<?php
/**
 * Title: Store header — 2-row, edge-to-edge
 * Slug: asteris/header-store-two-row
 * Categories: asteris-headers, header, woo-commerce
 * Block Types: core/template-part/header
 * Description: Two-row layout for stores with crowded nav. Row 1: logo left + account/cart tight on the right. Row 2: navigation centred below. Content spans the full viewport width — no centre column.
 *
 * NOTE: Contains a Mini-Cart block (WP allows one per page). Remove any
 * duplicate Mini-Cart elsewhere before using.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"border":{"bottom":{"color":"var:preset|color|border","width":"1px"}}}} -->
<header class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px">

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|30","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--60)">
		<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"nowrap"}} -->
		<div class="wp-block-group">

			<!-- wp:site-title {"level":0,"style":{"typography":{"fontWeight":"800","fontSize":"var:preset|font-size|xl","textTransform":"uppercase","letterSpacing":"0.06em"}}} /-->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"},"style":{"spacing":{"blockGap":"var:preset|spacing|30"}}} -->
			<div class="wp-block-group">
				<!-- wp:search {"label":"Search","showLabel":false,"placeholder":"Search…","width":220,"widthUnit":"px","buttonText":"Search","buttonPosition":"button-inside","buttonUseIcon":true,"style":{"border":{"radius":"999px"}}} /-->

				<!-- wp:woocommerce/customer-account {"displayStyle":"icon_only","iconStyle":"line"} /-->

				<!-- wp:woocommerce/mini-cart {"hasHiddenPrice":true} /-->
			</div>
			<!-- /wp:group -->

		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|30","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}},"border":{"top":{"color":"var:preset|color|border","width":"1px"}}}} -->
	<div class="wp-block-group alignfull" style="border-top-color:var(--wp--preset--color--border);border-top-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--60)">
		<!-- wp:navigation {"overlayMenu":"mobile","layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center"},"style":{"typography":{"fontSize":"var:preset|font-size|sm","letterSpacing":"0.02em"}}} /-->
	</div>
	<!-- /wp:group -->

</header>
<!-- /wp:group -->
