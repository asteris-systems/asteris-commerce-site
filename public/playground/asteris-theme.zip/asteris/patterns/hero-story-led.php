<?php
/**
 * Title: Hero — story-led, narrow
 * Slug: asteris/hero-story-led
 * Categories: asteris-heroes, asteris-page-sections
 * Description: Editorial hero — narrow centred column, generous spacing. For about pages, manifestos, long-form intros.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|90","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"600px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--90);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":1,"fontSize":"3xl"} -->
	<h1 class="wp-block-heading has-3-xl-font-size">There's a better way to do this — and we're building it.</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"lg","textColor":"muted"} -->
	<p class="has-muted-color has-text-color has-lg-font-size">A paragraph that sets up the story. Why this matters, who it's for, what the rest of the page is going to walk through. Earn the scroll.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
