<?php
/**
 * Title: Centered logo header
 * Slug: asteris/header-centered-with-logo
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Centered site title with navigation underneath. Premium / editorial vibe.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"},"style":{"spacing":{"blockGap":"var:preset|spacing|40"}}} -->
	<div class="wp-block-group">
		<!-- wp:site-title {"level":0,"textAlign":"center","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.16em","fontWeight":"700","fontSize":"var:preset|font-size|lg"}}} /-->

		<!-- wp:navigation {"layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center"},"style":{"typography":{"fontSize":"var:preset|font-size|sm","letterSpacing":"0.04em"}}} /-->
	</div>
	<!-- /wp:group -->
</header>
<!-- /wp:group -->
