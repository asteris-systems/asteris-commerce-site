<?php
/**
 * Title: Newsletter — single-field inline
 * Slug: asteris/newsletter-single-field
 * Categories: asteris-page-sections, call-to-action
 * Description: Minimal email + button on one line. No card, no background. Drop into any column.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center"><strong>Get one good email a week.</strong></p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Subscribe</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">No spam. Unsubscribe anytime.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
