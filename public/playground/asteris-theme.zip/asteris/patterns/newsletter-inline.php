<?php
/**
 * Title: Newsletter signup — inline section
 * Slug: asteris/newsletter-inline
 * Categories: asteris-page-sections, featured, call-to-action
 * Description: Inline newsletter signup section. Drop between content sections to collect emails.
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-xl-font-size">Stay in the loop.</h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","fontSize":"md","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-md-font-size">Monthly updates. No spam. Unsubscribe in one click.</p>
	<!-- /wp:paragraph -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Subscribe</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->

</div>
<!-- /wp:group -->
