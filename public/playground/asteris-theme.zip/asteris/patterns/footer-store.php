<?php
/**
 * Title: Store footer — payment + trust + nav
 * Slug: asteris/footer-store
 * Categories: asteris-footers, footer, woo-commerce
 * Block Types: core/template-part/footer
 * Description: Three nav columns + trust strip (free shipping / returns / secure) + payment icons mention. The default e-commerce footer.
 */
?>
<!-- wp:group {"tagName":"footer","align":"full","style":{"spacing":{"margin":{"top":"var:preset|spacing|80"}},"border":{"top":{"color":"var:preset|color|border","width":"1px"}}}} -->
<footer class="wp-block-group alignfull" style="border-top-color:var(--wp--preset--color--border);border-top-width:1px;margin-top:var(--wp--preset--spacing--80)">

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px"}}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-columns">

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|sm","fontWeight":"600"}}} -->
				<p class="has-text-align-center" style="font-size:var(--wp--preset--font-size--sm);font-weight:600">Free shipping over $75</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|sm","fontWeight":"600"}}} -->
				<p class="has-text-align-center" style="font-size:var(--wp--preset--font-size--sm);font-weight:600">30-day returns</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|sm","fontWeight":"600"}}} -->
				<p class="has-text-align-center" style="font-size:var(--wp--preset--font-size--sm);font-weight:600">Secure checkout</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|sm","fontWeight":"600"}}} -->
				<p class="has-text-align-center" style="font-size:var(--wp--preset--font-size--sm);font-weight:600">2–3 day support</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:column -->

		</div>
		<!-- /wp:columns -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">

		<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
		<div class="wp-block-columns">

			<!-- wp:column {"width":"40%"} -->
			<div class="wp-block-column" style="flex-basis:40%">
				<!-- wp:site-title {"level":0,"style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em","fontWeight":"800","fontSize":"var:preset|font-size|lg"}}} /-->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|sm","lineHeight":"1.6"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
				<p class="has-text-color" style="color:var(--wp--preset--color--muted);margin-top:var(--wp--preset--spacing--30);font-size:var(--wp--preset--font-size--sm);line-height:1.6">Quality goods, honest pricing. Edit this tagline in the Site Editor.</p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|xs"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
				<p class="has-text-color" style="color:var(--wp--preset--color--muted);margin-top:var(--wp--preset--spacing--40);font-size:var(--wp--preset--font-size--xs)">We accept Visa · Mastercard · AmEx · Afterpay · Klarna · PayPal</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column {"width":"20%"} -->
			<div class="wp-block-column" style="flex-basis:20%">
				<!-- wp:heading {"level":4,"fontSize":"xs","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
				<h4 class="wp-block-heading has-text-color has-xs-font-size" style="color:var(--wp--preset--color--muted);margin-bottom:var(--wp--preset--spacing--30);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Shop</h4>
				<!-- /wp:heading -->
				<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical","setCascadingProperties":true},"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"spacing":{"blockGap":"var:preset|spacing|20"}}} /-->
			</div>
			<!-- /wp:column -->

			<!-- wp:column {"width":"20%"} -->
			<div class="wp-block-column" style="flex-basis:20%">
				<!-- wp:heading {"level":4,"fontSize":"xs","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
				<h4 class="wp-block-heading has-text-color has-xs-font-size" style="color:var(--wp--preset--color--muted);margin-bottom:var(--wp--preset--spacing--30);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Help</h4>
				<!-- /wp:heading -->
				<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical","setCascadingProperties":true},"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"spacing":{"blockGap":"var:preset|spacing|20"}}} /-->
			</div>
			<!-- /wp:column -->

			<!-- wp:column {"width":"20%"} -->
			<div class="wp-block-column" style="flex-basis:20%">
				<!-- wp:heading {"level":4,"fontSize":"xs","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
				<h4 class="wp-block-heading has-text-color has-xs-font-size" style="color:var(--wp--preset--color--muted);margin-bottom:var(--wp--preset--spacing--30);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Company</h4>
				<!-- /wp:heading -->
				<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical","setCascadingProperties":true},"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"spacing":{"blockGap":"var:preset|spacing|20"}}} /-->
			</div>
			<!-- /wp:column -->

		</div>
		<!-- /wp:columns -->

		<!-- wp:separator {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}}} -->
		<hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--40)"/>
		<!-- /wp:separator -->

		<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|xs"},"color":{"text":"var:preset|color|muted"}}} -->
		<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--muted);font-size:var(--wp--preset--font-size--xs)">&copy; All rights reserved.</p>
		<!-- /wp:paragraph -->

	</div>
	<!-- /wp:group -->

</footer>
<!-- /wp:group -->
