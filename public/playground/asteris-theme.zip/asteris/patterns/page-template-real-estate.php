<?php
/**
 * Title: Real estate listing — single property
 * Slug: asteris/page-template-real-estate
 * Categories: asteris-page-templates
 * Description: Single property page — hero image, price + key stats, description, features, inspection times, agent card.
 */
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt="Hero shot"/></figure><!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"65%"} -->
		<div class="wp-block-column" style="flex-basis:65%">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">FOR SALE · INSPECT SATURDAY</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"3xl"} --><h1 class="wp-block-heading has-3-xl-font-size">12 Example Street, Surry Hills</h1><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"lg"} --><p class="has-lg-font-size"><strong>$1,850,000</strong> · 4 bed · 2 bath · 2 car · 380 m²</p><!-- /wp:paragraph -->

			<!-- wp:heading {"level":2,"fontSize":"lg","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} --><h2 class="wp-block-heading has-lg-font-size" style="margin-top:var(--wp--preset--spacing--60)">About this home</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p>A beautifully renovated four-bedroom terrace on a quiet tree-lined street. Walking distance to cafés, parks, and the light rail. Sun-drenched living spaces, a chef's kitchen, and a private courtyard garden make this a rare find in one of Sydney's most-loved suburbs.</p><!-- /wp:paragraph -->

			<!-- wp:heading {"level":2,"fontSize":"lg","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} --><h2 class="wp-block-heading has-lg-font-size" style="margin-top:var(--wp--preset--spacing--60)">Features</h2><!-- /wp:heading -->
			<!-- wp:columns -->
			<div class="wp-block-columns">
				<!-- wp:column --><div class="wp-block-column"><!-- wp:list {"fontSize":"sm"} --><ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>4 bedrooms, all with built-ins</li><!-- /wp:list-item --><!-- wp:list-item --><li>Renovated kitchen + butler's pantry</li><!-- /wp:list-item --><!-- wp:list-item --><li>Polished timber floors throughout</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
				<!-- wp:column --><div class="wp-block-column"><!-- wp:list {"fontSize":"sm"} --><ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>Reverse-cycle air-conditioning</li><!-- /wp:list-item --><!-- wp:list-item --><li>Lock-up garage + storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>Solar panels (6.6 kW)</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
			</div>
			<!-- /wp:columns -->

			<!-- wp:heading {"level":2,"fontSize":"lg","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} --><h2 class="wp-block-heading has-lg-font-size" style="margin-top:var(--wp--preset--spacing--60)">Inspect</h2><!-- /wp:heading -->
			<!-- wp:list -->
			<ul class="wp-block-list"><!-- wp:list-item --><li>Saturday 14 June · 11am-11:30am</li><!-- /wp:list-item --><!-- wp:list-item --><li>Wednesday 18 June · 5pm-5:30pm</li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Or book a private inspection</a></li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"35%","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50);flex-basis:35%">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt="Agent photo"/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Sarah Chen</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Principal · 12 years selling in Surry Hills</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Call agent</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
