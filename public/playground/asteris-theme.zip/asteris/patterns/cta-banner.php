<?php
/**
 * Title: CTA banner
 * Slug: asteris/cta-banner
 * Categories: asteris-page-sections, call-to-action, banner
 * Description: Full-width call-to-action banner on a brand colour background. Drop in before the footer to drive conversions.
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"3xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-3-xl-font-size"><?php echo esc_html_x( 'Ready to get started?', 'CTA banner headline', 'asteris' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","fontSize":"lg"} -->
	<p class="has-text-align-center has-lg-font-size"><?php echo esc_html_x( 'A persuasive one-liner that makes the next step obvious.', 'CTA banner subhead', 'asteris' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#"><?php echo esc_html_x( 'Get started today', 'CTA banner button', 'asteris' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
