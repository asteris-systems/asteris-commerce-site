<?php
/**
 * Title: Video showcase — embed-led hero
 * Slug: asteris/video-showcase
 * Categories: asteris-page-sections, featured
 * Description: Headline + supporting copy on the left, large video embed slot on the right. Drop a YouTube/Vimeo embed inside.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">WATCH THE STORY</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":2,"fontSize":"2xl"} --><h2 class="wp-block-heading has-2-xl-font-size">Three minutes to see it in action.</h2><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"lg","textColor":"muted"} --><p class="has-muted-color has-text-color has-lg-font-size">A short walkthrough of how it works, who it's for, and what changes when you ship it.</p><!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Start free trial</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:html -->
			<div style="aspect-ratio:16/9;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;">▶ Paste a YouTube or Vimeo URL here</div>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
