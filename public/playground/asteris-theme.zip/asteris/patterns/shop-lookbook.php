<?php
/**
 * Title: Lookbook — shop the look
 * Slug: asteris/shop-lookbook
 * Categories: asteris-shop, woo-commerce, featured
 * Description: Lifestyle hero image on top + four shoppable product cards beneath. For fashion, home, lifestyle stores.
 */
if ( ! class_exists( 'WooCommerce' ) ) { return; }
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
	<p class="has-muted-color has-text-color has-sm-font-size">LOOKBOOK · AUTUMN 2026</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-2-xl-font-size">Shop the look.</h2>
	<!-- /wp:heading -->

	<!-- wp:image -->
	<figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt="Editorial lifestyle shot"/></figure>
	<!-- /wp:image -->

	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#">Linen overshirt</a></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">$189</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#">Wool trousers</a></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">$249</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#">Leather belt</a></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">$95</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#">Suede loafer</a></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">$320</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
