<?php
/**
 * Title: Centered header with social icons
 * Slug: asteris/header-social-icons
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Site title centred, navigation below, social row at top-right. Publication / lifestyle.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:group {"layout":{"type":"flex","justifyContent":"right"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
	<div class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--30)">
		<!-- wp:social-links {"iconColor":"ink","iconColorValue":"#0a0a0a","size":"has-small-icon-size","className":"is-style-logos-only"} -->
		<ul class="wp-block-social-links has-small-icon-size has-icon-color is-style-logos-only">
			<!-- wp:social-link {"url":"#","service":"instagram"} /-->
			<!-- wp:social-link {"url":"#","service":"facebook"} /-->
			<!-- wp:social-link {"url":"#","service":"twitter"} /-->
			<!-- wp:social-link {"url":"#","service":"youtube"} /-->
		</ul>
		<!-- /wp:social-links -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"},"style":{"spacing":{"blockGap":"var:preset|spacing|30"}}} -->
	<div class="wp-block-group">
		<!-- wp:site-title {"level":0,"textAlign":"center","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.14em","fontWeight":"700","fontSize":"var:preset|font-size|xl"}}} /-->

		<!-- wp:navigation {"layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center"},"style":{"typography":{"fontSize":"var:preset|font-size|sm","letterSpacing":"0.06em"}}} /-->
	</div>
	<!-- /wp:group -->

</header>
<!-- /wp:group -->
