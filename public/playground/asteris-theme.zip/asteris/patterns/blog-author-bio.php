<?php
/**
 * Title: Author bio strip
 * Slug: asteris/blog-author-bio
 * Categories: asteris-blog
 * Description: Compact author card with avatar, name, bio, and link. Drop at the end of a post.
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="margin-top:var(--wp--preset--spacing--70);margin-bottom:var(--wp--preset--spacing--70);padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"96px"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:96px">
			<!-- wp:avatar {"size":80} /-->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
			<p class="has-muted-color has-text-color has-sm-font-size">WRITTEN BY</p>
			<!-- /wp:paragraph -->
			<!-- wp:post-author-name {"fontSize":"lg"} /-->
			<!-- wp:post-author-biography {"fontSize":"sm"} /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
