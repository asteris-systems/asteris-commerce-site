<?php
/**
 * Title: Services — Free / Basic tiers with checklist
 * Slug: asteris/services-tier-feature-list
 * Categories: asteris-page-sections, services
 * Description: Two service tiers side-by-side, dark "Get started" button, feature checklist beneath each.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"860px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"lg"} -->
	<h2 class="wp-block-heading has-text-align-center has-lg-font-size">Pricing</h2>
	<!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--50)">
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-text-align-center has-lg-font-size">Free</h3><!-- /wp:heading -->
			<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Get started</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ Browse the catalogue</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Save to wishlist</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Community forum access</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-text-align-center has-lg-font-size">Basic</h3><!-- /wp:heading -->
			<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Get started</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ Everything in Free</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ One design consultation</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Priority email support</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
