<?php
/**
 * Title: Logo cloud — customer / partner logos
 * Slug: asteris/logo-cloud
 * Categories: asteris-page-sections, featured
 * Description: A row of customer or partner logos. Drop in placeholder images and they become recognisable brand marks.
 */
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|sm","textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|50"}}}} -->
	<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--muted);margin-top:0;margin-bottom:var(--wp--preset--spacing--50);font-size:var(--wp--preset--font-size--sm);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Trusted by teams at</p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:image {"sizeSlug":"medium","align":"center"} -->
			<figure class="wp-block-image aligncenter size-medium"><img src="<?php echo $asteris_placeholder; ?>" alt="Customer logo placeholder"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:image {"sizeSlug":"medium","align":"center"} -->
			<figure class="wp-block-image aligncenter size-medium"><img src="<?php echo $asteris_placeholder; ?>" alt="Customer logo placeholder"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:image {"sizeSlug":"medium","align":"center"} -->
			<figure class="wp-block-image aligncenter size-medium"><img src="<?php echo $asteris_placeholder; ?>" alt="Customer logo placeholder"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:image {"sizeSlug":"medium","align":"center"} -->
			<figure class="wp-block-image aligncenter size-medium"><img src="<?php echo $asteris_placeholder; ?>" alt="Customer logo placeholder"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:image {"sizeSlug":"medium","align":"center"} -->
			<figure class="wp-block-image aligncenter size-medium"><img src="<?php echo $asteris_placeholder; ?>" alt="Customer logo placeholder"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:image {"sizeSlug":"medium","align":"center"} -->
			<figure class="wp-block-image aligncenter size-medium"><img src="<?php echo $asteris_placeholder; ?>" alt="Customer logo placeholder"/></figure>
			<!-- /wp:image -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
