<?php
/**
 * Title: Dark footer
 * Slug: asteris/footer-dark
 * Categories: asteris-footers, footer
 * Block Types: core/template-part/footer
 * Description: Full dark footer with two columns + social icons. Pairs naturally with the Dark header.
 */
?>
<!-- wp:group {"tagName":"footer","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|80"}},"color":{"background":"var:preset|color|ink","text":"var:preset|color|paper"}},"layout":{"type":"constrained"}} -->
<footer class="wp-block-group alignfull has-text-color has-background" style="background-color:var(--wp--preset--color--ink);color:var(--wp--preset--color--paper);margin-top:var(--wp--preset--spacing--80);padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70"}}}} -->
	<div class="wp-block-columns">

		<!-- wp:column {"width":"50%"} -->
		<div class="wp-block-column" style="flex-basis:50%">
			<!-- wp:site-title {"level":0,"style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em","fontWeight":"800","fontSize":"var:preset|font-size|xl"},"color":{"text":"var:preset|color|paper"}}} /-->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|sm","lineHeight":"1.6"},"color":{"text":"var:preset|color|paper"},"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
			<p class="has-text-color" style="color:var(--wp--preset--color--paper);margin-top:var(--wp--preset--spacing--30);font-size:var(--wp--preset--font-size--sm);line-height:1.6">A short tagline describing the site. Edit in the Site Editor.</p>
			<!-- /wp:paragraph -->

			<!-- wp:social-links {"iconColor":"paper","iconColorValue":"#ffffff","size":"has-small-icon-size","className":"is-style-logos-only","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
			<ul class="wp-block-social-links has-small-icon-size has-icon-color is-style-logos-only" style="margin-top:var(--wp--preset--spacing--40)">
				<!-- wp:social-link {"url":"#","service":"instagram"} /-->
				<!-- wp:social-link {"url":"#","service":"facebook"} /-->
				<!-- wp:social-link {"url":"#","service":"twitter"} /-->
				<!-- wp:social-link {"url":"#","service":"linkedin"} /-->
			</ul>
			<!-- /wp:social-links -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"25%"} -->
		<div class="wp-block-column" style="flex-basis:25%">
			<!-- wp:heading {"level":4,"fontSize":"xs","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|paper"},"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
			<h4 class="wp-block-heading has-text-color has-xs-font-size" style="color:var(--wp--preset--color--paper);margin-bottom:var(--wp--preset--spacing--30);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Explore</h4>
			<!-- /wp:heading -->
			<!-- wp:navigation {"textColor":"paper","overlayMenu":"never","layout":{"type":"flex","orientation":"vertical","setCascadingProperties":true},"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"spacing":{"blockGap":"var:preset|spacing|20"}}} /-->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"25%"} -->
		<div class="wp-block-column" style="flex-basis:25%">
			<!-- wp:heading {"level":4,"fontSize":"xs","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|paper"},"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
			<h4 class="wp-block-heading has-text-color has-xs-font-size" style="color:var(--wp--preset--color--paper);margin-bottom:var(--wp--preset--spacing--30);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Company</h4>
			<!-- /wp:heading -->
			<!-- wp:navigation {"textColor":"paper","overlayMenu":"never","layout":{"type":"flex","orientation":"vertical","setCascadingProperties":true},"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"spacing":{"blockGap":"var:preset|spacing|20"}}} /-->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

	<!-- wp:separator {"backgroundColor":"paper","style":{"color":{"background":"#ffffff"},"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}}} -->
	<hr class="wp-block-separator has-text-color has-paper-color has-alpha-channel-opacity has-paper-background-color has-background" style="background-color:#ffffff;color:#ffffff;margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--40)"/>
	<!-- /wp:separator -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|xs"},"color":{"text":"var:preset|color|paper"}}} -->
	<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--paper);font-size:var(--wp--preset--font-size--xs)">&copy; All rights reserved.</p>
	<!-- /wp:paragraph -->

</footer>
<!-- /wp:group -->
