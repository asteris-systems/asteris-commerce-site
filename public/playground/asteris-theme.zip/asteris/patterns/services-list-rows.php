<?php
/**
 * Title: Services — labelled rows
 * Slug: asteris/services-list-rows
 * Categories: asteris-page-sections, services
 * Description: Each row has a big label on the left and the service description on the right. Bold, easy to scan.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"width":"33%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:33%">
			<!-- wp:heading {"level":3,"fontSize":"xl"} --><h3 class="wp-block-heading has-xl-font-size">Installation</h3><!-- /wp:heading -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"67%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:67%">
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Two-person team, white-glove install. Average job under three hours.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#"><strong>Learn more →</strong></a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"width":"33%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:33%">
			<!-- wp:heading {"level":3,"fontSize":"xl"} --><h3 class="wp-block-heading has-xl-font-size">Maintenance</h3><!-- /wp:heading -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"67%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:67%">
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Annual service plan keeps everything working as the day it arrived.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#"><strong>Learn more →</strong></a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"width":"33%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:33%">
			<!-- wp:heading {"level":3,"fontSize":"xl"} --><h3 class="wp-block-heading has-xl-font-size">Trade-in</h3><!-- /wp:heading -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"67%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:67%">
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Refresh your pieces, return the old ones, get credit toward the new.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#"><strong>Learn more →</strong></a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"33%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:33%">
			<!-- wp:heading {"level":3,"fontSize":"xl"} --><h3 class="wp-block-heading has-xl-font-size">Support</h3><!-- /wp:heading -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"67%","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);flex-basis:67%">
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Talk to a real person within one business day. We answer every email.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#"><strong>Learn more →</strong></a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
