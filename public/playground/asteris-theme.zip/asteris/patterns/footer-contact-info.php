<?php
/**
 * Title: Footer with contact info block
 * Slug: asteris/footer-contact-info
 * Categories: asteris-footers, footer
 * Block Types: core/template-part/footer
 * Description: Address + phone + email + hours on the left, two link columns on the right. Local business / store.
 */
?>
<!-- wp:group {"tagName":"footer","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|80"}},"border":{"top":{"color":"var:preset|color|border","width":"1px"}}},"layout":{"type":"constrained"}} -->
<footer class="wp-block-group alignfull" style="border-top-color:var(--wp--preset--color--border);border-top-width:1px;margin-top:var(--wp--preset--spacing--80);padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70"}}}} -->
	<div class="wp-block-columns">

		<!-- wp:column {"width":"50%"} -->
		<div class="wp-block-column" style="flex-basis:50%">
			<!-- wp:site-title {"level":0,"style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em","fontWeight":"800","fontSize":"var:preset|font-size|lg"}}} /-->

			<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20","margin":{"top":"var:preset|spacing|40"}}}} -->
			<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--40)">
				<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|sm","lineHeight":"1.6"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
				<p class="has-text-color" style="color:var(--wp--preset--color--muted);margin-top:0;margin-bottom:0;font-size:var(--wp--preset--font-size--sm);line-height:1.6">123 Example Street<br>Suburb, State 2000<br>Australia</p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|sm","lineHeight":"1.6"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
				<p class="has-text-color" style="color:var(--wp--preset--color--muted);margin-top:0;margin-bottom:0;font-size:var(--wp--preset--font-size--sm);line-height:1.6"><a href="tel:+61000000000">+61 0 0000 0000</a><br><a href="mailto:hello@example.com">hello@example.com</a></p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|sm","lineHeight":"1.6"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"0"}}}} -->
				<p class="has-text-color" style="color:var(--wp--preset--color--muted);margin-top:var(--wp--preset--spacing--30);margin-bottom:0;font-size:var(--wp--preset--font-size--sm);line-height:1.6"><strong>Hours</strong><br>Mon–Fri 9–5 · Sat 10–4 · Sun closed</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"25%"} -->
		<div class="wp-block-column" style="flex-basis:25%">
			<!-- wp:heading {"level":4,"fontSize":"xs","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
			<h4 class="wp-block-heading has-text-color has-xs-font-size" style="color:var(--wp--preset--color--muted);margin-bottom:var(--wp--preset--spacing--30);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Shop</h4>
			<!-- /wp:heading -->
			<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical","setCascadingProperties":true},"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"spacing":{"blockGap":"var:preset|spacing|20"}}} /-->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"25%"} -->
		<div class="wp-block-column" style="flex-basis:25%">
			<!-- wp:heading {"level":4,"fontSize":"xs","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
			<h4 class="wp-block-heading has-text-color has-xs-font-size" style="color:var(--wp--preset--color--muted);margin-bottom:var(--wp--preset--spacing--30);text-transform:uppercase;letter-spacing:0.12em;font-weight:600">Help</h4>
			<!-- /wp:heading -->
			<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical","setCascadingProperties":true},"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"spacing":{"blockGap":"var:preset|spacing|20"}}} /-->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

	<!-- wp:separator {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}}} -->
	<hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--40)"/>
	<!-- /wp:separator -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|xs"},"color":{"text":"var:preset|color|muted"}}} -->
	<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--muted);font-size:var(--wp--preset--font-size--xs)">&copy; All rights reserved.</p>
	<!-- /wp:paragraph -->

</footer>
<!-- /wp:group -->
