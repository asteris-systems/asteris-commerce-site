<?php
/**
 * Title: Dark header
 * Slug: asteris/header-dark
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Full dark bar with light text. Dramatic, design-led — for studios, agencies, photography.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"color":{"background":"var:preset|color|ink","text":"var:preset|color|paper"}},"layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull has-text-color has-background" style="background-color:var(--wp--preset--color--ink);color:var(--wp--preset--color--paper);padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"nowrap"}} -->
	<div class="wp-block-group">
		<!-- wp:site-title {"level":0,"style":{"typography":{"fontWeight":"700","fontSize":"var:preset|font-size|md","textTransform":"uppercase","letterSpacing":"0.10em"},"color":{"text":"var:preset|color|paper"}}} /-->

		<!-- wp:navigation {"textColor":"paper","layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"right"},"style":{"typography":{"fontSize":"var:preset|font-size|sm"}}} /-->
	</div>
	<!-- /wp:group -->
</header>
<!-- /wp:group -->
