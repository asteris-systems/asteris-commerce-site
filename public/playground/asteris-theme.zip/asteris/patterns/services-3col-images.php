<?php
/**
 * Title: Services — 3-column cards with image on top
 * Slug: asteris/services-3col-images
 * Categories: asteris-page-sections, services, featured
 * Description: Three service cards, image on top, heading + description + link below.
 */
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Furniture customisation</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Tailor each piece to your space — finishes, dimensions, configurations.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#"><strong>Learn more →</strong></a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Interior design</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Work with our team on layout, lighting, materials. From a single room to a full home.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#"><strong>Learn more →</strong></a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Delivery &amp; assembly</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">White-glove delivery and full assembly — we leave nothing behind but the finished room.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><a href="#"><strong>Learn more →</strong></a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
