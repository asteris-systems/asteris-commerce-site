<?php
/**
 * Title: Transparent overlay header
 * Slug: asteris/header-transparent-overlay
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Sits on top of the hero image with white text. Use with a dark hero. Premium / DTC vibe.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"nowrap"}} -->
	<div class="wp-block-group">
		<!-- wp:site-title {"level":0,"style":{"typography":{"fontWeight":"700","fontSize":"var:preset|font-size|md","textTransform":"uppercase","letterSpacing":"0.08em"},"color":{"text":"var:preset|color|paper"}}} /-->

		<!-- wp:navigation {"textColor":"paper","layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"right"},"style":{"typography":{"fontSize":"var:preset|font-size|sm","letterSpacing":"0.04em"}}} /-->
	</div>
	<!-- /wp:group -->
</header>
<!-- /wp:group -->
