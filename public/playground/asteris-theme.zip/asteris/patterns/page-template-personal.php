<?php
/**
 * Title: Personal site — single page
 * Slug: asteris/page-template-personal
 * Categories: asteris-page-templates
 * Description: Single-page personal homepage — intro, what I do, recent writing, get in touch. For independents, writers, freelancers.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":1,"fontSize":"3xl"} --><h1 class="wp-block-heading has-3-xl-font-size">Hi, I'm Sarah.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"lg","textColor":"muted"} --><p class="has-muted-color has-text-color has-lg-font-size">I write about craft and the long game. Based in Sydney. Currently building <a href="#">a thing</a> and writing <a href="#">a newsletter</a>.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":2,"fontSize":"lg"} --><h2 class="wp-block-heading has-lg-font-size">Recent writing</h2><!-- /wp:heading -->
	<!-- wp:list -->
	<ul class="wp-block-list"><!-- wp:list-item --><li><a href="#">Building in public, ten years in</a> — June 2026</li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">The pricing mistakes we made twice</a> — May 2026</li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">When to ignore the advice</a> — April 2026</li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">The first year nobody talks about</a> — March 2026</li><!-- /wp:list-item --></ul>
	<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|90","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--90);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":2,"fontSize":"lg"} --><h2 class="wp-block-heading has-lg-font-size">Get in touch</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Email is best — <a href="mailto:hello@example.com">hello@example.com</a>. I'm slow but I always reply.</p><!-- /wp:paragraph -->
	<!-- wp:social-links {"size":"has-small-icon-size","className":"is-style-logos-only"} -->
	<ul class="wp-block-social-links has-small-icon-size is-style-logos-only">
		<!-- wp:social-link {"url":"#","service":"twitter"} /-->
		<!-- wp:social-link {"url":"#","service":"linkedin"} /-->
		<!-- wp:social-link {"url":"#","service":"github"} /-->
	</ul>
	<!-- /wp:social-links -->
</div>
<!-- /wp:group -->
