<?php
/**
 * Title: Hero with stats strip
 * Slug: asteris/hero-with-stats
 * Categories: asteris-heroes, asteris-page-sections, featured
 * Description: Centered hero headline + 4-column stats row beneath.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"3xl"} -->
	<h1 class="wp-block-heading has-text-align-center has-3-xl-font-size">Built for teams that ship.</h1>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">A short supporting line that explains what you do.</p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|70"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--70)">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} -->
			<h2 class="wp-block-heading has-text-align-center has-xl-font-size">10K+</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Active customers</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} -->
			<h2 class="wp-block-heading has-text-align-center has-xl-font-size">99.9%</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Uptime</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} -->
			<h2 class="wp-block-heading has-text-align-center has-xl-font-size">4.9★</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Average rating</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} -->
			<h2 class="wp-block-heading has-text-align-center has-xl-font-size">24/7</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Support</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

</div>
<!-- /wp:group -->
