<?php
/**
 * Title: Hero — video / image background
 * Slug: asteris/hero-video-bg
 * Categories: asteris-heroes, asteris-page-sections
 * Description: Cover-block hero — set a background image or video in the editor. Centered light text on a dimmed overlay.
 */
?>
<!-- wp:cover {"dimRatio":50,"overlayColor":"ink","minHeight":520,"minHeightUnit":"px","align":"full","contentPosition":"center center"} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-center" style="min-height:520px">
	<span aria-hidden="true" class="wp-block-cover__background has-ink-background-color has-background-dim-50 has-background-dim"></span>
	<div class="wp-block-cover__inner-container">
		<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"4xl","textColor":"paper"} -->
		<h1 class="wp-block-heading has-text-align-center has-paper-color has-text-color has-4-xl-font-size">Pictures tell the story.</h1>
		<!-- /wp:heading -->
		<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"paper"} -->
		<p class="has-text-align-center has-paper-color has-text-color has-lg-font-size">Click the cover block in the editor and add a background image or video.</p>
		<!-- /wp:paragraph -->
		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">See the work</a></div><!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
</div>
<!-- /wp:cover -->
