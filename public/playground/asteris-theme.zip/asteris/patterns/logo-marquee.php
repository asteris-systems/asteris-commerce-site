<?php
/**
 * Title: Logo marquee — scrolling logos
 * Slug: asteris/logo-marquee
 * Categories: asteris-page-sections
 * Description: Horizontal scrolling band of company logos. Pure CSS animation — no JavaScript required.
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">TRUSTED BY 10,000+ TEAMS</p>
	<!-- /wp:paragraph -->
	<!-- wp:html -->
	<div class="asteris-marquee" style="overflow:hidden;mask-image:linear-gradient(to right, transparent, black 10%, black 90%, transparent);">
		<div style="display:flex;gap:4rem;animation:asteris-marquee 30s linear infinite;width:max-content;padding:1.5rem 0;font-weight:700;font-size:1.25rem;">
			<span>Northwind</span><span>Lattice</span><span>Stratafield</span><span>Pinnacle</span><span>Marlowe</span><span>Vector</span><span>Northwind</span><span>Lattice</span><span>Stratafield</span><span>Pinnacle</span><span>Marlowe</span><span>Vector</span>
		</div>
		<style>@keyframes asteris-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}</style>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
