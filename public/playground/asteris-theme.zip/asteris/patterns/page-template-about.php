<?php
/**
 * Title: About page — full starter
 * Slug: asteris/page-template-about
 * Categories: asteris-page-templates
 * Description: Complete About page: mission hero, story, values, team grid, CTA.
 */
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">ABOUT US</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"3xl"} -->
	<h1 class="wp-block-heading has-text-align-center has-3-xl-font-size">Building tools we wish existed.</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">A single-sentence summary of who you are and what you believe.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":2,"fontSize":"xl"} -->
	<h2 class="wp-block-heading has-xl-font-size">Our story.</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Tell the story of why you started. What were you trying to fix? Who was hurting from the status quo? Lead with the customer pain, then the founding decision.</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p>Add a second paragraph about the early days — the first hire, the first customer, the lesson that shaped the company. Real specifics beat polished marketing every time.</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph -->
	<p>Close with where you are now and where you're headed. Make it concrete: numbers, products, the next twelve months.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">What we value.</h2>
	<!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Honesty</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">We say what we mean. No dark patterns, no inflated claims, no hiding the trade-offs.</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Craft</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">We sweat the details others skip. Performance, accessibility, the small UX moments.</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Patience</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">We're building something that lasts decades. We're not in a hurry.</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">The team.</h2>
	<!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Sarah Chen</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Founder &amp; CEO</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Alex Morgan</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Engineering</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Priya Iyer</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Design</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Jack Williams</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Support</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
