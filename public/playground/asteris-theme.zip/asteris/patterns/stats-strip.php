<?php
/**
 * Title: Stats strip — 4 big numbers
 * Slug: asteris/stats-strip
 * Categories: asteris-page-sections, featured
 * Description: Standalone 4-column stats band on a subtle background.
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"3xl"} -->
			<h3 class="wp-block-heading has-text-align-center has-3-xl-font-size">$2.4M</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Saved by customers</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"3xl"} -->
			<h3 class="wp-block-heading has-text-align-center has-3-xl-font-size">120K</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Sites running</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"3xl"} -->
			<h3 class="wp-block-heading has-text-align-center has-3-xl-font-size">4.9/5</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Customer rating</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"3xl"} -->
			<h3 class="wp-block-heading has-text-align-center has-3-xl-font-size">12 yrs</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">In business</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
