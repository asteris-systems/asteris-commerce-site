<?php
/**
 * Title: Podcast episode — single episode hero
 * Slug: asteris/podcast-episode
 * Categories: asteris-page-sections, asteris-blog
 * Description: Single podcast-episode page — cover art, episode meta, audio player slot, show notes.
 */
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt="Episode artwork"/></figure><!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">EPISODE 47 · 48 MIN</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"2xl"} --><h1 class="wp-block-heading has-2-xl-font-size">Building in public, ten years in.</h1><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"md","textColor":"muted"} --><p class="has-muted-color has-text-color has-md-font-size">With Sarah Chen. We talk about long-game founder energy, the seasons of a startup, and what changes when you finally start trusting your instincts.</p><!-- /wp:paragraph -->
			<!-- wp:html -->
			<div style="background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;padding:1rem 1.5rem;min-height:54px;">🎵 Paste an audio file URL or podcast embed here</div>
			<!-- /wp:html -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Apple</a></div><!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Spotify</a></div><!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">RSS</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-xl-font-size">Show notes</h2><!-- /wp:heading -->
	<!-- wp:list -->
	<ul class="wp-block-list"><!-- wp:list-item --><li>00:00 — Cold open</li><!-- /wp:list-item --><!-- wp:list-item --><li>02:18 — The first year nobody talks about</li><!-- /wp:list-item --><!-- wp:list-item --><li>14:30 — Pricing mistakes we made twice</li><!-- /wp:list-item --><!-- wp:list-item --><li>27:00 — When to ignore the advice</li><!-- /wp:list-item --><!-- wp:list-item --><li>41:15 — Closing thoughts</li><!-- /wp:list-item --></ul>
	<!-- /wp:list -->
</div>
<!-- /wp:group -->
