<?php
/**
 * Title: Hero — announcement pill + headline
 * Slug: asteris/hero-2-cta-pill
 * Categories: asteris-heroes, asteris-page-sections
 * Description: Small announcement pill above the headline (great for "What's new" or version launches), then dual CTAs.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|90","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--90);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"className":"is-style-outline","fontSize":"sm"} -->
		<div class="wp-block-button is-style-outline has-custom-font-size has-sm-font-size"><a class="wp-block-button__link wp-element-button" href="#">✨ New: v3.0 is here →</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"4xl","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
	<h1 class="wp-block-heading has-text-align-center has-4-xl-font-size" style="margin-top:var(--wp--preset--spacing--40)">Built for the way you actually work.</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">Replaces six tools, costs less than one, and you'll be set up in an afternoon.</p>
	<!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Start free trial</a></div><!-- /wp:button -->
		<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Watch the demo</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
