<?php
/**
 * Title: Minimal header
 * Slug: asteris/header-minimal
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Just the site title. Maximum restraint — for publications and editorial sites.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:site-title {"level":0,"style":{"typography":{"fontWeight":"600","fontSize":"var:preset|font-size|md"}}} /-->
</header>
<!-- /wp:group -->
