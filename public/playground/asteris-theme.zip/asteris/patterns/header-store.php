<?php
/**
 * Title: Store header (logo + nav + account/cart)
 * Slug: asteris/header-store
 * Categories: asteris-headers, header, woo-commerce
 * Block Types: core/template-part/header
 * Description: Logo left, navigation centre, account icon + mini-cart icon tight together on the right. The default e-commerce header — drop in and trade.
 *
 * NOTE: Contains a Mini-Cart block, which WordPress only allows once per page.
 * If you insert this pattern into a template that already has a Mini-Cart
 * elsewhere, remove the duplicate.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px"}}},"layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"nowrap"}} -->
	<div class="wp-block-group">

		<!-- wp:site-title {"level":0,"style":{"typography":{"fontWeight":"800","fontSize":"var:preset|font-size|lg","textTransform":"uppercase","letterSpacing":"0.06em"}}} /-->

		<!-- wp:navigation {"layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center"},"style":{"typography":{"fontSize":"var:preset|font-size|sm"}}} /-->

		<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"},"style":{"spacing":{"blockGap":"var:preset|spacing|30"}}} -->
		<div class="wp-block-group">
			<!-- wp:woocommerce/customer-account {"displayStyle":"icon_only","iconStyle":"line","iconClass":""} /-->

			<!-- wp:woocommerce/mini-cart {"hasHiddenPrice":true} /-->
		</div>
		<!-- /wp:group -->

	</div>
	<!-- /wp:group -->

</header>
<!-- /wp:group -->
