<?php
/**
 * Title: Blog post header
 * Slug: asteris/blog-post-header
 * Categories: asteris-blog
 * Description: Single-post intro: category, title, date and author meta. Drop above the post content.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:post-terms {"term":"category","textAlign":"center","fontSize":"sm","textColor":"muted"} /-->
	<!-- wp:post-title {"textAlign":"center","level":1,"fontSize":"3xl"} /-->
	<!-- wp:group {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-group">
		<!-- wp:post-author-name {"fontSize":"sm"} /-->
		<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">·</p><!-- /wp:paragraph -->
		<!-- wp:post-date {"fontSize":"sm","textColor":"muted"} /-->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
