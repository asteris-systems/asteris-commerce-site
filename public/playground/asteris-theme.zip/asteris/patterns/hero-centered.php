<?php
/**
 * Title: Centered hero with CTA
 * Slug: asteris/hero-centered
 * Categories: asteris-page-sections, featured, call-to-action
 * Description: Large centred headline, supporting paragraph, primary + secondary buttons. The default homepage hero.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|90","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--90);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group">

		<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"4xl","style":{"typography":{"lineHeight":"1.05","letterSpacing":"-0.02em","fontWeight":"700"}}} -->
		<h1 class="wp-block-heading has-text-align-center has-4-xl-font-size" style="font-weight:700;letter-spacing:-0.02em;line-height:1.05"><?php echo esc_html_x( 'Build something better.', 'Default centred hero headline', 'asteris' ); ?></h1>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|lg"},"color":{"text":"var:preset|color|muted"}}} -->
		<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--muted);font-size:var(--wp--preset--font-size--lg)"><?php echo esc_html_x( 'A concise supporting line that explains what you do and why it matters. Edit this in the Site Editor.', 'Default centred hero subhead', 'asteris' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|30"}}} -->
		<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)">
			<!-- wp:button {"className":"is-style-fill"} -->
			<div class="wp-block-button is-style-fill"><a class="wp-block-button__link wp-element-button" href="#"><?php echo esc_html_x( 'Get started', 'Default hero primary CTA', 'asteris' ); ?></a></div>
			<!-- /wp:button -->

			<!-- wp:button {"className":"is-style-outline"} -->
			<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#"><?php echo esc_html_x( 'Learn more', 'Default hero secondary CTA', 'asteris' ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->

	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
