<?php
/**
 * Title: Bundle — complete the look
 * Slug: asteris/shop-bundle
 * Categories: asteris-shop, woo-commerce
 * Description: Three products grouped as a bundle with a single bundle price and "Save $X" tag. Strong AOV lift.
 */
if ( ! class_exists( 'WooCommerce' ) ) { return; }
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">THE STARTER SET · SAVE $40</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">Complete the routine.</h2>
	<!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center"><strong>Cleanser</strong></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">$45</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center"><strong>Serum</strong></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">$85</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center"><strong>Moisturiser</strong></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">$65</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
	<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--50)">
		<!-- wp:paragraph {"align":"center","fontSize":"3xl"} -->
		<p class="has-text-align-center has-3-xl-font-size"><strong>$155</strong></p>
		<!-- /wp:paragraph -->
		<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
		<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Regular price $195 · You save $40</p>
		<!-- /wp:paragraph -->
		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Add bundle to cart</a></div><!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
