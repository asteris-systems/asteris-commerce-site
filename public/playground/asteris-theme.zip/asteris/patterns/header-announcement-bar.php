<?php
/**
 * Title: Header with announcement bar
 * Slug: asteris/header-announcement-bar
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Promo strip on top (Free shipping, etc.) + main header below. DTC startup vibe.
 */
?>
<!-- wp:group {"tagName":"header","align":"full"} -->
<header class="wp-block-group alignfull">

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"color":{"background":"var:preset|color|ink","text":"var:preset|color|paper"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignfull has-text-color has-background" style="background-color:var(--wp--preset--color--ink);color:var(--wp--preset--color--paper);padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|xs","letterSpacing":"0.04em"},"color":{"text":"var:preset|color|paper"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
		<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--paper);margin-top:0;margin-bottom:0;font-size:var(--wp--preset--font-size--xs);letter-spacing:0.04em"><?php echo esc_html_x( 'Free shipping on orders over $75 · 30-day returns', 'Default announcement bar', 'asteris' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px"}}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"nowrap"}} -->
		<div class="wp-block-group">
			<!-- wp:site-title {"level":0,"style":{"typography":{"fontWeight":"700","fontSize":"var:preset|font-size|md"}}} /-->

			<!-- wp:navigation {"layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"right"},"style":{"typography":{"fontSize":"var:preset|font-size|sm"}}} /-->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

</header>
<!-- /wp:group -->
