<?php
/**
 * Title: Wedding — save-the-date / event page
 * Slug: asteris/page-template-wedding
 * Categories: asteris-page-templates
 * Description: Single-page wedding microsite — couple names, date, story, schedule, location, RSVP.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">SAVE THE DATE</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"4xl"} --><h1 class="wp-block-heading has-text-align-center has-4-xl-font-size">Sarah &amp; Tom</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">15 March 2027 · Byron Bay, Australia</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">RSVP</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"600px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-text-align-center has-xl-font-size">Our story</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>We met at a coffee shop in Newtown in 2019. Tom was reading the same book Sarah had just finished. Six years, two cities, and one very patient dog later, we're getting married.</p><!-- /wp:paragraph -->
	<!-- wp:paragraph --><p>We'd love you to be there. Bring comfortable shoes — there will be dancing.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"600px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-text-align-center has-xl-font-size">The day</h2><!-- /wp:heading -->
	<!-- wp:list -->
	<ul class="wp-block-list"><!-- wp:list-item --><li><strong>3:00pm</strong> — Ceremony · Beachfront lawn</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>4:00pm</strong> — Drinks &amp; canapés · Garden terrace</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>6:30pm</strong> — Dinner · The Pavilion</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>9:00pm</strong> — Dancing · Until late</li><!-- /wp:list-item --></ul>
	<!-- /wp:list -->
</div>
<!-- /wp:group -->
