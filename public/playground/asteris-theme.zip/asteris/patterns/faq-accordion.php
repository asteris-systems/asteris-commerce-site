<?php
/**
 * Title: FAQ accordion section
 * Slug: asteris/faq-accordion
 * Categories: asteris-page-sections, featured
 * Description: Expandable Q&A items using native core/details blocks.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">Frequently asked questions.</h2>
	<!-- /wp:heading -->

	<!-- wp:details -->
	<details class="wp-block-details"><summary>How does it work?</summary>
		<!-- wp:paragraph -->
		<p>Replace this with the answer. Keep it to 2-4 sentences.</p>
		<!-- /wp:paragraph -->
	</details>
	<!-- /wp:details -->

	<!-- wp:details -->
	<details class="wp-block-details"><summary>Can I cancel anytime?</summary>
		<!-- wp:paragraph -->
		<p>Yes. Cancel from your account page; no calls, no emails.</p>
		<!-- /wp:paragraph -->
	</details>
	<!-- /wp:details -->

	<!-- wp:details -->
	<details class="wp-block-details"><summary>Do you offer refunds?</summary>
		<!-- wp:paragraph -->
		<p>Yes — full refund within 30 days. No conditions.</p>
		<!-- /wp:paragraph -->
	</details>
	<!-- /wp:details -->

	<!-- wp:details -->
	<details class="wp-block-details"><summary>What's included in support?</summary>
		<!-- wp:paragraph -->
		<p>Email support on all plans. Pro and Agency get priority queue.</p>
		<!-- /wp:paragraph -->
	</details>
	<!-- /wp:details -->

	<!-- wp:details -->
	<details class="wp-block-details"><summary>How is my data handled?</summary>
		<!-- wp:paragraph -->
		<p>Edit this answer to describe your privacy + data handling.</p>
		<!-- /wp:paragraph -->
	</details>
	<!-- /wp:details -->

</div>
<!-- /wp:group -->
