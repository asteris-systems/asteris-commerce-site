<?php
/**
 * Title: Roadmap — quarterly bands
 * Slug: asteris/roadmap-quarterly
 * Categories: asteris-page-sections
 * Description: Four quarterly columns showing what's shipping next. For public roadmap pages.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":2,"fontSize":"2xl"} --><h2 class="wp-block-heading has-2-xl-font-size">What we're building.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"md","textColor":"muted"} --><p class="has-muted-color has-text-color has-md-font-size">Subject to change — but rarely does. Want to help shape what's next? <a href="#">Vote on features</a>.</p><!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|40","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">SHIPPED</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Q2 2026</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ SAML SSO</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Audit log</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Bulk operations</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|40","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">SHIPPING NOW</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Q3 2026</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>· AI-powered search</li><!-- /wp:list-item --><!-- wp:list-item --><li>· Mobile app v2</li><!-- /wp:list-item --><!-- wp:list-item --><li>· Webhooks v2</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|40","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">PLANNED</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Q4 2026</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>· Custom roles</li><!-- /wp:list-item --><!-- wp:list-item --><li>· Workspace export</li><!-- /wp:list-item --><!-- wp:list-item --><li>· Public API v3</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|40","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">CONSIDERING</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Q1 2027</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>· Native iPad app</li><!-- /wp:list-item --><!-- wp:list-item --><li>· Vendor marketplace</li><!-- /wp:list-item --><!-- wp:list-item --><li>· Workflow automation</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
