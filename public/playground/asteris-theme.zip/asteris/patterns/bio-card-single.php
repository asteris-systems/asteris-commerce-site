<?php
/**
 * Title: Bio card — single person
 * Slug: asteris/bio-card-single
 * Categories: asteris-page-sections, asteris-blog
 * Description: Square photo, name, role, bio paragraph, social links. For guest authors, single team members, speaker bios.
 */
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"35%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:35%">
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"65%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:65%">
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">FOUNDER &amp; CEO</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-xl-font-size">Sarah Chen</h2><!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Sarah has spent twelve years building products that respect the user's time. Previously at Stripe and Notion, she now leads the team and writes occasionally about craft and the long game.</p><!-- /wp:paragraph -->
			<!-- wp:social-links {"size":"has-small-icon-size","className":"is-style-logos-only"} -->
			<ul class="wp-block-social-links has-small-icon-size is-style-logos-only">
				<!-- wp:social-link {"url":"#","service":"twitter"} /-->
				<!-- wp:social-link {"url":"#","service":"linkedin"} /-->
				<!-- wp:social-link {"url":"#","service":"github"} /-->
			</ul>
			<!-- /wp:social-links -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
