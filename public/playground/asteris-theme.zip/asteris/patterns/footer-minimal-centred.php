<?php
/**
 * Title: Minimal centred footer
 * Slug: asteris/footer-minimal-centred
 * Categories: asteris-footers, footer
 * Block Types: core/template-part/footer
 * Description: Just the site title + copyright. Maximum restraint — pairs with the minimal header.
 */
?>
<!-- wp:group {"tagName":"footer","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|80"}},"border":{"top":{"color":"var:preset|color|border","width":"1px"}}},"layout":{"type":"constrained"}} -->
<footer class="wp-block-group alignfull" style="border-top-color:var(--wp--preset--color--border);border-top-width:1px;margin-top:var(--wp--preset--spacing--80);padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"},"style":{"spacing":{"blockGap":"var:preset|spacing|30"}}} -->
	<div class="wp-block-group">
		<!-- wp:site-title {"level":0,"textAlign":"center","isLink":false,"style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"700","fontSize":"var:preset|font-size|md"}}} /-->

		<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|xs"},"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
		<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--muted);margin-top:0;margin-bottom:0;font-size:var(--wp--preset--font-size--xs)">&copy; All rights reserved.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</footer>
<!-- /wp:group -->
