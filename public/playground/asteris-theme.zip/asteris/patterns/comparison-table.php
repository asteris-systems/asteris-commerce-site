<?php
/**
 * Title: Comparison table — us vs them
 * Slug: asteris/comparison-table
 * Categories: asteris-page-sections, featured
 * Description: 3-column comparison: feature, you, competitor. Drop into landing pages.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">How we compare.</h2>
	<!-- /wp:heading -->
	<!-- wp:table {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<figure class="wp-block-table" style="margin-top:var(--wp--preset--spacing--60)"><table><thead><tr><th>Feature</th><th>Asteris</th><th>Others</th></tr></thead><tbody><tr><td>Setup time</td><td>5 minutes</td><td>1-2 hours</td></tr><tr><td>Pricing tiers</td><td>Three honest plans</td><td>Six confusing ones</td></tr><tr><td>Support</td><td>Real humans, 2-day SLA</td><td>Chatbot maze</td></tr><tr><td>Hidden fees</td><td>None</td><td>Usually</td></tr><tr><td>Cancel anytime</td><td>One click</td><td>Phone call required</td></tr></tbody></table></figure>
	<!-- /wp:table -->
</div>
<!-- /wp:group -->
