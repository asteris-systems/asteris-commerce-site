<?php
/**
 * Title: Contact page — full starter
 * Slug: asteris/page-template-contact
 * Categories: asteris-page-templates
 * Description: Complete contact page: hero, contact details + form placeholder, alternative channels.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"3xl"} -->
	<h1 class="wp-block-heading has-text-align-center has-3-xl-font-size">Talk to us.</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">We reply within 2 business days. For urgent matters, use the priority channels below.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-xl-font-size">Get in touch.</h2><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><strong>Email</strong><br><a href="mailto:hello@example.com">hello@example.com</a></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><strong>Phone</strong><br>+61 0 0000 0000</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><strong>Address</strong><br>123 Example Street<br>Suburb, State 2000</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size"><strong>Hours</strong><br>Mon-Fri 9-5 AEST</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|60"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
			<!-- wp:heading {"level":2,"fontSize":"lg"} --><h2 class="wp-block-heading has-lg-font-size">Send a message.</h2><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Drop your contact form here. Asteris is form-plugin agnostic — works with WPForms, Gravity Forms, Fluent Forms, Contact Form 7, or Asteris Forms.</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
