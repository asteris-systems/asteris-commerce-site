<?php
/**
 * Title: Comparison — detailed vs competitor
 * Slug: asteris/comparison-detailed
 * Categories: asteris-page-sections, featured
 * Description: Full feature comparison table. For "vs [Competitor]" landing pages.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} --><h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">How we compare.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"md","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-md-font-size">An honest side-by-side. Last updated June 2026.</p><!-- /wp:paragraph -->

	<!-- wp:table {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<figure class="wp-block-table" style="margin-top:var(--wp--preset--spacing--60)"><table><thead><tr><th>Feature</th><th><strong>Asteris</strong></th><th>Competitor A</th><th>Competitor B</th></tr></thead><tbody><tr><td>Starting price</td><td><strong>$19/mo</strong></td><td>$29/mo</td><td>$39/mo</td></tr><tr><td>Free trial</td><td>14 days, no card</td><td>7 days, card required</td><td>No</td></tr><tr><td>Setup time</td><td>Under 1 hour</td><td>1-2 days</td><td>1+ week</td></tr><tr><td>Single sign-on (SAML)</td><td>✓ Included on Agency</td><td>Enterprise add-on</td><td>Enterprise add-on</td></tr><tr><td>Audit log</td><td>✓</td><td>✓</td><td>—</td></tr><tr><td>API + webhooks</td><td>✓ REST + GraphQL</td><td>REST only</td><td>—</td></tr><tr><td>Native mobile apps</td><td>iOS &amp; Android</td><td>iOS only</td><td>—</td></tr><tr><td>Public roadmap</td><td>✓</td><td>—</td><td>—</td></tr><tr><td>Support SLA</td><td>2 business days</td><td>5 business days</td><td>Ticket-only</td></tr><tr><td>Money-back guarantee</td><td>30 days</td><td>—</td><td>—</td></tr></tbody></table></figure>
	<!-- /wp:table -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Start free trial</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
