<?php
/**
 * Title: Best sellers — ranked top 3
 * Slug: asteris/shop-best-sellers-ranked
 * Categories: asteris-shop, woo-commerce, featured
 * Description: Top three products with #1 / #2 / #3 rankings and "X sold this week" badge.
 */
if ( ! class_exists( 'WooCommerce' ) ) { return; }
?>
<?php $asteris_placeholder = esc_url( get_template_directory_uri() . '/assets/placeholder.svg' ); ?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">This week's top three.</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"md","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-md-font-size">What customers are buying right now.</p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"fontSize":"3xl"} --><p class="has-3-xl-font-size"><strong>#1</strong></p><!-- /wp:paragraph -->
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph --><p><strong>The signature scent</strong></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">$89 · 247 sold this week</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"fontSize":"3xl"} --><p class="has-3-xl-font-size"><strong>#2</strong></p><!-- /wp:paragraph -->
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph --><p><strong>Hand cream</strong></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">$28 · 198 sold this week</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"fontSize":"3xl"} --><p class="has-3-xl-font-size"><strong>#3</strong></p><!-- /wp:paragraph -->
			<!-- wp:image {"url":"<?php echo $asteris_placeholder; ?>"} --><figure class="wp-block-image"><img src="<?php echo $asteris_placeholder; ?>" alt=""/></figure><!-- /wp:image -->
			<!-- wp:paragraph --><p><strong>Bath oil</strong></p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">$54 · 156 sold this week</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
