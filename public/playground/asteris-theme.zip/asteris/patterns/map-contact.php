<?php
/**
 * Title: Map + contact details
 * Slug: asteris/map-contact
 * Categories: asteris-page-sections, contact
 * Description: Large map embed slot on the left, address and hours on the right. For physical-location businesses.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%">
			<!-- wp:html -->
			<div style="background:#f5f5f5;aspect-ratio:16/10;display:flex;align-items:center;justify-content:center;color:#999;border-radius:4px;">Paste a Google Maps embed iframe here</div>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
			<!-- wp:heading {"level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-xl-font-size">Visit us.</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p><strong>Address</strong><br>123 Example Street<br>Surry Hills, NSW 2010<br>Australia</p><!-- /wp:paragraph -->
			<!-- wp:paragraph --><p><strong>Hours</strong><br>Mon-Fri 9am-6pm<br>Sat 10am-4pm<br>Sun closed</p><!-- /wp:paragraph -->
			<!-- wp:paragraph --><p><strong>Phone</strong><br><a href="tel:+61200000000">+61 2 0000 0000</a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
