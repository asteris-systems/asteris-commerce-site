<?php
/**
 * Title: Hero — opens with a quote
 * Slug: asteris/hero-quote-led
 * Categories: asteris-heroes, asteris-page-sections
 * Description: Lead with a big quote from a credible source, then the headline. For thought-leadership / agency / writer brands.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|90","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--90);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:paragraph {"align":"center","fontSize":"2xl"} -->
	<p class="has-text-align-center has-2-xl-font-size">&ldquo;The most refreshing voice in the space.&rdquo;</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">— THE NEW YORK TIMES</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"3xl","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<h1 class="wp-block-heading has-text-align-center has-3-xl-font-size" style="margin-top:var(--wp--preset--spacing--60)">A different way to think about it.</h1>
	<!-- /wp:heading -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Read the manifesto</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
