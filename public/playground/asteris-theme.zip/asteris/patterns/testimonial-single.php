<?php
/**
 * Title: Testimonial — single centred quote
 * Slug: asteris/testimonial-single
 * Categories: asteris-page-sections, featured
 * Description: One quote, big, centred.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|90","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--90);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:paragraph {"align":"center","fontSize":"2xl"} -->
	<p class="has-text-align-center has-2-xl-font-size">&ldquo;The single best decision we made all year. We saved 20 hours a week and the team is finally working on the right things.&rdquo;</p>
	<!-- /wp:paragraph -->

	<!-- wp:paragraph {"align":"center","fontSize":"md"} -->
	<p class="has-text-align-center has-md-font-size"><strong>Sarah Chen</strong></p>
	<!-- /wp:paragraph -->

	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Head of Ops · Lattice Studio</p>
	<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->
