<?php
/**
 * Title: Changelog — dated entries
 * Slug: asteris/changelog
 * Categories: asteris-page-sections, asteris-blog, posts
 * Description: Versioned release notes — date, version, short summary, bullet list. For changelog pages and "what's new" sections.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"level":1,"fontSize":"3xl"} --><h1 class="wp-block-heading has-3-xl-font-size">Changelog.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"lg","textColor":"muted"} --><p class="has-muted-color has-text-color has-lg-font-size">Everything we've shipped, in reverse order.</p><!-- /wp:paragraph -->

	<!-- wp:separator {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} --><hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60)"/><!-- /wp:separator -->

	<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">9 JUNE 2026 · <strong>v2.4</strong></p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-xl-font-size">Bulk operations + CSV export</h2><!-- /wp:heading -->
	<!-- wp:list -->
	<ul class="wp-block-list"><!-- wp:list-item --><li>Select multiple items and update them in one click.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Export any list view to CSV — keyboard shortcut <code>⌘E</code>.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Performance: list views render 3× faster on large datasets.</li><!-- /wp:list-item --></ul>
	<!-- /wp:list -->

	<!-- wp:separator {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} --><hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60)"/><!-- /wp:separator -->

	<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">23 MAY 2026 · <strong>v2.3</strong></p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-xl-font-size">SAML SSO + audit log</h2><!-- /wp:heading -->
	<!-- wp:list -->
	<ul class="wp-block-list"><!-- wp:list-item --><li>SAML 2.0 + SCIM provisioning for the Agency plan.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Full audit log — searchable, exportable, retention configurable.</li><!-- /wp:list-item --></ul>
	<!-- /wp:list -->

	<!-- wp:separator {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} --><hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60)"/><!-- /wp:separator -->

	<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">2 MAY 2026 · <strong>v2.2</strong></p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":2,"fontSize":"xl"} --><h2 class="wp-block-heading has-xl-font-size">New: native mobile apps</h2><!-- /wp:heading -->
	<!-- wp:list -->
	<ul class="wp-block-list"><!-- wp:list-item --><li>iOS + Android apps are out of beta.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Offline mode included on both platforms.</li><!-- /wp:list-item --></ul>
	<!-- /wp:list -->
</div>
<!-- /wp:group -->
