<?php
/**
 * Title: Pricing — 3-tier minimal
 * Slug: asteris/pricing-minimal
 * Categories: asteris-page-sections, featured
 * Description: Three sparse pricing tiers. Big price, name, single sentence, CTA.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">Simple pricing.</h2>
	<!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|70"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--70)">

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"md","textColor":"muted"} -->
			<h3 class="wp-block-heading has-text-align-center has-muted-color has-text-color has-md-font-size">Starter</h3>
			<!-- /wp:heading -->
			<!-- wp:heading {"textAlign":"center","level":4,"fontSize":"3xl"} -->
			<h4 class="wp-block-heading has-text-align-center has-3-xl-font-size">$19</h4>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">per month. For getting started.</p>
			<!-- /wp:paragraph -->
			<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
			<div class="wp-block-buttons">
				<!-- wp:button {"className":"is-style-outline"} -->
				<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Starter</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|40","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-text-align-center has-md-font-size">Pro</h3>
			<!-- /wp:heading -->
			<!-- wp:heading {"textAlign":"center","level":4,"fontSize":"3xl"} -->
			<h4 class="wp-block-heading has-text-align-center has-3-xl-font-size">$49</h4>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">per month. For most teams.</p>
			<!-- /wp:paragraph -->
			<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
			<div class="wp-block-buttons">
				<!-- wp:button -->
				<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Choose Pro</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"md","textColor":"muted"} -->
			<h3 class="wp-block-heading has-text-align-center has-muted-color has-text-color has-md-font-size">Agency</h3>
			<!-- /wp:heading -->
			<!-- wp:heading {"textAlign":"center","level":4,"fontSize":"3xl"} -->
			<h4 class="wp-block-heading has-text-align-center has-3-xl-font-size">$149</h4>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
			<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">per month. For agencies.</p>
			<!-- /wp:paragraph -->
			<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
			<div class="wp-block-buttons">
				<!-- wp:button {"className":"is-style-outline"} -->
				<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Agency</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
