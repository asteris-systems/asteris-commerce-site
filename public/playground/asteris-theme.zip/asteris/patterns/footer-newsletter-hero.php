<?php
/**
 * Title: Newsletter signup footer
 * Slug: asteris/footer-newsletter-hero
 * Categories: asteris-footers, footer
 * Block Types: core/template-part/footer
 * Description: Big newsletter subscribe block + thin nav/copyright bar beneath. DTC / SaaS — drives email signups.
 */
?>
<!-- wp:group {"tagName":"footer","align":"full","style":{"spacing":{"margin":{"top":"var:preset|spacing|80"}}}} -->
<footer class="wp-block-group alignfull" style="margin-top:var(--wp--preset--spacing--80)">

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"color":{"background":"var:preset|color|ink","text":"var:preset|color|paper"}},"layout":{"type":"constrained","contentSize":"640px"}} -->
	<div class="wp-block-group alignfull has-text-color has-background" style="background-color:var(--wp--preset--color--ink);color:var(--wp--preset--color--paper);padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl","style":{"color":{"text":"var:preset|color|paper"},"typography":{"fontWeight":"700","letterSpacing":"-0.02em"}}} -->
		<h2 class="wp-block-heading has-text-align-center has-text-color has-2-xl-font-size" style="color:var(--wp--preset--color--paper);font-weight:700;letter-spacing:-0.02em">Join the newsletter</h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"var:preset|font-size|md"},"color":{"text":"var:preset|color|paper"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|50"}}}} -->
		<p class="has-text-align-center has-text-color" style="color:var(--wp--preset--color--paper);margin-top:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--50);font-size:var(--wp--preset--font-size--md)">Weekly tips, no spam, unsubscribe in one click.</p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} -->
			<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Subscribe</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|sm"},"color":{"text":"var:preset|color|muted"}}} -->
			<p class="has-text-color" style="color:var(--wp--preset--color--muted);font-size:var(--wp--preset--font-size--sm)">&copy; <!-- wp:site-title {"level":0,"isLink":false} /-->. All rights reserved.</p>
			<!-- /wp:paragraph -->

			<!-- wp:navigation {"layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"right"},"style":{"typography":{"fontSize":"var:preset|font-size|sm"}}} /-->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

</footer>
<!-- /wp:group -->
