<?php
/**
 * Title: Pricing — 3-tier with feature checklist
 * Slug: asteris/pricing-rich
 * Categories: asteris-page-sections, featured
 * Description: Three pricing tiers with full feature checklists. Middle tier highlighted.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">Pricing for every stage.</h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">Pick the tier that fits — upgrade or downgrade anytime.</p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|70"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--70)">

		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:heading {"level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-md-font-size">Starter</h3>
			<!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"3xl"} -->
			<h4 class="wp-block-heading has-3-xl-font-size">$19 /mo</h4>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
			<p class="has-muted-color has-text-color has-sm-font-size">For solo founders and small teams.</p>
			<!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button {"width":100,"className":"is-style-outline"} -->
				<div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Starter</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ 1 site</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 10 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Email support</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Core features</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:paragraph {"fontSize":"xs"} -->
			<p class="has-xs-font-size"><strong>MOST POPULAR</strong></p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-md-font-size">Pro</h3>
			<!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"3xl"} -->
			<h4 class="wp-block-heading has-3-xl-font-size">$49 /mo</h4>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm"} -->
			<p class="has-sm-font-size">For growing teams that need more.</p>
			<!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button {"backgroundColor":"paper","textColor":"ink","width":100} -->
				<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Choose Pro</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ 5 sites</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 100 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Priority support</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ All core features</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Advanced integrations</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Custom branding</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:heading {"level":3,"fontSize":"md"} -->
			<h3 class="wp-block-heading has-md-font-size">Agency</h3>
			<!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"3xl"} -->
			<h4 class="wp-block-heading has-3-xl-font-size">$149 /mo</h4>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} -->
			<p class="has-muted-color has-text-color has-sm-font-size">For agencies managing many clients.</p>
			<!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button {"width":100,"className":"is-style-outline"} -->
				<div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Agency</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ 25 sites</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 500 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 1-day priority support</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Everything in Pro</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ White-label</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Dedicated success</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
