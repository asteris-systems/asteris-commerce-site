<?php
/**
 * Title: Stacked logo and navigation
 * Slug: asteris/header-stacked
 * Categories: asteris-headers, header
 * Block Types: core/template-part/header
 * Description: Logo on its own row, navigation below with a divider. Newspaper / editorial vibe.
 */
?>
<!-- wp:group {"tagName":"header","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"0","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px"}}},"layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:0;padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:site-title {"level":0,"textAlign":"center","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.18em","fontWeight":"800","fontSize":"var:preset|font-size|2xl"},"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}}} /-->

	<!-- wp:separator {"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
	<hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:0;margin-bottom:0"/>
	<!-- /wp:separator -->

	<!-- wp:navigation {"layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center"},"style":{"typography":{"fontSize":"var:preset|font-size|sm","letterSpacing":"0.04em"},"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} /-->

</header>
<!-- /wp:group -->
