<?php
/**
 * Title: Blog archive intro
 * Slug: asteris/blog-archive-intro
 * Categories: asteris-blog
 * Description: Centred archive header — title, description, optional category nav. Drop above your blog query loop.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">THE BLOG</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"3xl"} -->
	<h1 class="wp-block-heading has-text-align-center has-3-xl-font-size">Notes, essays, and updates.</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">Long-form writing on the craft, the team, and what we're building next.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
