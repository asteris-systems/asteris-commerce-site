<?php
/**
 * Title: Recipe card — ingredients + method
 * Slug: asteris/recipe-card
 * Categories: asteris-page-sections, asteris-blog
 * Description: Two-column recipe layout — ingredients on the left, method on the right. For food blogs and recipe posts.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">

	<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">SERVES 4 · PREP 15 MIN · COOK 30 MIN</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":2,"fontSize":"2xl"} --><h2 class="wp-block-heading has-2-xl-font-size">Slow-roast tomato pasta.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"lg","textColor":"muted"} --><p class="has-muted-color has-text-color has-lg-font-size">The kind of dish that tastes like it took all day. It didn't.</p><!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column {"width":"35%"} -->
		<div class="wp-block-column" style="flex-basis:35%">
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Ingredients</h3><!-- /wp:heading -->
			<!-- wp:list -->
			<ul class="wp-block-list"><!-- wp:list-item --><li>1 kg ripe Roma tomatoes</li><!-- /wp:list-item --><!-- wp:list-item --><li>6 garlic cloves, smashed</li><!-- /wp:list-item --><!-- wp:list-item --><li>½ cup olive oil</li><!-- /wp:list-item --><!-- wp:list-item --><li>1 tbsp flaky salt</li><!-- /wp:list-item --><!-- wp:list-item --><li>500 g rigatoni</li><!-- /wp:list-item --><!-- wp:list-item --><li>A handful of basil</li><!-- /wp:list-item --><!-- wp:list-item --><li>Parmesan, to finish</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"65%"} -->
		<div class="wp-block-column" style="flex-basis:65%">
			<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Method</h3><!-- /wp:heading -->
			<!-- wp:list {"ordered":true} -->
			<ol class="wp-block-list"><!-- wp:list-item --><li>Heat the oven to 160°C. Halve the tomatoes and toss them on a tray with the garlic, oil, and salt.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Roast for 90 minutes, undisturbed. They should be deeply jammy.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Bring a large pot of salted water to a boil. Cook the rigatoni until just al dente.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Toss the pasta through the tomatoes, smashing them gently into a rough sauce.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Finish with basil and a heavy hand of parmesan.</li><!-- /wp:list-item --></ol>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
