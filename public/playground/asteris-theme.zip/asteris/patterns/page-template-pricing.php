<?php
/**
 * Title: Pricing page — full starter
 * Slug: asteris/page-template-pricing
 * Categories: asteris-page-templates
 * Description: Complete pricing page with 3 tiers, FAQ, and CTA.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"3xl"} -->
	<h1 class="wp-block-heading has-text-align-center has-3-xl-font-size">Simple, honest pricing.</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} -->
	<p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">Pick a plan. Change it anytime. Cancel in one click.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Starter</h3><!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"3xl"} --><h4 class="wp-block-heading has-3-xl-font-size">$19 /mo</h4><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">For solo founders.</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"width":100,"className":"is-style-outline"} --><div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Starter</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ 1 site</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 10 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Email support</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:paragraph {"fontSize":"xs"} --><p class="has-xs-font-size"><strong>MOST POPULAR</strong></p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Pro</h3><!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"3xl"} --><h4 class="wp-block-heading has-3-xl-font-size">$49 /mo</h4><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm"} --><p class="has-sm-font-size">For growing teams.</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"paper","textColor":"ink","width":100} --><div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Choose Pro</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ 5 sites</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 100 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Priority support</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ All core features</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
			<!-- wp:heading {"level":3,"fontSize":"md"} --><h3 class="wp-block-heading has-md-font-size">Agency</h3><!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"3xl"} --><h4 class="wp-block-heading has-3-xl-font-size">$149 /mo</h4><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">For agencies.</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"width":100,"className":"is-style-outline"} --><div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Agency</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"sm"} -->
			<ul class="wp-block-list has-sm-font-size"><!-- wp:list-item --><li>✓ 25 sites</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 500 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Everything in Pro</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ White-label</li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} -->
	<h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">Common questions.</h2>
	<!-- /wp:heading -->
	<!-- wp:details --><details class="wp-block-details"><summary>Can I change plans?</summary><!-- wp:paragraph --><p>Yes. Upgrade or downgrade anytime from your account page.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>Is there a free trial?</summary><!-- wp:paragraph --><p>14 days, no card required.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>Do you offer refunds?</summary><!-- wp:paragraph --><p>30 days, full refund, no conditions.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
</div>
<!-- /wp:group -->
