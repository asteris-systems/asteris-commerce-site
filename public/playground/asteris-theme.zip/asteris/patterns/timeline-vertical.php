<?php
/**
 * Title: Timeline — vertical milestones
 * Slug: asteris/timeline-vertical
 * Categories: asteris-page-sections, featured
 * Description: Dated milestones in a vertical column — career history, company milestones, project phases.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":2,"fontSize":"2xl"} --><h2 class="wp-block-heading has-2-xl-font-size">The road so far.</h2><!-- /wp:heading -->

	<!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"},"padding":{"left":"var:preset|spacing|50","bottom":"var:preset|spacing|40"}},"border":{"left":{"width":"2px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-group" style="border-left-color:#e5e5e5;border-left-width:2px;margin-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">2026</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">v2.0 launch + Series A</h3><!-- /wp:heading -->
		<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Shipped the rewrite, doubled the team, raised eight million to fund the next chapter.</p><!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"style":{"spacing":{"padding":{"left":"var:preset|spacing|50","bottom":"var:preset|spacing|40"}},"border":{"left":{"width":"2px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-group" style="border-left-color:#e5e5e5;border-left-width:2px;padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">2024</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Public launch</h3><!-- /wp:heading -->
		<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Out of private beta. First thousand customers in the first month.</p><!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"style":{"spacing":{"padding":{"left":"var:preset|spacing|50","bottom":"var:preset|spacing|40"}},"border":{"left":{"width":"2px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-group" style="border-left-color:#e5e5e5;border-left-width:2px;padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">2023</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">First hire</h3><!-- /wp:heading -->
		<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Two co-founders became three. We started writing more code, less proposal.</p><!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:group {"style":{"spacing":{"padding":{"left":"var:preset|spacing|50"}},"border":{"left":{"width":"2px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-group" style="border-left-color:#e5e5e5;border-left-width:2px;padding-left:var(--wp--preset--spacing--50)">
		<!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">2022</p><!-- /wp:paragraph -->
		<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Founded</h3><!-- /wp:heading -->
		<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Started in a borrowed garage in Surry Hills. Idea on a napkin, prototype the same week.</p><!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
