<?php
/**
 * Title: Charity / non-profit — full starter
 * Slug: asteris/page-template-charity
 * Categories: asteris-page-templates
 * Description: Non-profit homepage — mission hero, impact stats, program areas, donate CTA, story-led footer.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|90","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--90);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">REGISTERED CHARITY · ABN 00 000 000 000</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"3xl"} --><h1 class="wp-block-heading has-text-align-center has-3-xl-font-size">Every child deserves a meal.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"lg","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-lg-font-size">We fund school breakfast programs across regional Australia. $1 = 4 meals. 100% of donations go to programs.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Donate now</a></div><!-- /wp:button -->
		<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Read our impact report</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"2xl"} --><h3 class="wp-block-heading has-text-align-center has-2-xl-font-size">2.4M</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Meals served</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"2xl"} --><h3 class="wp-block-heading has-text-align-center has-2-xl-font-size">340</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Schools supported</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"2xl"} --><h3 class="wp-block-heading has-text-align-center has-2-xl-font-size">100%</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">Of donations to programs</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"2xl"} --><h3 class="wp-block-heading has-text-align-center has-2-xl-font-size">12 yrs</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"sm","textColor":"muted"} --><p class="has-text-align-center has-muted-color has-text-color has-sm-font-size">In operation</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"2xl"} --><h2 class="wp-block-heading has-text-align-center has-2-xl-font-size">How we help.</h2><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--60)">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">School breakfasts</h3><!-- /wp:heading --><!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Daily breakfast in 340 schools across NSW, Vic, and Qld.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Holiday meals</h3><!-- /wp:heading --><!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Vacation hampers so kids don't go without when school's out.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">Food education</h3><!-- /wp:heading --><!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">Cooking and nutrition programs for parents and students.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
