<?php
/**
 * Title: Careers — open roles list
 * Slug: asteris/careers-list
 * Categories: asteris-page-sections
 * Description: Categorised open-roles list with title, location, type. For /careers and /jobs pages.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"level":2,"fontSize":"2xl"} --><h2 class="wp-block-heading has-2-xl-font-size">Open roles.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"md","textColor":"muted"} --><p class="has-muted-color has-text-color has-md-font-size">We're hiring across engineering, design, and ops. Remote-friendly, async-first.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":3,"fontSize":"lg","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} --><h3 class="wp-block-heading has-lg-font-size" style="margin-top:var(--wp--preset--spacing--60)">Engineering</h3><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:paragraph --><p><strong><a href="#">Senior backend engineer</a></strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);flex-basis:30%"><!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Remote · Full-time</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:paragraph --><p><strong><a href="#">Mobile engineer (iOS)</a></strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);flex-basis:30%"><!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Sydney · Full-time</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:heading {"level":3,"fontSize":"lg","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} --><h3 class="wp-block-heading has-lg-font-size" style="margin-top:var(--wp--preset--spacing--60)">Design</h3><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:paragraph --><p><strong><a href="#">Senior product designer</a></strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);flex-basis:30%"><!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Remote · Full-time</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:heading {"level":3,"fontSize":"lg","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} --><h3 class="wp-block-heading has-lg-font-size" style="margin-top:var(--wp--preset--spacing--60)">Operations</h3><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:paragraph --><p><strong><a href="#">Customer support lead</a></strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} --><div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);flex-basis:30%"><!-- wp:paragraph {"fontSize":"sm","textColor":"muted"} --><p class="has-muted-color has-text-color has-sm-font-size">Sydney · Full-time</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
