# Asteris theme — bundled assets & attribution

The Asteris theme bundles only original work or assets used under GPL-compatible licences (GPL-2.0+, MIT, CC0, OFL). This file is the audit trail.

WordPress.org Theme Review Team requires every bundled font, image, icon, or script to be GPL-compatible AND to have its source documented. Adding anything new to the theme means adding a row here.

---

## Bundled assets

| Asset | Path | Source | Licence | Notes |
|---|---|---|---|---|
| _(none yet — populate as we add)_ | | | | |

---

## Code

| Component | Path | Author | Licence |
|---|---|---|---|
| Theme PHP, templates, theme.json, style.css | `/` | Asteris Commerce | GPL-2.0-or-later |
| Block patterns | `/patterns/*.php` | Asteris Commerce | GPL-2.0-or-later |
| Block templates | `/templates/*.html`, `/parts/*.html` | Asteris Commerce | GPL-2.0-or-later |
| Style variations | `/styles/*.json` | Asteris Commerce | GPL-2.0-or-later |

---

## Fonts

The theme ships **no bundled web fonts** by default. It uses each operating system's native font stack (San Francisco on Apple, Segoe UI on Windows, Roboto on Android, system defaults elsewhere). This is a deliberate performance + privacy choice.

If a future version ships an optional bundled font, it must be:
- Available under SIL Open Font License (OFL) 1.1, GPL-compatible
- Self-hosted (no Google Fonts CDN — TRT will reject)
- Sourced from Google Fonts download, Fontsource, or a similar verified source
- Added to this file with the exact source URL + licence text

---

## Images

The theme ships **no bundled images** by default. Theme previews, demo screenshots, and starter-site imagery are delivered separately via the Asteris Blocks plugin's pattern previews (where appropriate) or via documentation links to external CDN-hosted CC0/Unsplash imagery (referenced, never bundled).

If a future version ships bundled imagery, every file must be:
- Public domain (CC0), or
- GPL-compatible Creative Commons (CC-BY where attribution is given here)
- Sourced from a verifiable original
- Added to this file with original-source URL + licence

---

## SVG icons

The theme ships **no bundled SVG icon library** — it relies on WordPress core block icons + any icons inlined within block markup (which become part of the GPL theme by virtue of being authored here).

---

## Third-party libraries

The theme ships **zero JavaScript** and **no third-party PHP libraries**. All interactive functionality comes from WordPress core blocks or optionally from the Asteris Blocks plugin.

---

## How to add a new asset to this audit trail

1. Verify the asset's licence is GPL-compatible. If unsure, do not bundle it.
2. Download the asset to its theme folder location (`/assets/images/`, `/assets/fonts/`, etc.).
3. Add a row to the appropriate table above with:
   - Path inside the theme
   - Original source URL
   - Exact licence (e.g., "CC0", "CC-BY 4.0", "OFL 1.1", "GPL-2.0+")
   - Any required attribution text
4. Commit both the asset and this file update in the same change.

---

Last reviewed: 2026-06-09 (theme v0.1.0 initial scaffold).
