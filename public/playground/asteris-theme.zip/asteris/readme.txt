=== Asteris ===
Contributors: asteriscommerce
Requires at least: 6.7
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 0.4.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: full-site-editing, block-themes, e-commerce, blog, news, portfolio, one-column, two-columns, custom-colors, custom-logo, custom-menu, editor-style, featured-images, threaded-comments, translation-ready, wide-blocks, block-styles, style-variations

A clean, fast, WooCommerce-graceful FSE block theme. Ships 6 product page templates, 4 style variations, and 110+ block patterns across 12 categories. Standalone — no plugins required.

== Description ==

**Asteris is a free, full-site-editing WordPress theme built around three principles: stand on its own, work beautifully with WooCommerce when present, and stay out of your way.**

= What's in the box =

* **110+ block patterns** across 12 categories — heroes, page templates, page sections, shop, blog, portfolio, video, audio, testimonials, pricing, FAQ, CTA. Every pattern with image slots ships a visible placeholder so empty inserts look intentional.
* **6 product page templates** — Default, Boutique, Long-form, Shopify-clean, Atelier, Gallery. Pick one per product from the editor sidebar. No other free theme ships this many.
* **4 style variations** — Minimal, Bold, Dark, Shop-focused. Switch the entire visual identity in one click via the Site Editor.
* **19 site templates** — Homepage, blog, page, single, archive, search, 404, plus dedicated WooCommerce templates (single-product variants + archive-product).
* **Brand-quartet gradient** — Violet, orange, indigo, green. Locked palette used across the whole theme; override per-site in the Site Editor.
* **System font stack by default** — Zero web fonts loaded by default. Sub-50KB on the wire. Customise to any font in the Site Editor.
* **Zero JavaScript bundled** — All interactivity comes from WordPress core blocks and (optionally) the Asteris Blocks plugin.
* **WCAG 2.2 AA tested** — Every style variation runs through automated and manual accessibility audits.

= WooCommerce =

When WooCommerce is active, Asteris automatically:

* Registers shop-specific block patterns under their own inserter category
* Surfaces the 6 product page templates in the editor sidebar (Templates dropdown on any product)
* Adds support for WC's product gallery zoom, lightbox, and slider features
* Provides archive-product and search templates with sensible defaults

When WooCommerce is **not** active, none of this loads. The theme degrades gracefully to a clean content-site experience.

= Asteris Blocks (companion free plugin) =

Pairs naturally with the free [Asteris Blocks](https://asterisblocks.com) plugin (50 polished Gutenberg blocks + 30+ landing-page patterns + starter sites). Asteris Blocks is not required — the theme works on its own — but installing it unlocks one-click starter sites and the full block library.

= Asteris Pro Patterns (optional paid add-on) =

For projects that need premium patterns the free theme doesn't ship — niche page templates (photographer, music artist, conference, salon, fitness), video and audio sections (Spotify, SoundCloud, podcast, course), premium e-commerce patterns (drop launch, bundle builder, gift guide, subscription), and composite section inserts — there's a separate paid [Asteris Pro Patterns](https://asteriscommerce.com/asteris-pro-patterns) plugin. Entirely optional. The theme never prompts for it.

= What's NOT in the theme =

* No remote API calls — your privacy is yours.
* No tracking, no analytics, no cookies set by the theme.
* No "Pro upgrade" prompts. (Asteris Commerce sells paid plugins from its own site — never via theme admin.)
* No SEO functionality (use Yoast / Rank Math / AIOSEO / SEOPress).
* No CPTs, no shortcodes, no functionality that belongs in a plugin.

= Accessibility =

* WCAG 2.2 AA target for every style variation.
* Skip-link, semantic landmarks, full keyboard navigation.
* `prefers-reduced-motion` respected globally.
* All bundled colour combinations meet AA contrast minimums.

== Installation ==

1. In your WordPress admin, go to Appearance -> Themes -> Add New.
2. Search for "Asteris" or upload the theme ZIP via the Upload Theme button.
3. Activate.
4. Optional: install the free Asteris Blocks plugin for starter sites + 50 blocks.

== Frequently Asked Questions ==

= Is this really free forever? =

Yes. No "Pro" upgrade, no email-gated features, no upsell prompts in admin. Asteris Commerce sells paid WordPress and WooCommerce plugins from its own site (never via theme admin) and funds this free theme from that.

= Does it require the Asteris Blocks plugin? =

No. The theme works fully on its own using WordPress core blocks. Asteris Blocks adds more blocks and pre-built starter sites but is optional.

= Will it work without WooCommerce? =

Yes. WooCommerce-specific features only load when WC is active. The theme works perfectly as a content / blog / portfolio site without any e-commerce.

= How do I switch product page templates? =

Edit any product in WordPress admin. In the right sidebar, find the "Template" dropdown. Pick from Default, Boutique, Long-form, Shopify-clean, Atelier, or Gallery. Each product can use a different template.

= Will it conflict with my SEO plugin? =

No. The theme doesn't output any SEO meta — that's your SEO plugin's job. Yoast, Rank Math, AIOSEO, and SEOPress all work without modification.

= Page builders (Elementor, Divi, Beaver)? =

Asteris is a block theme designed for the WordPress Site Editor. Classic page builders technically work on individual pages but are not the intended editing experience. We recommend using the WordPress Site Editor for the best result.

= Why are my pattern images showing a grey placeholder? =

That's by design. Patterns that ship with empty image slots render a visible "PLACEHOLDER" card so empty inserts look intentional and remind you to replace them. Click the image and use the WordPress media library to swap in your own.

== Changelog ==

= 0.4.0 =
* Added placeholder SVG system across all 25 image-bearing patterns — empty image slots now render a styled "PLACEHOLDER" card instead of broken/blank squares.
* Pattern library expanded to 110+ patterns across 12 categories.
* Added 8 new audio-category patterns (Spotify, SoundCloud, podcast hero, episode archive, listen-on strip, audio testimonial, album hero, featured episodes).
* Added 8 new video-category patterns (testimonials grid, course/lessons, lesson single, webinar landing, case study, YouTube channel hero, live stream, autoplay-bg hero).
* Pattern validation pass — fixed JSON brace mismatches, inline opacity styles, span style attributes in paragraphs, empty embed/audio blocks. All patterns now lint-clean.
* Reconciled style.css and readme.txt versions.

= 0.3.0 =
* Added Shop-focused style variation.
* Added 3 new product page templates: Atelier, Gallery, Edge-to-edge.
* Style variation polish across Bold, Dark, Minimal.

= 0.2.0 =
* Added Dark style variation.
* Initial WooCommerce template family (single-product, archive-product, single-product-* variants).
* Pattern category registration moved to functions.php.

= 0.1.0 =
* Initial release. 6 WooCommerce product page templates, 4 style variations, 10 site templates, full FSE support.

== Upgrade Notice ==

= 0.4.0 =
Pattern library expansion (110+ patterns) plus placeholder system across image-bearing patterns. Safe upgrade — additive only, no breaking template changes.

= 0.1.0 =
First public release. Built against WordPress 7.0 with theme.json v3.

== Copyright ==

Asteris bundles only original work or assets used under GPL-compatible licences. See CREDITS.md in the theme directory for full attribution.

Asteris WordPress Theme, (C) 2026 Asteris Commerce.
Asteris is distributed under the terms of the GNU GPL.
