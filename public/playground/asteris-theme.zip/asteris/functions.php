<?php
/**
 * Asteris theme functions
 *
 * Kept deliberately minimal — block themes do almost everything via
 * theme.json + HTML template files. PHP only handles things JSON cannot:
 * conditional WC support declaration, pattern category registration, and
 * Block Hooks anchor exposure for the Asteris Blocks plugin to inject into.
 *
 * No business logic. No CPTs. No shortcodes. No SEO/analytics. No remote
 * calls. No tracking. Per WP.org Theme Review Team requirements, all of
 * those belong in a plugin, never a theme.
 *
 * @package Asteris
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/inc/product-page-fields.php';
require_once __DIR__ . '/inc/wc-page-templates.php';

/**
 * Theme setup.
 *
 * Declares the support features WordPress needs to know about up front.
 * Run on after_setup_theme so it lands before WC's own init.
 */
add_action( 'after_setup_theme', static function (): void {
	// i18n — every string in patterns + this file uses the 'asteris' domain.
	load_theme_textdomain( 'asteris', get_template_directory() . '/languages' );

	// Standard block-theme support flags.
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'html5', [ 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form', 'script', 'style' ] );

	// WooCommerce — declared unconditionally so WC's own theme-support
	// detection finds it. WC blocks/templates only render when WC is active;
	// the theme degrades gracefully when WC is not installed.
	add_theme_support( 'woocommerce', [
		'thumbnail_image_width' => 600,
		'single_image_width'    => 1200,
		'product_grid'          => [
			'default_rows'    => 2,
			'min_rows'        => 1,
			'default_columns' => 3,
			'min_columns'     => 2,
			'max_columns'     => 4,
		],
	] );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
} );

/**
 * Register pattern categories shipped by the theme.
 *
 * Registered on init at default priority 10 — the same priority WordPress
 * uses for _register_theme_block_patterns(). Same-priority callbacks fire
 * in registration order; the theme's functions.php is included earlier in
 * WP boot than core's block-patterns.php hook setup, so our callback runs
 * before the pattern auto-loader. Pattern: matches Twenty Twenty-Five.
 *
 * CRITICAL: WordPress caches the parsed pattern data per theme keyed on
 * the theme's Version. If you edit a pattern file's Categories header
 * without bumping the theme version, WP serves the stale cached parse and
 * your category changes won't take effect. To force a re-parse:
 *   - Bump style.css Version (any change works), OR
 *   - Add `define('WP_DEVELOPMENT_MODE', 'theme')` to wp-config.php
 *     (bypasses the cache entirely during development), OR
 *   - Delete the site transient via wp-cli:
 *     wp transient delete wp_theme_files_patterns-<hash> --site
 *
 * Asteris Blocks (free plugin) registers its own patterns under separate
 * categories; this hook covers the theme-shipped patterns only.
 */
if ( ! function_exists( 'asteris_pattern_categories' ) ) :
	function asteris_pattern_categories(): void {
		register_block_pattern_category( 'asteris-headers', [
			'label'       => __( 'Asteris — Headers', 'asteris' ),
			'description' => __( 'Header patterns shipped by the Asteris theme.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-footers', [
			'label'       => __( 'Asteris — Footers', 'asteris' ),
			'description' => __( 'Footer patterns shipped by the Asteris theme.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-page-sections', [
			'label'       => __( 'Asteris — Page sections', 'asteris' ),
			'description' => __( 'Hero, CTA, and structural page section patterns.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-page-templates', [
			'label'       => __( 'Asteris — Page templates', 'asteris' ),
			'description' => __( 'Full-page starter templates: Home, About, Pricing, Contact, 404.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-heroes', [
			'label'       => __( 'Asteris — Hero sections', 'asteris' ),
			'description' => __( 'Hero patterns for the top of landing and marketing pages.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-blog', [
			'label'       => __( 'Asteris — Blog', 'asteris' ),
			'description' => __( 'Single-post and archive patterns: author bios, related posts, post headers.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-portfolio', [
			'label'       => __( 'Asteris — Portfolio', 'asteris' ),
			'description' => __( 'Portfolio, gallery, and project showcase patterns.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-video', [
			'label'       => __( 'Asteris — Video', 'asteris' ),
			'description' => __( 'Video hero, lessons, webinars, case studies, and channel pages.', 'asteris' ),
		] );
		register_block_pattern_category( 'asteris-audio', [
			'label'       => __( 'Asteris — Audio', 'asteris' ),
			'description' => __( 'Podcast, Spotify, SoundCloud, music album, and audio testimonial patterns.', 'asteris' ),
		] );

		if ( class_exists( 'WooCommerce' ) ) {
			register_block_pattern_category( 'asteris-shop', [
				'label'       => __( 'Asteris — Shop', 'asteris' ),
				'description' => __( 'WooCommerce-specific patterns surfaced when WC is active.', 'asteris' ),
			] );
		}
	}
endif;
add_action( 'init', 'asteris_pattern_categories' );

/**
 * Enqueue the theme stylesheet on the front end.
 *
 * style.css is intentionally tiny — only carries the bits theme.json cannot
 * express (skip-link focus state, prefers-reduced-motion, print stylesheet).
 * No JavaScript enqueues from the theme itself.
 */
add_action( 'wp_enqueue_scripts', static function (): void {
	$ver = wp_get_theme()->get( 'Version' );
	$css = get_stylesheet_directory() . '/style.css';
	if ( file_exists( $css ) ) {
		// Cache-bust on file mtime so live edits show without bumping the
		// theme Version every change. Production still gets a stable version
		// once the mtime stops changing.
		$ver .= '.' . filemtime( $css );
	}
	wp_enqueue_style(
		'asteris-style',
		get_stylesheet_uri(),
		[],
		$ver
	);
} );

/**
 * Editor styles — same stylesheet loaded inside the block editor so the
 * skip-link/print/reduced-motion rules don't leak into the editor and the
 * editor accurately reflects the front-end's typography + colour decisions
 * (most of which already come from theme.json automatically).
 */
add_action( 'after_setup_theme', static function (): void {
	add_editor_style( 'style.css' );
} );

/**
 * Block Hooks anchors exposed for Asteris Blocks (and any well-behaved
 * third-party plugin) to inject content into the theme without ever
 * touching theme template files.
 *
 * Block Hooks API (stable since WP 6.5) lets a plugin declare a block
 * pattern hooked to a target block + position, and WordPress automatically
 * weaves it into the rendered template. Theme exposes the anchors here;
 * plugin decides what to inject. Zero coupling between theme and plugin.
 *
 * Plugin-side example (in Asteris Blocks):
 *   register_block_pattern( 'asteris-blocks/announcement-bar', [
 *     ...
 *     'blockTypes' => [ 'core/group' ],
 *     'inserter'   => false,
 *     'hooked'     => [ 'asteris/header-after' => 'after' ],
 *   ] );
 *
 * The five anchor names below are the contract:
 *   - asteris/header-before        (e.g. cookie consent, top utility bar)
 *   - asteris/header-after         (e.g. announcement bar)
 *   - asteris/footer-before        (e.g. newsletter signup, social proof)
 *   - asteris/product-meta-after   (e.g. cross-sells, recently viewed) — WC only
 *   - asteris/article-end          (e.g. related posts, author bio enrichment)
 *
 * No PHP is needed in the theme to "register" these — they're string
 * conventions exposed via theme template-part naming + documentation.
 */
