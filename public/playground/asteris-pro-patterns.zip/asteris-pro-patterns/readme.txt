=== Asteris Pro Patterns ===
Contributors: asteriscommerce
Tags: patterns, block-patterns, video, podcast, ecommerce, landing-page
Requires at least: 6.5
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 1.0.0
License: Proprietary
License URI: https://asteriscommerce.com/asteris-pro-patterns/license

50+ premium block patterns for the Asteris theme. Licensed product.

== Description ==

Asteris Pro Patterns is a paid companion plugin for the free Asteris theme.
It adds 50+ premium block patterns covering categories the free theme
doesn't ship:

* 8 niche page templates — Portfolio, Personal, Membership, Charity,
  Real estate, Wedding, Book launch, App landing
* 5 vertical-niche landing pages — SaaS, Agency, Course, Podcast, Restaurant
* 10 video patterns — testimonials, course / lessons, webinars, case studies,
  YouTube channel, live stream, autoplay background, and more
* 8 audio patterns — Spotify, SoundCloud, podcast series hero, episode
  archive, listen-on strip, music album, and more
* 7 premium e-commerce patterns — featured product hero, lookbook,
  editorial narrative, bundle, best sellers ranked
* 6 advanced content patterns — comparison vs competitor, changelog,
  roadmap, press kit, careers, recipe card

A valid licence is required to register the patterns. Buy a licence at
https://asteriscommerce.com/asteris-pro-patterns/.

== Installation ==

1. Install the free Asteris theme.
2. Install and activate this plugin.
3. Settings → Asteris Pro Patterns → paste your licence key.
4. Open any page in the editor — the new patterns appear under their
   respective Asteris categories in the inserter.

== Frequently Asked Questions ==

= Do I need the free Asteris theme installed? =

Yes. This plugin assumes the Asteris theme's pattern categories and
theme.json presets. It will technically activate under other themes but
patterns may render with theme defaults.

= How many sites can I activate on? =

Depends on your licence tier — see the purchase page.

== Changelog ==

= 1.0.0 =
* Initial release. 18 video and audio patterns shipped first;
  remaining premium patterns landing in subsequent point releases.
