<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">Sarah Chen.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Author of <em>The Long Game</em> (Penguin, 2026). Essays on craft and the long view. Currently writing book two.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"35%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:35%">
			<!-- wp:image --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt="Book cover"/></figure><!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"65%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:65%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">OUT NOW · HARDCOVER · 280 PAGES</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":2,"fontSize":"xx-large"} --><h2 class="wp-block-heading has-xx-large-font-size">The Long Game.</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p>"Required reading for anyone building something that matters." — <em>The New York Times</em></p><!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Amazon</a></div><!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Bookshop</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Recent essays</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li><strong><a href="#">Building in public, ten years in</a></strong> — June 2026</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong><a href="#">The pricing mistakes we made twice</a></strong> — May 2026</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong><a href="#">When to ignore the advice</a></strong> — April 2026</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong><a href="#">The first year nobody talks about</a></strong> — March 2026</li><!-- /wp:list-item --></ul><!-- /wp:list -->
	<!-- wp:paragraph --><p><a href="#">Browse the full archive →</a></p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-text-align-center has-large-font-size">Join the newsletter.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">One essay a week. 12,000+ readers. No spam, ever.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Subscribe</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
