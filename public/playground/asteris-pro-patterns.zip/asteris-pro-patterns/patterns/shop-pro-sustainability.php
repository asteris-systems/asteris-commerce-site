<?php
if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:6rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">OUR APPROACH · LAST UPDATED 1 JUNE 2026</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">Made to last. Built to mend.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">We're not perfect. We're getting better every year. Here's exactly where we are right now.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">94%</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Of materials are natural or recycled</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">100%</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Packaging is recyclable or compostable</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">10 yrs</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Free repairs on everything we make</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">B Corp</h3><!-- /wp:heading --><!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Certified since 2024</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">

	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Materials.</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>We source organic cotton through GOTS-certified mills, merino from RWS-certified farms, and recycled metals from local refineries. Every supplier is audited annually. Where we can't yet meet the standard, we say so.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">Repairs.</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Send anything back within ten years and we'll repair it free. Past ten years, we'll repair it at cost. We don't make new things to replace the old ones — we make the old ones last.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">What we're still working on.</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>Reducing freight emissions — currently 8% of our total footprint</li><!-- /wp:list-item --><!-- wp:list-item --><li>Closing the loop on our hardware — recycled options ship Q4 2026</li><!-- /wp:list-item --><!-- wp:list-item --><li>Living wage verification for every supplier worldwide by 2027</li><!-- /wp:list-item --></ul><!-- /wp:list -->
</div>
<!-- /wp:group -->
PATTERN;
