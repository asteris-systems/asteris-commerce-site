<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">Latest track.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Released this week. Mastered on cheap speakers, on purpose.</p><!-- /wp:paragraph -->
	<!-- wp:html -->
	<div style="background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:8px;min-height:152px;padding:2rem;">🎵 Paste a SoundCloud track URL here</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
PATTERN;
