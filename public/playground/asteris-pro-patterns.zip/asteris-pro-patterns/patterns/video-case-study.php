<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">CASE STUDY · LATTICE STUDIO</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-xx-large-font-size">How Lattice doubled output in 90 days.</h1><!-- /wp:heading -->

	<!-- wp:html -->
	<div style="aspect-ratio:16/9;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;margin:3rem 0;">▶ Paste a YouTube or Vimeo URL here</div>
	<!-- /wp:html -->

	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"fontSize":"x-large"} --><h3 class="wp-block-heading has-x-large-font-size">2×</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Throughput</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"fontSize":"x-large"} --><h3 class="wp-block-heading has-x-large-font-size">−40%</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">On-call burden</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"fontSize":"x-large"} --><h3 class="wp-block-heading has-x-large-font-size">90 days</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">From kickoff to outcome</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
