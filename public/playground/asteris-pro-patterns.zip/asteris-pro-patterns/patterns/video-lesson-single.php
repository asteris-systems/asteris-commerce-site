<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"66%"} -->
		<div class="wp-block-column" style="flex-basis:66%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">LESSON 3 OF 12 · 24 MIN</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-xx-large-font-size">Building your first project.</h1><!-- /wp:heading -->
			<!-- wp:html -->
			<div style="aspect-ratio:16/9;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;">▶ Paste a YouTube or Vimeo URL here</div>
			<!-- /wp:html -->
			<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">Transcript</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p>Welcome back. In the last lesson we covered the fundamentals — today we're going to put them to work by building our first real project from scratch.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph --><p>Replace this transcript with the real one. You can paste auto-generated captions from YouTube or use a service like Descript to clean them up.</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"34%","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"1.5rem","right":"1.5rem","bottom":"1.5rem","left":"1.5rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:1.5rem;padding-right:1.5rem;padding-bottom:1.5rem;padding-left:1.5rem;flex-basis:34%">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">All lessons</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"small"} -->
			<ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>✓ <a href="#">Getting started</a></li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ <a href="#">The fundamentals</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>▶ Building your first project</strong></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Going deeper</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Advanced patterns</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Shipping &amp; next steps</a></li><!-- /wp:list-item --></ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
