<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">FREE DOWNLOAD · 32 PAGES · PDF</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-xx-large-font-size">The shipping playbook.</h1><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Every template, agenda, and script we used to take a 12-person team from 1 feature a month to 3 features a week.</p><!-- /wp:paragraph -->
			<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>The 4 meeting agendas we run weekly</li><!-- /wp:list-item --><!-- wp:list-item --><li>The roadmap template our team builds with</li><!-- /wp:list-item --><!-- wp:list-item --><li>The retro format we never skip</li><!-- /wp:list-item --><!-- wp:list-item --><li>The hiring scorecard for senior engineers</li><!-- /wp:list-item --></ul><!-- /wp:list -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Send me the playbook</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">We'll send it to your inbox. No spam, unsubscribe any time.</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:image --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt="Playbook cover"/></figure><!-- /wp:image -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">⭐ 12,000+ founders downloaded this last month.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
