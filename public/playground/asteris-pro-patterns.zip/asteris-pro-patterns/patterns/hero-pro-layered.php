<?php
return <<<'PATTERN'
<!-- wp:cover {"useFeaturedImage":false,"dimRatio":0,"minHeight":640,"minHeightUnit":"px","align":"full","contentPosition":"center center"} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-center" style="min-height:640px">
	<span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span>
	<div class="wp-block-cover__inner-container">
		<!-- wp:group {"style":{"spacing":{"padding":{"top":"4rem","right":"4rem","bottom":"4rem","left":"4rem"}}},"backgroundColor":"base","layout":{"type":"constrained","contentSize":"560px"}} -->
		<div class="wp-block-group has-base-background-color has-background" style="padding-top:4rem;padding-right:4rem;padding-bottom:4rem;padding-left:4rem">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">FROM THE STUDIO · JUNE 2026</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">Notes on slowness.</h1><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">A small essay on why we're taking our time. Two years in, four hires, one product. We could be moving faster. We're choosing not to.</p><!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Read the essay</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:group -->
	</div>
</div>
<!-- /wp:cover -->
PATTERN;
