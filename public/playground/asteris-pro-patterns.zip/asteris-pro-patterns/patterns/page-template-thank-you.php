<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:6rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"large"} --><p class="has-text-align-center has-large-font-size">🎉</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">Thank you.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">Your order is confirmed. We've sent the receipt and download links to your email.</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Order #2026-0612 · Confirmation sent to <strong>hello@example.com</strong></p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Open your dashboard</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">While you're here…</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">Customers who bought what you bought also like these. One-click add — no second checkout.</p><!-- /wp:paragraph -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"2rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:2rem">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph --><p><strong>The Long Game (audiobook)</strong><br>$19</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Add for $19</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph --><p><strong>Office hours pass (3 months)</strong><br>$99</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Add for $99</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
