<?php
if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">2026 GIFT EDIT · LAST ORDER 18 DECEMBER</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">The gift guide.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">Hand-picked for the people on your list. Filtered by occasion, recipient, or budget.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">By occasion</h2><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"2rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:2rem">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size"><a href="#">Birthday</a></h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">42 ideas · $20-$300</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size"><a href="#">Holiday</a></h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">68 ideas · $30-$500</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size"><a href="#">Wedding</a></h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">24 ideas · $50-$800</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size"><a href="#">New home</a></h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">31 ideas · $40-$400</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">By budget</h2><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"2rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:2rem">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size"><a href="#">Under $50</a></h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Small but considered.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size"><a href="#">$50-$150</a></h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">The sweet spot.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size"><a href="#">$150+</a></h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">For the people you really like.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
