<?php
if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"7rem","bottom":"7rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:7rem;padding-right:2rem;padding-bottom:7rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">DROPS FRIDAY · 18 SEPTEMBER · 9PM AEST</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">The Autumn Drop.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"large"} --><p class="has-text-align-center has-large-font-size">Five pieces. Limited run. Once they're gone they're gone.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Join the waitlist</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Waitlist members get 15-minute early access.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Preview the collection.</h2><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"3rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:3rem">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph --><p><strong>Piece 01</strong> · The Overcoat</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph --><p><strong>Piece 02</strong> · The Knit</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph --><p><strong>Piece 03</strong> · The Trouser</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph --><p><strong>Piece 04</strong> · The Boot</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph --><p><strong>Piece 05</strong> · The Bag</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
