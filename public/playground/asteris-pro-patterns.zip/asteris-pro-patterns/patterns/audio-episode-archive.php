<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-xx-large-font-size">All episodes.</h1><!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} -->
		<div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem">
			<!-- wp:paragraph --><p><strong><a href="#">#47 — Building in public, ten years in</a></strong><br><em>With Sarah Chen · 48 min</em></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"25%","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} -->
		<div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem;flex-basis:25%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">2 days ago</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} -->
		<div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem">
			<!-- wp:paragraph --><p><strong><a href="#">#46 — The pricing mistakes we made twice</a></strong><br><em>With Alex Morgan · 32 min</em></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"25%","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} -->
		<div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem;flex-basis:25%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">1 week ago</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} -->
		<div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem">
			<!-- wp:paragraph --><p><strong><a href="#">#45 — When to ignore the advice</a></strong><br><em>Solo episode · 28 min</em></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"25%","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} -->
		<div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem;flex-basis:25%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">2 weeks ago</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
