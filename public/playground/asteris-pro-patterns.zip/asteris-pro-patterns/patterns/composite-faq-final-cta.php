<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:6rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xx-large"} --><h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">Questions you might have.</h2><!-- /wp:heading -->

	<!-- wp:details {"style":{"spacing":{"margin":{"top":"2rem"}}}} --><details class="wp-block-details" style="margin-top:2rem"><summary><strong>How does it work?</strong></summary><!-- wp:paragraph --><p>Replace this with the answer. Keep it to 2-4 sentences and link to a longer article if needed.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary><strong>Can I cancel anytime?</strong></summary><!-- wp:paragraph --><p>Yes. Cancel from your account; no calls, no emails. Access lasts until the end of your billing period.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary><strong>Do you offer refunds?</strong></summary><!-- wp:paragraph --><p>30 days, full refund, no conditions.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary><strong>What's included in support?</strong></summary><!-- wp:paragraph --><p>Email support on all plans (2-3 business day response). Pro and Agency tiers get priority queue.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary><strong>How is my data handled?</strong></summary><!-- wp:paragraph --><p>SOC 2 Type II audited annually. Edit this to describe your privacy and data handling. Link to your privacy policy.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:6rem;padding-right:2rem;padding-bottom:6rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xxx-large"} --><h2 class="wp-block-heading has-text-align-center has-xxx-large-font-size">Still here?</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"large"} --><p class="has-text-align-center has-large-font-size">Then you're probably the right kind of person for this. Start free — no card.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Start free trial</a></div><!-- /wp:button -->
		<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Book a demo</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">14-day free trial · No credit card · Cancel any time</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
