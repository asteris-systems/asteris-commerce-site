<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">🔴 LIVE NOW</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"x-large"} --><h1 class="wp-block-heading has-text-align-center has-x-large-font-size">Q3 product update.</h1><!-- /wp:heading -->
	<!-- wp:html -->
	<div style="aspect-ratio:16/9;background:#222;display:flex;align-items:center;justify-content:center;color:#aaa;font-size:.95rem;border-radius:4px;">▶ Paste the live YouTube/Vimeo URL here when streaming starts</div>
	<!-- /wp:html -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Started at 2pm AEST · 1,247 watching · Questions in #live-qa on Slack</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
