<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">AN HONEST COMPARISON</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-text-align-center has-xx-large-font-size">Asteris vs Competitor.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">We use Competitor too. Here's a side-by-side, written by people who use both.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:table -->
	<figure class="wp-block-table"><table><thead><tr><th>Feature</th><th><strong>Asteris</strong></th><th>Competitor</th></tr></thead><tbody><tr><td>Starting price</td><td><strong>$19/mo</strong></td><td>$29/mo</td></tr><tr><td>Setup time</td><td>Under 1 hour</td><td>1-2 days</td></tr><tr><td>Free trial</td><td>14 days, no card</td><td>7 days, card required</td></tr><tr><td>SAML SSO</td><td>Agency plan ✓</td><td>Enterprise only</td></tr><tr><td>API + webhooks</td><td>REST + GraphQL</td><td>REST only</td></tr><tr><td>Native mobile apps</td><td>iOS &amp; Android</td><td>iOS only</td></tr><tr><td>Public roadmap</td><td>✓</td><td>—</td></tr><tr><td>Money-back guarantee</td><td>30 days</td><td>—</td></tr></tbody></table></figure>
	<!-- /wp:table -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">When Competitor is the right call</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>If you need feature X, Y, or Z — Competitor is genuinely better. We mean it. Don't pay us for something they do better.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:2rem">When Asteris is the right call</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>If you care about price-to-value, setup speed, mobile, or want a clear product roadmap — that's where we shine.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">Try us alongside Competitor.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">14-day free trial. No card required. Free import from Competitor — your data, in your hands, in 5 minutes.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Start free trial</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
