<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">A NEW WAY TO SHIP</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">The system 1,200+ founders use to ship 3× faster.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"large"} --><p class="has-text-align-center has-large-font-size">A focused 6-week program that replaces "how should we work?" with "what should we work on?"</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Get the system — $499</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">If this sounds familiar…</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>You start the week with a roadmap and end it firefighting.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Your team is busy but you can't point to what shipped.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Every retro lands on "we need better processes" and nothing changes.</li><!-- /wp:list-item --><!-- wp:list-item --><li>You're hiring more people but throughput stayed the same.</li><!-- /wp:list-item --></ul><!-- /wp:list -->
	<!-- wp:paragraph --><p>You're not the problem. The system is.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">What you'll learn</h2><!-- /wp:heading -->
	<!-- wp:heading {"level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-large-font-size">Week 1 — The audit</h3><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Map every meeting, every status update, every workflow. Identify the three biggest time sinks. We'll do this together on a live call.</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":3,"fontSize":"large","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h3 class="wp-block-heading has-large-font-size" style="margin-top:2rem">Weeks 2-3 — The rebuild</h3><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Replace the broken parts of your week with the proven cadence. We'll send templates, scripts, and meeting agendas you can copy verbatim.</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":3,"fontSize":"large","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h3 class="wp-block-heading has-large-font-size" style="margin-top:2rem">Weeks 4-6 — The reinforcement</h3><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Weekly 1:1 office hours. We watch you run it, then we adjust. By week 6 it sticks.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"x-large"} --><p class="has-text-align-center has-x-large-font-size">"This system added two engineering hires worth of throughput. Without the headcount."</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size"><strong>Sarah Chen</strong> · Head of Ops, Lattice Studio</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">$499 · 6 weeks · 60-day guarantee</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">If your throughput hasn't measurably improved in 60 days, full refund. We've never had to give one.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Enrol now</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
