<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:4rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">CASE STUDY · LATTICE STUDIO · 2026</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">How Lattice doubled output in 90 days.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"large"} --><p class="has-large-font-size">A 60-person SaaS team rebuilt their weekly cadence and shipped 2× as many features in the next quarter — without hiring.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:image --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt="Hero image"/></figure><!-- /wp:image -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">2×</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Features shipped per quarter</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">−40%</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Time spent in meetings</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">90</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Days from kickoff to outcome</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"xx-large"} --><h3 class="wp-block-heading has-text-align-center has-xx-large-font-size">0</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">New hires required</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">The problem</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Lattice had a 60-person engineering org and was shipping less than they had at 30. The CEO described the symptom in one line: "we're busy, but I can't point to what we did this month."</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">What we changed</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Three things, in order of impact:</p><!-- /wp:paragraph -->
	<!-- wp:list {"ordered":true} --><ol class="wp-block-list"><!-- wp:list-item --><li>Killed the weekly all-hands status meeting. Replaced with written async updates.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Moved roadmap from quarterly to six-week cycles with built-in cool-down weeks.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Introduced a "shipping bar" — no feature ships without a one-paragraph rationale and a measurement plan.</li><!-- /wp:list-item --></ol><!-- /wp:list -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">The result</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Inside 90 days, the team was shipping twice as many customer-visible features per quarter. Meeting time dropped 40%. Retention of senior engineers improved measurably — exit interviews stopped citing "I don't feel like we're making progress" as the reason.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"x-large"} --><p class="has-text-align-center has-x-large-font-size">"This system added two engineering hires worth of throughput. Without the headcount."</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size"><strong>Sarah Chen</strong> · Head of Engineering, Lattice</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"2rem"}}}} --><div class="wp-block-buttons" style="margin-top:2rem"><!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">See if we can help your team</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
