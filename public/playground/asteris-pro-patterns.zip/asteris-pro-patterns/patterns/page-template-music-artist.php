<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:6rem;padding-right:2rem;padding-bottom:6rem;padding-left:2rem">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%">
			<!-- wp:image --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt="Album artwork"/></figure><!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">NEW ALBUM · OUT NOW</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">Long Light.</h1><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">10 tracks · 42 minutes · Recorded live in one room, five days, no overdubs.</p><!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Spotify</a></div><!-- /wp:button -->
				<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Apple Music</a></div><!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Bandcamp</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">On tour.</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li><strong>18 SEP — Sydney</strong> · Enmore Theatre · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>22 SEP — Melbourne</strong> · The Forum · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>27 SEP — Brisbane</strong> · The Tivoli · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>04 OCT — Auckland</strong> · Powerstation · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>11 OCT — London</strong> · Lafayette · <a href="#">Tickets</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">FOLLOW</p><!-- /wp:paragraph -->
	<!-- wp:social-links {"size":"has-small-icon-size","className":"is-style-logos-only","layout":{"type":"flex","justifyContent":"center"}} -->
	<ul class="wp-block-social-links has-small-icon-size is-style-logos-only">
		<!-- wp:social-link {"url":"#","service":"instagram"} /-->
		<!-- wp:social-link {"url":"#","service":"youtube"} /-->
		<!-- wp:social-link {"url":"#","service":"tiktok"} /-->
		<!-- wp:social-link {"url":"#","service":"spotify"} /-->
	</ul>
	<!-- /wp:social-links -->
</div>
<!-- /wp:group -->
PATTERN;
