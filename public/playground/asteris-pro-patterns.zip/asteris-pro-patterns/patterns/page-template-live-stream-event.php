<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">🔴 LIVE NOW · 1,247 WATCHING</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-text-align-center has-xx-large-font-size">Q3 product update.</h1><!-- /wp:heading -->
	<!-- wp:html -->
	<div style="aspect-ratio:16/9;background:#222;display:flex;align-items:center;justify-content:center;color:#aaa;font-size:.95rem;border-radius:4px;">▶ Paste the live YouTube/Vimeo URL here when streaming starts</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"65%"} -->
		<div class="wp-block-column" style="flex-basis:65%">
			<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">What we're announcing.</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p>Three big things shipping this quarter, plus a roadmap walkthrough for Q4. Bring your hardest questions — we're keeping 30 minutes at the end for live Q&amp;A.</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"large","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h3 class="wp-block-heading has-large-font-size" style="margin-top:2rem">Agenda</h3><!-- /wp:heading -->
			<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li><strong>00:00</strong> — Welcome + the year so far</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>05:00</strong> — Announcement 1: Native iOS app</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>20:00</strong> — Announcement 2: Public API v3</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>35:00</strong> — Announcement 3: Enterprise plan</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>50:00</strong> — Q4 roadmap walkthrough</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>1:05:00</strong> — Live Q&amp;A</li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"width":"35%","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"1.5rem","right":"1.5rem","bottom":"1.5rem","left":"1.5rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:1.5rem;padding-right:1.5rem;padding-bottom:1.5rem;padding-left:1.5rem;flex-basis:35%">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Live chat</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Questions and reactions in <a href="#">#live-qa on Slack</a>.</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"medium","style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><h3 class="wp-block-heading has-medium-font-size" style="margin-top:1.5rem">Can't stay?</h3><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Drop your email — we'll send the replay.</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Send me the replay</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
