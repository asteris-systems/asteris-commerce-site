<?php
return <<<'PATTERN'
<!-- wp:cover {"dimRatio":30,"overlayColor":"ink","minHeight":720,"minHeightUnit":"px","align":"full","contentPosition":"center center"} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-center" style="min-height:720px">
	<span aria-hidden="true" class="wp-block-cover__background has-ink-background-color has-background-dim-30 has-background-dim"></span>
	<div class="wp-block-cover__inner-container">
		<!-- wp:paragraph {"align":"center","fontSize":"small","textColor":"paper"} --><p class="has-text-align-center has-paper-color has-text-color has-small-font-size">A FILM BY SARAH CHEN</p><!-- /wp:paragraph -->
		<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large","textColor":"paper"} --><h1 class="wp-block-heading has-text-align-center has-paper-color has-text-color has-xxx-large-font-size">In the making.</h1><!-- /wp:heading -->
		<!-- wp:paragraph {"align":"center","fontSize":"large","textColor":"paper"} --><p class="has-text-align-center has-paper-color has-text-color has-large-font-size">Three years. Four cities. Six lives.</p><!-- /wp:paragraph -->
		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">▶ Watch trailer</a></div><!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
</div>
<!-- /wp:cover -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"1rem","bottom":"1rem","left":"2rem","right":"2rem"}}},"backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:1rem;padding-right:2rem;padding-bottom:1rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">DOLBY ATMOS · 4K HDR · OFFICIAL SELECTION SUNDANCE 2026</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
