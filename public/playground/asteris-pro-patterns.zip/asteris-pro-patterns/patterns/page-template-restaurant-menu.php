<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">DINNER MENU · CHANGES SEASONALLY</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">Tonight's menu.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">Three courses, $79 per person. Wine pairings $35 extra.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">To start</h2><!-- /wp:heading -->

	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"2rem"}}}} --><p style="margin-top:2rem"><strong>House-made focaccia</strong> · cultured butter, flaky salt</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Burrata</strong> · slow-roast tomato, basil, sourdough crisps</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Steak tartare</strong> · cured yolk, anchovy, charred toast</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Roast pumpkin</strong> · whipped feta, dukkah, sage <em>(v)</em></p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:separator {"style":{"spacing":{"margin":{"top":"2rem","bottom":"2rem"}}}} --><hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:2rem;margin-bottom:2rem"/><!-- /wp:separator -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">Main</h2><!-- /wp:heading -->

	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"2rem"}}}} --><p style="margin-top:2rem"><strong>Slow-roast lamb shoulder</strong> · white beans, salsa verde, rocket</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Pan-fried barramundi</strong> · brown butter, capers, charred lemon</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Wood-fired pappardelle</strong> · slow-cooked beef cheek, parmesan</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Eggplant parmigiana</strong> · house ricotta, pomodoro, basil <em>(v)</em></p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:separator {"style":{"spacing":{"margin":{"top":"2rem","bottom":"2rem"}}}} --><hr class="wp-block-separator has-alpha-channel-opacity" style="margin-top:2rem;margin-bottom:2rem"/><!-- /wp:separator -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">To finish</h2><!-- /wp:heading -->

	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"2rem"}}}} --><p style="margin-top:2rem"><strong>Tiramisu</strong> · Marsala, espresso, mascarpone</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Affogato</strong> · vanilla bean ice cream, double espresso, amaretto</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.5rem"}}}} --><p style="margin-top:1.5rem"><strong>Seasonal cheese</strong> · house quince paste, lavosh</p><!-- /wp:paragraph -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"3rem"}}}} -->
	<div class="wp-block-buttons" style="margin-top:3rem">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Book a table</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
