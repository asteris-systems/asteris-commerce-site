<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">FREE TUTORIAL · 12 MIN VIDEO + WRITTEN GUIDE</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">How to ship your first feature in a weekend.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">A step-by-step walkthrough you can follow even if you've never shipped before.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"2rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:2rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:html -->
	<div style="aspect-ratio:16/9;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;">▶ Paste a YouTube or Vimeo URL here</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">What you'll learn</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>How to scope a weekend project so it's actually shippable</li><!-- /wp:list-item --><!-- wp:list-item --><li>The three things to cut before you start</li><!-- /wp:list-item --><!-- wp:list-item --><li>A timeline you can copy</li><!-- /wp:list-item --><!-- wp:list-item --><li>How to launch on Monday morning without burning out</li><!-- /wp:list-item --></ul><!-- /wp:list -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:3rem">Step 1 — Scope down</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Most weekend projects fail because they were two-week projects in disguise. Write down what you'd love to ship, then cut it in half. Then cut it in half again. That's your scope.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:3rem">Step 2 — Lock the deadline</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Tell someone you're shipping on Sunday at 6pm. Public commitment is unreasonably effective.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:3rem">Step 3 — Build the smallest thing that proves the idea</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>If you can't demo it in 30 seconds, it's too big. Find the 30-second demo. Build that. Everything else is v2.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-text-align-center has-large-font-size">Want more tutorials?</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">A new one every Sunday. No spam, unsubscribe anytime.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Subscribe — free</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
