<?php
return <<<'PATTERN'
<!-- wp:cover {"useFeaturedImage":false,"dimRatio":40,"overlayColor":"ink","minHeight":640,"minHeightUnit":"px","align":"full","contentPosition":"bottom left"} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-bottom-left" style="min-height:640px">
	<span aria-hidden="true" class="wp-block-cover__background has-ink-background-color has-background-dim-40 has-background-dim"></span>
	<div class="wp-block-cover__inner-container">
		<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","right":"3rem","bottom":"3rem","left":"3rem"}}},"backgroundColor":"base","layout":{"type":"constrained","contentSize":"480px"}} -->
		<div class="wp-block-group has-base-background-color has-background" style="padding-top:3rem;padding-right:3rem;padding-bottom:3rem;padding-left:3rem">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">ISSUE 47 · SS26</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">A quieter way to dress.</h1><!-- /wp:heading -->
			<!-- wp:paragraph --><p>Six pieces. Considered fabric. Made by hand in Sydney. Made to last.</p><!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Shop the collection</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:group -->
	</div>
</div>
<!-- /wp:cover -->
PATTERN;
