<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">🎙️ HEAR FROM SARAH</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"x-large"} --><p class="has-text-align-center has-x-large-font-size">"The single best decision we made all year."</p><!-- /wp:paragraph -->
	<!-- wp:html -->
	<div style="background:#fff;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;padding:1rem 1.5rem;min-height:54px;">🎵 Paste an audio file URL or embed here</div>
	<!-- /wp:html -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size"><strong>Sarah Chen</strong> · Head of Ops, Lattice Studio</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
