<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:4rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size"><a href="#">← All open roles</a></p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-xx-large-font-size">Senior backend engineer.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Remote (Australia / NZ timezones) · Full-time · $180k-$220k AUD + equity</p><!-- /wp:paragraph -->
	<!-- wp:buttons -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Apply now</a></div><!-- /wp:button -->
		<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Share this role</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">About the role</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>We're hiring a senior backend engineer to lead the rewrite of our core sync engine — the thing that makes everything else possible. You'll own architecture, mentor two more junior engineers, and ship the next 12 months of our infrastructure roadmap.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"2.5rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:2.5rem">What you'll do</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>Design and ship the rewrite of our sync layer (Go + Postgres)</li><!-- /wp:list-item --><!-- wp:list-item --><li>Mentor two engineers via code review, pairing, and design docs</li><!-- /wp:list-item --><!-- wp:list-item --><li>Own oncall rotation for your area (one week in six)</li><!-- /wp:list-item --><!-- wp:list-item --><li>Write the engineering blog posts that explain what you build</li><!-- /wp:list-item --></ul><!-- /wp:list -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"2.5rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:2.5rem">About you</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>8+ years of backend engineering experience, ideally in product startups</li><!-- /wp:list-item --><!-- wp:list-item --><li>Strong with Go, comfortable in Postgres / distributed systems</li><!-- /wp:list-item --><!-- wp:list-item --><li>Can write clear technical documentation</li><!-- /wp:list-item --><!-- wp:list-item --><li>Bonus: open-source contributions, technical writing, talks</li><!-- /wp:list-item --></ul><!-- /wp:list -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"2.5rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:2.5rem">Benefits</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>$180k-$220k AUD + meaningful equity</li><!-- /wp:list-item --><!-- wp:list-item --><li>6 weeks paid leave (forced — we mean it)</li><!-- /wp:list-item --><!-- wp:list-item --><li>$2,500/yr learning budget, no questions</li><!-- /wp:list-item --><!-- wp:list-item --><li>Quarterly team retreats in Australia + NZ</li><!-- /wp:list-item --></ul><!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-text-align-center has-large-font-size">Sound like a fit?</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">Applications open until the role is filled. We reply to every one within 5 business days.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Apply now</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
