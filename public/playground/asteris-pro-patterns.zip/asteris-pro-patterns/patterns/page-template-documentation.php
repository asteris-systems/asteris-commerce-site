<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-text-align-center has-xx-large-font-size">Documentation.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">Everything you need to get started, from setup to advanced workflows.</p><!-- /wp:paragraph -->
	<!-- wp:search {"label":"Search","showLabel":false,"placeholder":"Search the docs…","buttonText":"Search","buttonPosition":"button-inside","align":"center"} /-->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Getting started</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li><a href="#">Quickstart</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Installation</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">First project</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Inviting your team</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Core concepts</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li><a href="#">Projects and workspaces</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Permissions and roles</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Webhooks and events</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Data model</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">API reference</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li><a href="#">Authentication</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Endpoints</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Rate limits</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Errors</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Integrations</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li><a href="#">Slack</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Zapier</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Linear</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Google</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Security</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li><a href="#">SAML SSO</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Audit log</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Data residency</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Incident response</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Troubleshooting</h3><!-- /wp:heading -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li><a href="#">Common errors</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">FAQ</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Status page</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><a href="#">Contact support</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
