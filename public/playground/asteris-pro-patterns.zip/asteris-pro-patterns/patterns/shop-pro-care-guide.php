<?php
if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">A GUIDE · 4-MIN READ</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">Care for the long run.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Looked after properly, our pieces last decades. Here's how.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">

	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Linen</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Machine wash cold on a gentle cycle. Tumble dry low or — better — hang to dry. Iron while still slightly damp for the best finish. Linen softens with every wash; it's at its best after the third.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">Wool</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Hand wash in cold water with wool detergent. Squeeze gently, never wring. Lay flat to dry away from direct sunlight. Store folded, not hung — gravity is wool's enemy. Steam to refresh between wears.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">Leather</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Wipe with a damp cloth. Condition twice a year with a wax-based product. Keep away from heat sources and direct sun. Scratches and marks are part of the story — don't try to remove them.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">Wood</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Dust weekly with a soft, dry cloth. Apply finishing oil every six months in dry climates, annually in humid ones. Keep away from radiators, fireplaces, and direct sun. Wood is alive — it'll move, expand, and contract with the seasons.</p><!-- /wp:paragraph -->

	<!-- wp:heading {"level":2,"fontSize":"x-large","style":{"spacing":{"margin":{"top":"3rem"}}}} --><h2 class="wp-block-heading has-x-large-font-size" style="margin-top:3rem">If something goes wrong</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Send it back. Repairs are free for the first ten years, at cost beyond. <a href="#">Start a repair →</a></p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
