<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:heading {"level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-xx-large-font-size">Sarah Chen</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Product designer · Sydney · <a href="mailto:hello@example.com">hello@example.com</a> · <a href="#">@sarahchen</a></p><!-- /wp:paragraph -->
	<!-- wp:paragraph --><p>Twelve years designing software that respects the user's time. Currently leading design at a small B2B SaaS. Previously at Stripe and Notion. Open to senior IC roles, advisory, or interesting problems.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">Experience</h2><!-- /wp:heading -->

	<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Lattice — Senior Designer · 2023–now</h3><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>Led the rewrite of the activity feed used by 200k+ daily users.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Shipped six end-to-end product surfaces from sketch to GA.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Hired and mentored two designers; ran the weekly design review.</li><!-- /wp:list-item --></ul><!-- /wp:list -->

	<!-- wp:heading {"level":3,"fontSize":"medium","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h3 class="wp-block-heading has-medium-font-size" style="margin-top:2rem">Notion — Product Designer · 2020–2023</h3><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>Designed the AI surface used by 30M+ users.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Owned the migrations team — how customers move from competitors.</li><!-- /wp:list-item --></ul><!-- /wp:list -->

	<!-- wp:heading {"level":3,"fontSize":"medium","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h3 class="wp-block-heading has-medium-font-size" style="margin-top:2rem">Stripe — Designer · 2017–2020</h3><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li>Dashboard team. Shipped the redesign of Reports and Insights.</li><!-- /wp:list-item --><!-- wp:list-item --><li>Wrote the internal design pattern library now used across 12 surfaces.</li><!-- /wp:list-item --></ul><!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">Education</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p><strong>UNSW</strong> — B.Des (Hons), 2013</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">Writing</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p>Essays on craft and the long game at <a href="#">sarahchen.com/writing</a>.</p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
