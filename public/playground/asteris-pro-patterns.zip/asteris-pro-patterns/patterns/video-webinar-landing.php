<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">LIVE WEBINAR · WEDNESDAY 25 JUNE · 2PM AEST</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xx-large"} --><h1 class="wp-block-heading has-text-align-center has-xx-large-font-size">How to ship 3× faster.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">A 45-minute deep dive with Q&amp;A. Free to attend, recording sent to all registrants.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Register — free</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Can't make it? Register anyway and we'll send the replay.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">What we'll cover</h2><!-- /wp:heading -->
	<!-- wp:list -->
	<ul class="wp-block-list"><!-- wp:list-item --><li>The three bottlenecks that slow most teams down</li><!-- /wp:list-item --><!-- wp:list-item --><li>The workflow shift that 10× our throughput</li><!-- /wp:list-item --><!-- wp:list-item --><li>Live Q&amp;A — bring your hardest questions</li><!-- /wp:list-item --></ul>
	<!-- /wp:list -->
</div>
<!-- /wp:group -->
PATTERN;
