<?php
return <<<'PATTERN'
<!-- wp:cover {"dimRatio":50,"overlayColor":"ink","minHeight":640,"minHeightUnit":"px","align":"full","contentPosition":"center center"} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-center" style="min-height:640px">
	<span aria-hidden="true" class="wp-block-cover__background has-ink-background-color has-background-dim-50 has-background-dim"></span>
	<div class="wp-block-cover__inner-container">
		<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large","textColor":"paper"} -->
		<h1 class="wp-block-heading has-text-align-center has-paper-color has-text-color has-xxx-large-font-size">Made in motion.</h1>
		<!-- /wp:heading -->
		<!-- wp:paragraph {"align":"center","fontSize":"large","textColor":"paper"} -->
		<p class="has-text-align-center has-paper-color has-text-color has-large-font-size">Click the cover block and upload a looping video as the background. Mute + autoplay is recommended.</p>
		<!-- /wp:paragraph -->
		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Watch the film</a></div><!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
</div>
<!-- /wp:cover -->
PATTERN;
