<?php
return <<<'PATTERN'
<!-- wp:cover {"dimRatio":60,"overlayColor":"ink","minHeight":640,"minHeightUnit":"px","align":"full","contentPosition":"center center"} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-center" style="min-height:640px">
	<span aria-hidden="true" class="wp-block-cover__background has-ink-background-color has-background-dim-60 has-background-dim"></span>
	<div class="wp-block-cover__inner-container">
		<!-- wp:paragraph {"align":"center","fontSize":"small","textColor":"paper"} --><p class="has-text-align-center has-paper-color has-text-color has-small-font-size">A FILM BY SARAH CHEN · 2026 · 87 MIN</p><!-- /wp:paragraph -->
		<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large","textColor":"paper"} --><h1 class="wp-block-heading has-text-align-center has-paper-color has-text-color has-xxx-large-font-size">Long Light.</h1><!-- /wp:heading -->
		<!-- wp:paragraph {"align":"center","fontSize":"medium","textColor":"paper"} --><p class="has-text-align-center has-paper-color has-text-color has-medium-font-size">A documentary about patient work, slow growth, and the people who do it.</p><!-- /wp:paragraph -->
		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Watch trailer</a></div><!-- /wp:button -->
			<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Find a screening</a></div><!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
</div>
<!-- /wp:cover -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">The story.</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Filmed over three years across four countries. Long Light follows the lives of six people who built something patient — a farmer, a luthier, a typeface designer, a bookbinder, a watchmaker, a writer.</p><!-- /wp:paragraph -->
	<!-- wp:paragraph --><p>Nobody in this film is famous. Nobody is rich. Every one of them is doing some of the best work of their life. That's the only thing they have in common.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">★★★★★ "DEEPLY MOVING." — THE GUARDIAN  ·  "ESSENTIAL." — SIGHT &amp; SOUND  ·  "RARE AND BEAUTIFUL." — INDIEWIRE</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Screenings.</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li><strong>SYDNEY</strong> — Dendy Newtown · 12 SEP, 7pm · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>MELBOURNE</strong> — ACMI · 18 SEP, 6:30pm · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>BERLIN</strong> — Zukunft am Ostkreuz · 02 OCT · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>NEW YORK</strong> — IFC Center · 14 OCT · <a href="#">Tickets</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
	<!-- wp:paragraph --><p>Or stream it from 1 November on Apple TV, Mubi, and the major platforms.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
