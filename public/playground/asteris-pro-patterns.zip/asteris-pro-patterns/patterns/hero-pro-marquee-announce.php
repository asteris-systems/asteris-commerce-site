<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"0.75rem","bottom":"0.75rem","left":"0","right":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:0.75rem;padding-right:0;padding-bottom:0.75rem;padding-left:0">
	<!-- wp:html -->
	<div style="overflow:hidden;mask-image:linear-gradient(to right, transparent, black 5%, black 95%, transparent);">
		<div style="display:flex;gap:3rem;animation:asteris-marquee-hero 35s linear infinite;width:max-content;font-weight:600;font-size:.95rem;">
			<span>✨ NEW: Asteris v3.0 is live</span><span>·</span><span>Free shipping on orders over $75</span><span>·</span><span>30-day money-back guarantee</span><span>·</span><span>Save 20% with code ASTERIS20</span><span>·</span><span>✨ NEW: Asteris v3.0 is live</span><span>·</span><span>Free shipping on orders over $75</span><span>·</span><span>30-day money-back guarantee</span><span>·</span><span>Save 20% with code ASTERIS20</span>
		</div>
		<style>@keyframes asteris-marquee-hero{from{transform:translateX(0)}to{transform:translateX(-50%)}}</style>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:6rem;padding-right:2rem;padding-bottom:6rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">Built for teams that ship.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"large"} --><p class="has-text-align-center has-large-font-size">A focused, fast, opinionated tool. Most teams are up and running in under an hour.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Start free trial</a></div><!-- /wp:button -->
		<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Book a demo</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
