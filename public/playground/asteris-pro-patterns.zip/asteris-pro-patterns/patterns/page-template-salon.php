<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">EST. 2012 · SURRY HILLS</p><!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">Mara Hair.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">A small Sydney studio. Six chairs. Senior stylists only. Nothing rushed.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Book online</a></div><!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">Services</h2><!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"2rem"},"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px;margin-top:2rem">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem"><!-- wp:paragraph --><p><strong>Cut &amp; finish</strong><br><em>60-90 min · senior stylist</em></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem;flex-basis:30%"><!-- wp:paragraph {"align":"right"} --><p class="has-text-align-right"><strong>From $145</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem"><!-- wp:paragraph --><p><strong>Colour — single process</strong><br><em>2-3 hr · includes consult</em></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem;flex-basis:30%"><!-- wp:paragraph {"align":"right"} --><p class="has-text-align-right"><strong>From $220</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}},"border":{"bottom":{"width":"1px","color":"#e5e5e5"}}}} -->
	<div class="wp-block-columns" style="border-bottom-color:#e5e5e5;border-bottom-width:1px">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem"><!-- wp:paragraph --><p><strong>Balayage / dimensional</strong><br><em>3-4 hr · quote on consult</em></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem;flex-basis:30%"><!-- wp:paragraph {"align":"right"} --><p class="has-text-align-right"><strong>From $385</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem"><!-- wp:paragraph --><p><strong>Bridal &amp; events</strong><br><em>Off-site, by appointment</em></p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column {"width":"30%","style":{"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem"}}}} --><div class="wp-block-column" style="padding-top:1.25rem;padding-bottom:1.25rem;flex-basis:30%"><!-- wp:paragraph {"align":"right"} --><p class="has-text-align-right"><strong>From $480</strong></p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-text-align-center has-large-font-size">Visit us.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">123 Crown Street<br>Surry Hills NSW 2010</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">Tue-Sat 10-6 · Closed Sun-Mon</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
