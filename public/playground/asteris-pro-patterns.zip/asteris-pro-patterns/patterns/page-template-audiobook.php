<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
			<!-- wp:image --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt="Audiobook cover"/></figure><!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">UNABRIDGED · 8H 42M · READ BY THE AUTHOR</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">The Long Game.</h1><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Now in audio. Eight hours of patient, considered listening, read by the author in one continuous voice.</p><!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Audible</a></div><!-- /wp:button -->
				<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Apple Books</a></div><!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Libro.fm</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">LISTEN TO THE FIRST CHAPTER · FREE</p><!-- /wp:paragraph -->
	<!-- wp:html -->
	<div style="background:#fff;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;padding:1rem 1.5rem;min-height:54px;">🎵 Paste an audio file URL here (chapter 1 preview)</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Chapters.</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li><strong>1.</strong> The long view · <em>47 min</em></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>2.</strong> Why patience pays · <em>52 min</em></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>3.</strong> The first decade · <em>61 min</em></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>4.</strong> Seasons of work · <em>48 min</em></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>5.</strong> Saying no slowly · <em>55 min</em></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>6.</strong> The next decade · <em>49 min</em></li><!-- /wp:list-item --></ul><!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"x-large"} --><p class="has-text-align-center has-x-large-font-size">"Required listening."</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">— THE NEW YORK TIMES</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
PATTERN;
