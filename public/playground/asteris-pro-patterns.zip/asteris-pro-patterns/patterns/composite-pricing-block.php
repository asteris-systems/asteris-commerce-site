<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"xx-large"} --><h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">Simple pricing.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">Three flat tiers. Switch any time. Cancel in one click.</p><!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"3rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:3rem">
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Starter</h3><!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"x-large"} --><h4 class="wp-block-heading has-x-large-font-size">$19/mo</h4><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">For solo founders.</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"width":100,"className":"is-style-outline"} --><div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Starter</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>✓ 1 site</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 10 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Email support</li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size"><strong>MOST POPULAR</strong></p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Pro</h3><!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"x-large"} --><h4 class="wp-block-heading has-x-large-font-size">$49/mo</h4><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">For growing teams.</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"paper","textColor":"ink","width":100} --><div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Choose Pro</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>✓ 5 sites</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 100 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Priority support</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ All integrations</li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
		<div class="wp-block-column has-subtle-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
			<!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Agency</h3><!-- /wp:heading -->
			<!-- wp:heading {"level":4,"fontSize":"x-large"} --><h4 class="wp-block-heading has-x-large-font-size">$149/mo</h4><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">For agencies.</p><!-- /wp:paragraph -->
			<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"width":100,"className":"is-style-outline"} --><div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Choose Agency</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
			<!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>✓ 25 sites</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ 500 GB storage</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ White-label</li><!-- /wp:list-item --><!-- wp:list-item --><li>✓ Everything in Pro</li><!-- /wp:list-item --></ul><!-- /wp:list -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} --><h3 class="wp-block-heading has-text-align-center has-large-font-size">Common questions.</h3><!-- /wp:heading -->
	<!-- wp:details --><details class="wp-block-details"><summary>Can I change plans later?</summary><!-- wp:paragraph --><p>Up or down, any time, from your account page.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>Is there a free trial?</summary><!-- wp:paragraph --><p>14 days, no card required.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>Do you offer refunds?</summary><!-- wp:paragraph --><p>30 days, full refund, no questions.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">Try it free for 14 days.</h2><!-- /wp:heading -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Start free trial</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
