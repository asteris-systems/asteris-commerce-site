<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">🎵 LISTEN WHILE YOU WORK</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Office playlist.</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>The tracks we keep on loop at the office. Updated whenever someone good comes along.</p><!-- /wp:paragraph -->
	<!-- wp:html -->
	<div style="background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:8px;min-height:152px;padding:2rem;">🎵 Paste a Spotify playlist URL here</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
PATTERN;
