<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","backgroundColor":"ink","textColor":"paper","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-paper-color has-ink-background-color has-text-color has-background" style="padding-top:6rem;padding-right:2rem;padding-bottom:6rem;padding-left:2rem">
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%">
			<!-- wp:image --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt="Album artwork"/></figure><!-- /wp:image -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%">
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">NEW ALBUM · OUT NOW</p><!-- /wp:paragraph -->
			<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">Long Light.</h1><!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">10 tracks · 42 minutes · Recorded live in one room, five days, no overdubs.</p><!-- /wp:paragraph -->
			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Spotify</a></div><!-- /wp:button -->
				<!-- wp:button {"backgroundColor":"paper","textColor":"ink"} --><div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-paper-background-color has-text-color has-background wp-element-button" href="#">Apple Music</a></div><!-- /wp:button -->
				<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Bandcamp</a></div><!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Tracklist.</h2><!-- /wp:heading -->
	<!-- wp:list {"ordered":true} --><ol class="wp-block-list"><!-- wp:list-item --><li>First Light · <em>3:42</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Sunday Drive · <em>4:18</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Where the Sky Went · <em>5:01</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Slow Hands · <em>3:55</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Honest Work · <em>4:33</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>The Long Way Home · <em>5:14</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Tuesday Morning · <em>3:28</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Quiet Years · <em>4:47</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Borrowed Time · <em>3:51</em></li><!-- /wp:list-item --><!-- wp:list-item --><li>Long Light · <em>5:22</em></li><!-- /wp:list-item --></ol><!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:paragraph {"align":"center","fontSize":"x-large"} --><p class="has-text-align-center has-x-large-font-size">"The kind of record that meets you where you are."</p><!-- /wp:paragraph -->
	<!-- wp:paragraph {"align":"center","fontSize":"small"} --><p class="has-text-align-center has-small-font-size">— PITCHFORK · 8.4 / 10</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">On tour.</h2><!-- /wp:heading -->
	<!-- wp:list --><ul class="wp-block-list"><!-- wp:list-item --><li><strong>18 SEP</strong> — Sydney · Enmore Theatre · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>22 SEP</strong> — Melbourne · The Forum · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>27 SEP</strong> — Brisbane · The Tivoli · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>04 OCT</strong> — Auckland · Powerstation · <a href="#">Tickets</a></li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>11 OCT</strong> — London · Lafayette · <a href="#">Tickets</a></li><!-- /wp:list-item --></ul><!-- /wp:list -->
</div>
<!-- /wp:group -->
PATTERN;
