<?php
if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-text-align-center has-xxx-large-font-size">Find us in store.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center","fontSize":"medium"} --><p class="has-text-align-center has-medium-font-size">Stocked in 48 carefully chosen retailers across Australia, NZ, the UK, and the US.</p><!-- /wp:paragraph -->
	<!-- wp:search {"label":"Search","showLabel":false,"placeholder":"Search by city or postcode…","buttonText":"Search","buttonPosition":"button-inside"} /-->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"760px"}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">

	<!-- wp:heading {"level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-large-font-size">Australia</h2><!-- /wp:heading -->
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p><strong>SYDNEY</strong></p><!-- /wp:paragraph --><!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>The Standard Store · Surry Hills</li><!-- /wp:list-item --><!-- wp:list-item --><li>Incu · Paddington</li><!-- /wp:list-item --><!-- wp:list-item --><li>Mecca · CBD</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p><strong>MELBOURNE</strong></p><!-- /wp:paragraph --><!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>Lazy Susan · Fitzroy</li><!-- /wp:list-item --><!-- wp:list-item --><li>Provider Store · South Yarra</li><!-- /wp:list-item --><!-- wp:list-item --><li>Mecca · Chadstone</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:2rem">New Zealand</h2><!-- /wp:heading -->
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p><strong>AUCKLAND</strong></p><!-- /wp:paragraph --><!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>Father Rabbit · Ponsonby</li><!-- /wp:list-item --><!-- wp:list-item --><li>Iko Iko · Newmarket</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p><strong>WELLINGTON</strong></p><!-- /wp:paragraph --><!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>Small Acorns · Cuba St</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:heading {"level":2,"fontSize":"large","style":{"spacing":{"margin":{"top":"2rem"}}}} --><h2 class="wp-block-heading has-large-font-size" style="margin-top:2rem">United Kingdom</h2><!-- /wp:heading -->
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p><strong>LONDON</strong></p><!-- /wp:paragraph --><!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>Liberty · Soho</li><!-- /wp:list-item --><!-- wp:list-item --><li>Goodhood · Shoreditch</li><!-- /wp:list-item --><!-- wp:list-item --><li>The Conran Shop · Marylebone</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:paragraph --><p><strong>BRISTOL</strong></p><!-- /wp:paragraph --><!-- wp:list {"fontSize":"small"} --><ul class="wp-block-list has-small-font-size"><!-- wp:list-item --><li>The Bristol Store · Park Street</li><!-- /wp:list-item --></ul><!-- /wp:list --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"large"} --><h2 class="wp-block-heading has-text-align-center has-large-font-size">Not near a stockist?</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">Free shipping over $75. Direct to your door, anywhere.</p><!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/shop/">Shop online</a></div><!-- /wp:button --></div><!-- /wp:buttons -->
</div>
<!-- /wp:group -->
PATTERN;
