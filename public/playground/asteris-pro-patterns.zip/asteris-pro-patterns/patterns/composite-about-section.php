<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"3rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group alignfull" style="padding-top:6rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">WHO WE ARE</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":2,"fontSize":"xxx-large"} --><h2 class="wp-block-heading has-xxx-large-font-size">A small team doing patient work.</h2><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"large"} --><p class="has-large-font-size">Six people, four cities, one Slack space. We've been building together since 2022, shipping things we wish existed.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"x-large"} --><h3 class="wp-block-heading has-text-align-center has-x-large-font-size">What we value.</h3><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"3rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:3rem">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":4,"fontSize":"medium"} --><h4 class="wp-block-heading has-medium-font-size">Honesty</h4><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">We say what we mean. No dark patterns, no inflated claims.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":4,"fontSize":"medium"} --><h4 class="wp-block-heading has-medium-font-size">Craft</h4><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">We sweat the details others skip. Performance, accessibility, polish.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:heading {"level":4,"fontSize":"medium"} --><h4 class="wp-block-heading has-medium-font-size">Patience</h4><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">We're building something that lasts decades. We're not in a hurry.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"textAlign":"center","level":3,"fontSize":"x-large"} --><h3 class="wp-block-heading has-text-align-center has-x-large-font-size">The team.</h3><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"3rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:3rem">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":4,"fontSize":"medium"} --><h4 class="wp-block-heading has-medium-font-size">Sarah Chen</h4><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Founder &amp; CEO</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":4,"fontSize":"medium"} --><h4 class="wp-block-heading has-medium-font-size">Alex Morgan</h4><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Engineering</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":4,"fontSize":"medium"} --><h4 class="wp-block-heading has-medium-font-size">Priya Iyer</h4><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Design</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:heading {"level":4,"fontSize":"medium"} --><h4 class="wp-block-heading has-medium-font-size">Jack Williams</h4><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">Support</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
