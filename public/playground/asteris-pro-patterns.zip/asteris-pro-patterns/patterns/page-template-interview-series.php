<?php
return <<<'PATTERN'
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">A CONVERSATIONS SERIES · NEW EVERY MONTH</p><!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"fontSize":"xxx-large"} --><h1 class="wp-block-heading has-xxx-large-font-size">In their own words.</h1><!-- /wp:heading -->
	<!-- wp:paragraph {"fontSize":"medium"} --><p class="has-medium-font-size">Long conversations with people doing patient work. Video, audio, transcript.</p><!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
	<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">LATEST CONVERSATION</p><!-- /wp:paragraph -->
	<!-- wp:columns {"verticalAlignment":"center"} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%">
			<!-- wp:html -->
			<div style="aspect-ratio:16/9;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#777;font-size:.95rem;border-radius:4px;">▶ Paste a YouTube or Vimeo URL here</div>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%">
			<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">Sarah Chen</h2><!-- /wp:heading -->
			<!-- wp:paragraph --><p>Founder of Lattice Studio. On building in public, the seasons of a company, and what changes when you finally start trusting your instincts.</p><!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">▶ 48 MIN · <a href="#">Watch</a> · <a href="#">Listen</a> · <a href="#">Read</a></p><!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:5rem;padding-right:2rem;padding-bottom:5rem;padding-left:2rem">
	<!-- wp:heading {"level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-x-large-font-size">The archive.</h2><!-- /wp:heading -->
	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"3rem"}}}} -->
	<div class="wp-block-columns" style="margin-top:3rem">
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">JUL 2026 · 41 MIN</p><!-- /wp:paragraph --><!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Alex Morgan</h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">On engineering at scale.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">JUN 2026 · 55 MIN</p><!-- /wp:paragraph --><!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Priya Iyer</h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">On the team behind the team.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
		<!-- wp:column --><div class="wp-block-column"><!-- wp:image {"url":"{{PLACEHOLDER_URL}}"} --><figure class="wp-block-image"><img src="{{PLACEHOLDER_URL}}" alt=""/></figure><!-- /wp:image --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">MAY 2026 · 38 MIN</p><!-- /wp:paragraph --><!-- wp:heading {"level":3,"fontSize":"medium"} --><h3 class="wp-block-heading has-medium-font-size">Jack Williams</h3><!-- /wp:heading --><!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">On staying small on purpose.</p><!-- /wp:paragraph --></div><!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
PATTERN;
