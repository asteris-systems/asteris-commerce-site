<?php
/**
 * Uninstall: clean up our options.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'asteris_pro_patterns_license' );
delete_option( 'asteris_pro_patterns_instance_name' );
delete_transient( 'asteris_pro_patterns_license_status' );
delete_transient( 'asteris_pro_patterns_show_welcome' );
