<?php
/**
 * @package AsterisProPatterns
 *
 * Plugin boot — wires the licence check + pattern registry + settings page.
 */

namespace AsterisProPatterns;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	public function boot(): void {
		License::register_auto_activate();
		$license = new License();
		( new Settings( $license ) )->register();
		( new Patterns( $license ) )->register();
	}
}
