<?php
/**
 * @package AsterisProPatterns
 *
 * Admin page: Settings → Asteris Pro Patterns.
 * Licence activation form + status + how-it-works copy.
 *
 * Uses admin-post.php pattern, not Settings API.
 */

namespace AsterisProPatterns;

defined( 'ABSPATH' ) || exit;

final class Settings {

	public function __construct( private License $license ) {}

	public function register(): void {
		add_action( 'admin_menu',                                       [ $this, 'menu' ] );
		add_action( 'admin_post_asteris_pro_patterns_save_license',     [ $this, 'save' ] );
		add_action( 'admin_post_asteris_pro_patterns_deactivate',       [ $this, 'deactivate' ] );
		add_action( 'admin_notices',                                    [ $this, 'maybe_notice' ] );
	}

	public function menu(): void {
		add_options_page(
			__( 'Asteris Pro Patterns', 'asteris-pro-patterns' ),
			__( 'Asteris Pro Patterns', 'asteris-pro-patterns' ),
			'manage_options',
			'asteris-pro-patterns',
			[ $this, 'render' ]
		);
	}

	public function maybe_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		if ( $this->license->is_active() )            { return; }

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && in_array( $screen->id, [ 'settings_page_asteris-pro-patterns', 'plugins' ], true ) ) {
			return; // Don't shout at users who are already looking at the settings.
		}

		$url = esc_url( admin_url( 'options-general.php?page=asteris-pro-patterns' ) );
		echo '<div class="notice notice-info is-dismissible"><p><strong>Asteris Pro Patterns</strong> — '
			. esc_html__( 'Activate your licence to unlock 50+ premium patterns.', 'asteris-pro-patterns' )
			. ' <a href="' . $url . '">' . esc_html__( 'Activate now', 'asteris-pro-patterns' ) . '</a></p></div>';
	}

	public function save(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
		check_admin_referer( 'asteris_pro_patterns_save_license' );

		$key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['license_key'] ) ) : '';
		[ $ok, $msg ] = $this->license->activate( $key );

		$redirect = add_query_arg( [
			'page'    => 'asteris-pro-patterns',
			'saved'   => $ok ? 1 : 0,
			'message' => rawurlencode( $msg ),
		], admin_url( 'options-general.php' ) );

		wp_safe_redirect( $redirect );
		exit;
	}

	public function deactivate(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
		check_admin_referer( 'asteris_pro_patterns_deactivate' );

		$this->license->deactivate();

		wp_safe_redirect( add_query_arg( [
			'page'    => 'asteris-pro-patterns',
			'saved'   => 1,
			'message' => rawurlencode( __( 'Licence deactivated.', 'asteris-pro-patterns' ) ),
		], admin_url( 'options-general.php' ) ) );
		exit;
	}

	public function render(): void {
		$state    = $this->license->state();
		$active   = $this->license->is_active();
		$key      = $this->license->get_key();
		$message  = isset( $_GET['message'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['message'] ) ) : '';
		$is_error = isset( $_GET['saved'] ) && '0' === (string) $_GET['saved'];
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Asteris Pro Patterns', 'asteris-pro-patterns' ); ?></h1>

			<?php if ( $message ) : ?>
				<div class="notice <?php echo $is_error ? 'notice-error' : 'notice-success'; ?> is-dismissible"><p><?php echo esc_html( $message ); ?></p></div>
			<?php endif; ?>

			<?php if ( $active ) : ?>
				<div class="card" style="max-width:680px;padding:16px 24px;">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Licence active', 'asteris-pro-patterns' ); ?> ✓</h2>
					<p><?php esc_html_e( 'All 50+ premium patterns are available in the inserter under the Asteris categories.', 'asteris-pro-patterns' ); ?></p>
					<p style="color:#666;font-size:13px;">
						<?php esc_html_e( 'Licence key', 'asteris-pro-patterns' ); ?>: <code><?php echo esc_html( $this->mask_key( $key ) ); ?></code><br>
						<?php esc_html_e( 'Last checked', 'asteris-pro-patterns' ); ?>: <?php echo esc_html( $state ? date_i18n( 'Y-m-d H:i', (int) ( $state['checked_at'] ?? 0 ) ) : '—' ); ?>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'asteris_pro_patterns_deactivate' ); ?>
						<input type="hidden" name="action" value="asteris_pro_patterns_deactivate"/>
						<button type="submit" class="button"><?php esc_html_e( 'Deactivate on this site', 'asteris-pro-patterns' ); ?></button>
					</form>
				</div>
			<?php else : ?>
				<div class="card" style="max-width:680px;padding:16px 24px;">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Activate your licence', 'asteris-pro-patterns' ); ?></h2>
					<p><?php esc_html_e( "Paste the licence key from your purchase confirmation email below. Don't have one? Get one in 60 seconds:", 'asteris-pro-patterns' ); ?></p>
					<p><a href="https://asteriscommerce.com/asteris-pro-patterns/" target="_blank" rel="noopener" class="button button-primary"><?php esc_html_e( 'Buy a licence →', 'asteris-pro-patterns' ); ?></a></p>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:24px;">
						<?php wp_nonce_field( 'asteris_pro_patterns_save_license' ); ?>
						<input type="hidden" name="action" value="asteris_pro_patterns_save_license"/>
						<label for="apppl_key" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Licence key', 'asteris-pro-patterns' ); ?></label>
						<input type="text" id="apppl_key" name="license_key" class="regular-text code" style="width:100%;max-width:480px;" placeholder="ASTW-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX" value="<?php echo esc_attr( $key ); ?>"/>
						<?php if ( '' !== $key ) : ?>
							<p style="color:#00802b;font-size:13px;margin-top:4px;">✓ <?php esc_html_e( 'Licence key pre-filled by the Asteris Installer — click Activate to validate.', 'asteris-pro-patterns' ); ?></p>
						<?php endif; ?>
						<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Activate', 'asteris-pro-patterns' ); ?></button></p>
					</form>
				</div>
			<?php endif; ?>

			<div class="card" style="max-width:680px;padding:16px 24px;margin-top:24px;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'What you get', 'asteris-pro-patterns' ); ?></h2>
				<ul style="margin:0;">
					<li>8 niche page templates (Portfolio, Personal, Membership, Charity, Real estate, Wedding, Book launch, App landing)</li>
					<li>5 vertical-niche landings (SaaS, Agency, Course, Podcast, Restaurant)</li>
					<li>7 premium e-commerce patterns</li>
					<li>10 video patterns (showcase, lessons, webinars, case studies, channel)</li>
					<li>8 audio patterns (Spotify, SoundCloud, podcast series, music)</li>
					<li>6 advanced content patterns (changelog, roadmap, press kit, careers, etc.)</li>
				</ul>
			</div>
		</div>
		<?php
	}

	private function mask_key( string $key ): string {
		if ( strlen( $key ) < 8 ) { return str_repeat( '•', strlen( $key ) ); }
		return substr( $key, 0, 4 ) . '••••••••••••' . substr( $key, -4 );
	}
}
