<?php
/**
 * @package AsterisProPatterns
 *
 * Licence client — mirrors the proven WC pattern (Asteris\Core\License).
 *
 * SINGLE SOURCE OF TRUTH for the licence key:
 *   asteris_pro_patterns_license_key (plain string).
 *
 * The Asteris Installer pre-seeds this option on install. The Settings form
 * reads and displays this option. The `admin_init` auto-activate hook reads
 * this option and POSTs to /license/activate if state is not yet valid.
 * NEVER deleted on activation — only by an explicit Deactivate action.
 *
 * State cache lives in asteris_pro_patterns_license_state (structured array
 * with `valid` + `checked_at`). Read by is_active() to avoid hitting the
 * server on every page load.
 *
 * Raw wp_remote_post per feedback_proven_path_over_wrapper.md.
 */

namespace AsterisProPatterns;

defined( 'ABSPATH' ) || exit;

final class License {

	public const OPT_KEY    = 'asteris_pro_patterns_license_key';
	public const OPT_STATE  = 'asteris_pro_patterns_license_state';
	private const VALIDATE_TTL = 12 * HOUR_IN_SECONDS;

	/**
	 * Register the auto-activate hook. Called once from the plugin bootstrap.
	 * Mirrors Asteris\Core\License::register_auto_activate().
	 *
	 * The moment a key lands in OPT_KEY (Installer pre-seed OR Settings paste),
	 * the next admin page load activates it server-side without requiring the
	 * customer to click anything. Priority 5 so it runs before module guards.
	 */
	public static function register_auto_activate(): void {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_init', static function (): void {
			$state = (array) get_option( self::OPT_STATE, [] );
			if ( ( $state['valid'] ?? false ) === true ) {
				return;
			}
			$key = (string) get_option( self::OPT_KEY, '' );
			if ( '' === $key ) {
				return;
			}
			( new self() )->raw_activate( $key );
		}, 5 );
	}

	/** Stored state cache. */
	public function state(): array {
		return (array) get_option( self::OPT_STATE, [] );
	}

	/** Plain-string licence key (what Installer pre-seeds and Settings displays). */
	public function get_key(): string {
		return (string) get_option( self::OPT_KEY, '' );
	}

	/** True when the cached state is valid and within TTL. */
	public function is_active(): bool {
		if ( defined( 'ASTERIS_PRO_PATTERNS_DEV' ) && ASTERIS_PRO_PATTERNS_DEV ) {
			return true;
		}
		$state = $this->state();
		if ( ( $state['valid'] ?? false ) !== true ) {
			return false;
		}
		return true;
	}

	/**
	 * Public activate — called from the Settings form submit handler.
	 * Writes the key to OPT_KEY, then runs raw_activate which writes OPT_STATE.
	 */
	public function activate( string $key ): array {
		$key = trim( $key );
		if ( '' === $key ) {
			return [ false, __( 'Please enter a licence key.', 'asteris-pro-patterns' ) ];
		}
		update_option( self::OPT_KEY, $key, false );
		$result = $this->raw_activate( $key );
		if ( true === $result ) {
			return [ true, __( 'Licence activated. Premium patterns are now available.', 'asteris-pro-patterns' ) ];
		}
		$msg = is_wp_error( $result ) ? $result->get_error_message() : __( 'Activation failed.', 'asteris-pro-patterns' );
		return [ false, $msg ];
	}

	/**
	 * Raw POST to /license/activate. Writes OPT_STATE with the result.
	 * Returns true on success, WP_Error on failure.
	 */
	public function raw_activate( string $key ) {
		$key = trim( $key );
		if ( '' === $key ) {
			return new \WP_Error( 'no_key', __( 'No licence key provided.', 'asteris-pro-patterns' ) );
		}

		$response = wp_remote_post( ASTERIS_LS_ENDPOINT . '/license/activate', [
			'timeout' => 20,
			'body'    => [
				'product'       => ASTERIS_PRO_PATTERNS_SLUG,
				'license_key'   => $key,
				'instance_name' => $this->instance_name(),
				'site_url'      => home_url(),
			],
		] );

		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'network_error', $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || ! is_array( $body ) || empty( $body['ok'] ) ) {
			$msg = is_array( $body ) && ! empty( $body['error'] )
				? (string) $body['error']
				: __( 'Activation failed.', 'asteris-pro-patterns' );
			update_option( self::OPT_STATE, [
				'valid'      => false,
				'error'      => $msg,
				'checked_at' => time(),
			], false );
			return new \WP_Error( 'activate_failed', $msg );
		}

		update_option( self::OPT_STATE, [
			'valid'      => true,
			'site_token' => (string) ( $body['site_token'] ?? '' ),
			'checked_at' => time(),
		], false );

		return true;
	}

	/** Deactivate locally + on server. */
	public function deactivate(): void {
		$key = $this->get_key();
		if ( '' !== $key ) {
			wp_remote_post( ASTERIS_LS_ENDPOINT . '/license/deactivate', [
				'timeout' => 10,
				'body'    => [
					'product'       => ASTERIS_PRO_PATTERNS_SLUG,
					'license_key'   => $key,
					'instance_name' => $this->instance_name(),
					'site_url'      => home_url(),
				],
			] );
		}
		delete_option( self::OPT_KEY );
		delete_option( self::OPT_STATE );
	}

	private function instance_name(): string {
		$name = get_option( 'asteris_pro_patterns_instance_name' );
		if ( ! is_string( $name ) || '' === $name ) {
			$name = wp_generate_uuid4();
			update_option( 'asteris_pro_patterns_instance_name', $name, false );
		}
		return (string) $name;
	}
}
