<?php
/**
 * @package AsterisProPatterns
 *
 * Pattern registry — registers all premium patterns when the licence
 * is active, registers a single "Activate to unlock" pattern otherwise.
 *
 * Patterns live under categories registered by the free Asteris theme
 * (asteris-video, asteris-audio, asteris-page-templates, etc.) so the
 * inserter UX stays consistent whether the plugin is active or not.
 */

namespace AsterisProPatterns;

defined( 'ABSPATH' ) || exit;

final class Patterns {

	public const PATTERNS = [
		// Video (10)
		'video-testimonials-grid'  => [ 'title' => 'Video — testimonials grid',         'categories' => [ 'asteris-video', 'asteris-testimonials' ] ],
		'video-course-grid'        => [ 'title' => 'Video — course / lessons grid',     'categories' => [ 'asteris-video' ] ],
		'video-lesson-single'      => [ 'title' => 'Video — single lesson with transcript', 'categories' => [ 'asteris-video' ] ],
		'video-webinar-landing'    => [ 'title' => 'Video — webinar landing',           'categories' => [ 'asteris-video' ] ],
		'video-case-study'         => [ 'title' => 'Video — case study',                'categories' => [ 'asteris-video' ] ],
		'video-youtube-channel'    => [ 'title' => 'Video — YouTube channel hero',      'categories' => [ 'asteris-video' ] ],
		'video-live-stream'        => [ 'title' => 'Video — live stream landing',       'categories' => [ 'asteris-video' ] ],
		'video-autoplay-bg'        => [ 'title' => 'Video — autoplay background hero',  'categories' => [ 'asteris-video' ] ],

		// Audio (8)
		'audio-spotify-playlist'   => [ 'title' => 'Audio — Spotify playlist embed',    'categories' => [ 'asteris-audio' ] ],
		'audio-soundcloud-track'   => [ 'title' => 'Audio — SoundCloud track',          'categories' => [ 'asteris-audio' ] ],
		'audio-podcast-show-hero'  => [ 'title' => 'Audio — Podcast series hero',       'categories' => [ 'asteris-audio' ] ],
		'audio-episode-archive'    => [ 'title' => 'Audio — Episode archive list',      'categories' => [ 'asteris-audio' ] ],
		'audio-listen-on-strip'    => [ 'title' => 'Audio — Listen-on multi-platform',  'categories' => [ 'asteris-audio' ] ],
		'audio-testimonial'        => [ 'title' => 'Audio — Testimonial card',          'categories' => [ 'asteris-audio', 'asteris-testimonials' ] ],
		'audio-album-hero'         => [ 'title' => 'Audio — Music album hero',          'categories' => [ 'asteris-audio' ] ],
		'audio-featured-episodes'  => [ 'title' => 'Audio — Featured episodes carousel','categories' => [ 'asteris-audio' ] ],

		// Page templates — premium niche (20 planned, 12 shipped in 1.1.0)
		'page-template-resume'              => [ 'title' => 'Page — Resume / CV',           'categories' => [ 'asteris-page-templates' ] ],
		'page-template-documentation'       => [ 'title' => 'Page — Documentation landing', 'categories' => [ 'asteris-page-templates' ] ],
		'page-template-sales-long'          => [ 'title' => 'Page — Long-form sales page',  'categories' => [ 'asteris-page-templates' ] ],
		'page-template-webinar-registration'=> [ 'title' => 'Page — Webinar registration',  'categories' => [ 'asteris-page-templates' ] ],
		'page-template-lead-magnet'         => [ 'title' => 'Page — Lead magnet / free download', 'categories' => [ 'asteris-page-templates' ] ],
		'page-template-job-posting'         => [ 'title' => 'Page — Job posting (single role)', 'categories' => [ 'asteris-page-templates' ] ],
		'page-template-case-study'          => [ 'title' => 'Page — Case study (single client)', 'categories' => [ 'asteris-page-templates' ] ],
		'page-template-thank-you'           => [ 'title' => 'Page — Thank you / order confirmation', 'categories' => [ 'asteris-page-templates' ] ],
		'page-template-maintenance'         => [ 'title' => 'Page — Maintenance mode',      'categories' => [ 'asteris-page-templates' ] ],
		'page-template-vs-competitor'       => [ 'title' => 'Page — vs Competitor',         'categories' => [ 'asteris-page-templates' ] ],
		'page-template-restaurant-menu'     => [ 'title' => 'Page — Restaurant menu',       'categories' => [ 'asteris-page-templates' ] ],
		'page-template-coach'               => [ 'title' => 'Page — Coach / consultant',    'categories' => [ 'asteris-page-templates' ] ],

		// Page templates — niche verticals (dual-tagged for discovery)
		'page-template-photographer'        => [ 'title' => 'Page — Photographer portfolio','categories' => [ 'asteris-page-templates', 'asteris-portfolio' ] ],
		'page-template-music-artist'        => [ 'title' => 'Page — Music artist / band',    'categories' => [ 'asteris-page-templates', 'asteris-audio' ] ],
		'page-template-conference'          => [ 'title' => 'Page — Conference / event',     'categories' => [ 'asteris-page-templates' ] ],
		'page-template-author'              => [ 'title' => 'Page — Author / writer',        'categories' => [ 'asteris-page-templates', 'asteris-blog' ] ],
		'page-template-salon'               => [ 'title' => 'Page — Salon / service business','categories' => [ 'asteris-page-templates' ] ],
		'page-template-fitness'             => [ 'title' => 'Page — Fitness / yoga studio',  'categories' => [ 'asteris-page-templates' ] ],
		'page-template-tutorial'            => [ 'title' => 'Page — Tutorial / how-to',      'categories' => [ 'asteris-page-templates', 'asteris-video' ] ],

		// Sectional pattern (composes into the Conference page)
		'section-speakers-lineup'           => [ 'title' => 'Section — Speakers / event lineup', 'categories' => [ 'asteris-page-sections' ] ],

		// Multimedia page templates (full pages composing audio/video into starters)
		'page-template-podcast-show'        => [ 'title' => 'Page — Podcast show landing',  'categories' => [ 'asteris-page-templates', 'asteris-audio' ] ],
		'page-template-video-course'        => [ 'title' => 'Page — Video course landing',  'categories' => [ 'asteris-page-templates', 'asteris-video' ] ],
		'page-template-music-album'         => [ 'title' => 'Page — Music album release',   'categories' => [ 'asteris-page-templates', 'asteris-audio' ] ],
		'page-template-virtual-event'       => [ 'title' => 'Page — Virtual event / online conference', 'categories' => [ 'asteris-page-templates', 'asteris-video' ] ],
		'page-template-documentary'         => [ 'title' => 'Page — Documentary / film',    'categories' => [ 'asteris-page-templates', 'asteris-video' ] ],
		'page-template-audiobook'           => [ 'title' => 'Page — Audiobook landing',     'categories' => [ 'asteris-page-templates', 'asteris-audio' ] ],
		'page-template-tutorial-series'     => [ 'title' => 'Page — Tutorial series hub',   'categories' => [ 'asteris-page-templates', 'asteris-video' ] ],
		'page-template-interview-series'    => [ 'title' => 'Page — Interview / Q&A series','categories' => [ 'asteris-page-templates', 'asteris-video', 'asteris-audio' ] ],
		'page-template-live-stream-event'   => [ 'title' => 'Page — Live stream event',     'categories' => [ 'asteris-page-templates', 'asteris-video' ] ],

		// Composite sections — multi-section combos in a single insert.
		// Primary category is asteris-composites (Pro-only). Cross-tagged
		// into single-section categories so users browsing by section
		// type still find them.
		'composite-above-fold'        => [ 'title' => 'Composite — Above-the-fold (Hero + Logos + Stats)', 'categories' => [ 'asteris-composites', 'featured' ] ],
		'composite-social-proof'      => [ 'title' => 'Composite — Social proof (Reviews + Press strip)',  'categories' => [ 'asteris-composites', 'asteris-testimonials' ] ],
		'composite-pricing-block'     => [ 'title' => 'Composite — Pricing block (3-tier + FAQ + CTA)',    'categories' => [ 'asteris-composites', 'asteris-pricing' ] ],
		'composite-mid-page-conversion'=> [ 'title' => 'Composite — Mid-page conversion (Features + Quote + CTA)', 'categories' => [ 'asteris-composites', 'featured' ] ],
		'composite-pre-footer'        => [ 'title' => 'Composite — Pre-footer (Newsletter + Social + Brand)', 'categories' => [ 'asteris-composites', 'asteris-cta' ] ],
		'composite-about-section'     => [ 'title' => 'Composite — About section (Intro + Values + Team)',  'categories' => [ 'asteris-composites' ] ],
		'composite-faq-final-cta'     => [ 'title' => 'Composite — FAQ + final CTA',                       'categories' => [ 'asteris-composites', 'asteris-faq', 'asteris-cta' ] ],

		// Premium e-commerce (WC-gated at file load — file returns empty string if WC inactive)
		'shop-pro-story-product'  => [ 'title' => 'Shop Pro — Story-led product page',  'categories' => [ 'asteris-shop', 'woo-commerce', 'featured' ] ],
		'shop-pro-drop-launch'    => [ 'title' => 'Shop Pro — Limited drop launch',     'categories' => [ 'asteris-shop', 'woo-commerce', 'featured' ] ],
		'shop-pro-bundle-builder' => [ 'title' => 'Shop Pro — Bundle builder',          'categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-gift-guide'     => [ 'title' => 'Shop Pro — Gift guide',              'categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-subscription'   => [ 'title' => 'Shop Pro — Subscription / recurring','categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-wholesale'      => [ 'title' => 'Shop Pro — Wholesale / B2B',          'categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-stockists'      => [ 'title' => 'Shop Pro — Stockists / find a retailer', 'categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-sustainability' => [ 'title' => 'Shop Pro — Sustainability / brand values', 'categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-configurator'   => [ 'title' => 'Shop Pro — Made-to-order configurator', 'categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-care-guide'     => [ 'title' => 'Shop Pro — Care &amp; materials guide', 'categories' => [ 'asteris-shop', 'woo-commerce' ] ],
		'shop-pro-loyalty'        => [ 'title' => 'Shop Pro — Loyalty / VIP program',    'categories' => [ 'asteris-shop', 'woo-commerce' ] ],

		// Premium heroes — sophisticated / layered / interactive heroes
		'hero-pro-counters'        => [ 'title' => 'Hero Pro — Animated counters',         'categories' => [ 'asteris-heroes', 'featured' ] ],
		'hero-pro-editorial-split' => [ 'title' => 'Hero Pro — Editorial split (cover + card)', 'categories' => [ 'asteris-heroes', 'featured' ] ],
		'hero-pro-video-caption'   => [ 'title' => 'Hero Pro — Video bg + caption strip',  'categories' => [ 'asteris-heroes', 'asteris-video' ] ],
		'hero-pro-magazine'        => [ 'title' => 'Hero Pro — Magazine cover',            'categories' => [ 'asteris-heroes', 'featured' ] ],
		'hero-pro-countdown'       => [ 'title' => 'Hero Pro — Countdown launch',          'categories' => [ 'asteris-heroes', 'asteris-shop' ] ],
		'hero-pro-marquee-announce'=> [ 'title' => 'Hero Pro — Marquee announcement bar',  'categories' => [ 'asteris-heroes' ] ],
		'hero-pro-quote-portrait'  => [ 'title' => 'Hero Pro — Quote-led with portrait',   'categories' => [ 'asteris-heroes', 'asteris-testimonials' ] ],
		'hero-pro-layered'         => [ 'title' => 'Hero Pro — Layered (overlay card)',    'categories' => [ 'asteris-heroes', 'featured' ] ],
	];

	public function __construct( private License $license ) {}

	public function register(): void {
		add_action( 'init', [ $this, 'register_categories' ], 9 );
		add_action( 'init', [ $this, 'register_patterns' ], 11 );
	}

	/**
	 * Pro-only categories that don't belong in the free theme.
	 * Registered only when this plugin is active so free-theme users
	 * never see an empty "Composites" entry in the inserter.
	 */
	public function register_categories(): void {
		register_block_pattern_category( 'asteris-composites', [
			'label'       => __( 'Asteris — Composites', 'asteris-pro-patterns' ),
			'description' => __( 'Multi-section combos in a single insert — Hero + Logos + Stats, Pricing + FAQ + CTA, etc.', 'asteris-pro-patterns' ),
		] );
	}

	public function register_patterns(): void {
		if ( ! $this->license->is_active() ) {
			$this->register_unlock_teaser();
			return;
		}

		$placeholder_url = ASTERIS_PRO_PATTERNS_URL . 'assets/placeholder.svg';

		foreach ( self::PATTERNS as $slug => $meta ) {
			$file = ASTERIS_PRO_PATTERNS_DIR . '/patterns/' . $slug . '.php';
			if ( ! file_exists( $file ) ) { continue; }
			$content = require $file;
			if ( ! is_string( $content ) || '' === $content ) { continue; }

			// Interpolate placeholder URL so empty wp:image blocks point at a
			// visible SVG (validates because the JSON `url` and `<img src>`
			// both contain the same final URL).
			$content = strtr( $content, [ '{{PLACEHOLDER_URL}}' => $placeholder_url ] );

			register_block_pattern( 'asteris-pro/' . $slug, [
				'title'         => __( $meta['title'], 'asteris-pro-patterns' ),
				'categories'    => $meta['categories'],
				'content'       => $content,
				'viewportWidth' => 1200,
				'description'   => $meta['title'],
			] );
		}
	}

	private function register_unlock_teaser(): void {
		$url = esc_url( admin_url( 'options-general.php?page=asteris-pro-patterns' ) );
		$content = '<!-- wp:group {"align":"full","backgroundColor":"subtle","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->'
			. '<div class="wp-block-group alignfull has-subtle-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">'
			. '<!-- wp:heading {"textAlign":"center","level":2,"fontSize":"x-large"} --><h2 class="wp-block-heading has-text-align-center has-x-large-font-size">Unlock 18 premium patterns</h2><!-- /wp:heading -->'
			. '<!-- wp:paragraph {"align":"center"} --><p class="has-text-align-center">Activate your Asteris Pro Patterns licence to use this video and audio library.</p><!-- /wp:paragraph -->'
			. '<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} --><div class="wp-block-buttons">'
			. '<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . $url . '">Activate licence</a></div><!-- /wp:button -->'
			. '</div><!-- /wp:buttons -->'
			. '</div><!-- /wp:group -->';

		register_block_pattern( 'asteris-pro/unlock', [
			'title'         => __( 'Asteris Pro — unlock premium patterns', 'asteris-pro-patterns' ),
			'categories'    => [ 'asteris-video', 'asteris-audio' ],
			'content'       => $content,
			'viewportWidth' => 1200,
			'description'   => __( 'Activate your licence to unlock 50+ premium patterns.', 'asteris-pro-patterns' ),
		] );
	}
}
