<?php
/**
 * Plugin Name:       Asteris Pro Patterns
 * Plugin URI:        https://asteriscommerce.com/asteris-pro-patterns/
 * Description:       50+ premium block patterns for the Asteris theme — niche page templates, video sections, podcast/audio patterns, premium e-commerce sections, advanced content patterns. Licensed product.
 * Version:           1.7.3
 * Author:            Asteris Commerce
 * Author URI:        https://asteriscommerce.com
 * License:           Proprietary
 * Text Domain:       asteris-pro-patterns
 * Requires at least: 6.5
 * Requires PHP:      8.1
 */

defined( 'ABSPATH' ) || exit;

define( 'ASTERIS_PRO_PATTERNS_VERSION', '1.7.3' );
define( 'ASTERIS_PRO_PATTERNS_DIR',     __DIR__ );
define( 'ASTERIS_PRO_PATTERNS_FILE',    __FILE__ );
define( 'ASTERIS_PRO_PATTERNS_URL',     plugin_dir_url( __FILE__ ) );
define( 'ASTERIS_PRO_PATTERNS_SLUG',    'asteris_pro_patterns' );

// HMAC signing secret for verifying licence server responses.
// Baked here per the locked rule (feedback_secret_baking_locked.md) — this
// is response-verification only, not an auth credential, and GPL bypass is
// already legal so obfuscation buys nothing. Zero-config install wins.
if ( ! defined( 'ASTERIS_LS_SIGNING_SECRET' ) ) {
	define( 'ASTERIS_LS_SIGNING_SECRET', 'df8fb23b9877c4e9edbb5951dcebd35220f46ab3e6116ab18e6287ce553c59a7' );
}

// Licence server endpoint.
if ( ! defined( 'ASTERIS_LS_ENDPOINT' ) ) {
	define( 'ASTERIS_LS_ENDPOINT', 'https://pay.asteriscommerce.com' );
}

require __DIR__ . '/src/License.php';
require __DIR__ . '/src/Settings.php';
require __DIR__ . '/src/Patterns.php';
require __DIR__ . '/src/Plugin.php';

add_action( 'plugins_loaded', static function (): void {
	( new \AsterisProPatterns\Plugin() )->boot();
} );

register_activation_hook( __FILE__, static function (): void {
	set_transient( 'asteris_pro_patterns_show_welcome', 1, 60 );
} );
